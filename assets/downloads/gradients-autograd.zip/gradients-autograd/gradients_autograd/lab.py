"""Gradients by hand, by autograd and by central finite differences.

Synthetic linear regression on CPU in float64:
    pred = X @ w + b, loss = mean((pred - y) ** 2)
"""

import math
import sys

import torch

DTYPE = torch.float64
N_SAMPLES = 16
N_FEATURES = 3
SEED = 0
FD_STEP = 1e-6
LEARNING_RATE = 0.1
MICROBATCH_SIZES = (5, 11)


def make_data(
    n: int = N_SAMPLES, d: int = N_FEATURES, seed: int = SEED
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return X (n, d) and y (n,) from a known linear rule plus noise."""
    gen = torch.Generator().manual_seed(seed)
    x = torch.randn(n, d, generator=gen, dtype=DTYPE)
    true_w = torch.tensor([2.0, -1.0, 0.5], dtype=DTYPE)[:d]
    noise = 0.1 * torch.randn(n, generator=gen, dtype=DTYPE)
    y = x @ true_w + 0.3 + noise
    return x, y


def mse_loss(
    x: torch.Tensor, y: torch.Tensor, w: torch.Tensor, b: torch.Tensor
) -> torch.Tensor:
    """Mean squared error; returns a 0-dim tensor (a scalar)."""
    residual = x @ w + b - y  # (n,)
    return (residual**2).mean()


def analytic_grads(
    x: torch.Tensor, y: torch.Tensor, w: torch.Tensor, b: torch.Tensor
) -> tuple[torch.Tensor, torch.Tensor]:
    """Hand-derived: dL/dw = 2/n X^T r, shape (d,); dL/db = 2/n sum(r)."""
    with torch.no_grad():
        residual = x @ w + b - y
        n = x.shape[0]
        return 2.0 / n * (x.T @ residual), 2.0 / n * residual.sum()


def autograd_grads(
    x: torch.Tensor, y: torch.Tensor, w: torch.Tensor, b: torch.Tensor
) -> tuple[torch.Tensor, torch.Tensor]:
    """Gradients from one reverse-mode pass, on fresh leaf copies."""
    w_leaf = w.detach().clone().requires_grad_(True)
    b_leaf = b.detach().clone().requires_grad_(True)
    mse_loss(x, y, w_leaf, b_leaf).backward()
    return w_leaf.grad, b_leaf.grad


def finite_diff_grads(
    x: torch.Tensor,
    y: torch.Tensor,
    w: torch.Tensor,
    b: torch.Tensor,
    h: float = FD_STEP,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Central differences (L(t + h) - L(t - h)) / 2h, per parameter."""
    if not (math.isfinite(h) and h > 0):
        raise ValueError(f"h must be a finite positive number, got {h!r}")
    theta = torch.cat([w.detach(), b.detach().reshape(1)])
    grad = torch.empty_like(theta)
    with torch.no_grad():
        for i in range(theta.numel()):
            plus, minus = theta.clone(), theta.clone()
            plus[i] += h
            minus[i] -= h
            loss_plus = mse_loss(x, y, plus[:-1], plus[-1])
            loss_minus = mse_loss(x, y, minus[:-1], minus[-1])
            grad[i] = (loss_plus - loss_minus) / (2.0 * h)
    return grad[:-1], grad[-1]


def microbatch_grads(
    x: torch.Tensor,
    y: torch.Tensor,
    w: torch.Tensor,
    b: torch.Tensor,
    sizes: tuple[int, ...],
) -> tuple[torch.Tensor, torch.Tensor]:
    """Accumulate .grad over consecutive microbatches of the given sizes.

    Each microbatch mean is weighted by its share of the reduced loss
    elements, numel_i / numel_total, so the accumulated gradient equals the
    full-batch mean gradient even for unequal sizes. w and b stay fixed.
    """
    if not sizes or min(sizes) <= 0 or sum(sizes) != x.shape[0]:
        raise ValueError(
            f"sizes must be positive and sum to {x.shape[0]}, got {sizes}"
        )
    w_leaf = w.detach().clone().requires_grad_(True)
    b_leaf = b.detach().clone().requires_grad_(True)
    start = 0
    for size in sizes:
        part = slice(start, start + size)
        weight = y[part].numel() / y.numel()
        (weight * mse_loss(x[part], y[part], w_leaf, b_leaf)).backward()
        start += size
    return w_leaf.grad, b_leaf.grad


def graph_nodes(loss: torch.Tensor) -> list[str]:
    """Names of backward nodes reachable from loss.grad_fn, in BFS order."""
    names: list[str] = []
    seen: list[object] = []  # keep references: id() of a freed node is reused
    queue = [loss.grad_fn]
    while queue:
        node = queue.pop(0)
        if node is None or any(node is other for other in seen):
            continue
        seen.append(node)
        names.append(type(node).__name__)
        queue.extend(child for child, _ in node.next_functions)
    return names


def gd_step(
    x: torch.Tensor,
    y: torch.Tensor,
    w: torch.Tensor,
    b: torch.Tensor,
    lr: float,
) -> tuple[float, float]:
    """One in-place gradient-descent update; returns (before, after)."""
    loss = mse_loss(x, y, w, b)
    w.grad, b.grad = None, None
    loss.backward()
    with torch.no_grad():
        w -= lr * w.grad
        b -= lr * b.grad
        loss_after = mse_loss(x, y, w, b)
    return loss.item(), loss_after.item()


def print_table(
    names: list[str], columns: dict[str, torch.Tensor], ref: torch.Tensor
) -> None:
    header = f"{'param':<6}" + "".join(f"{key:>22}" for key in columns)
    print(header + f"{'|auto-ana|':>12}{'|fd-ana|':>12}")
    for i, name in enumerate(names):
        row = f"{name:<6}" + "".join(
            f"{col[i].item():>22.15f}" for col in columns.values()
        )
        auto_err = abs(columns["autograd"][i] - ref[i]).item()
        fd_err = abs(columns["finite diff"][i] - ref[i]).item()
        print(row + f"{auto_err:>12.1e}{fd_err:>12.1e}")


def flat(grads: tuple[torch.Tensor, torch.Tensor]) -> torch.Tensor:
    return torch.cat([g.reshape(-1) for g in grads])


def main() -> None:
    version = sys.version.split()[0]
    print(f"python {version}, torch {torch.__version__}, dtype {DTYPE}")
    x, y = make_data()
    w = torch.zeros(N_FEATURES, dtype=DTYPE, requires_grad=True)
    b = torch.zeros((), dtype=DTYPE, requires_grad=True)
    shapes = [tuple(t.shape) for t in (x, y, w, b)]
    print("shapes: X {}, y {}, w {}, b {}".format(*shapes))

    loss = mse_loss(x, y, w, b)
    print(f"loss at w=0, b=0: {loss.item():.6f}  (0-dim: {loss.dim() == 0})")
    print("backward nodes (BFS order):", ", ".join(graph_nodes(loss)))
    print(f"is_leaf: w={w.is_leaf}, loss={loss.is_leaf}")

    ana = flat(analytic_grads(x, y, w, b))
    auto = flat(autograd_grads(x, y, w, b))
    fd = flat(finite_diff_grads(x, y, w, b))
    print(f"\ngradient comparison (central differences, h={FD_STEP:g}):")
    columns = {"analytic": ana, "autograd": auto, "finite diff": fd}
    print_table(["w[0]", "w[1]", "w[2]", "b"], columns, ana)

    print("\nfinite-difference error on w[0] vs step h:")
    for h in (1e8, 1e4, 1e-2, 1e-4, 1e-6, 1e-8, 1e-10):
        fd_h = finite_diff_grads(x, y, w, b, h)[0][0]
        print(f"  h={h:<6g} |fd-ana| = {abs(fd_h - ana[0]).item():.1e}")

    sizes = MICROBATCH_SIZES
    weighted = flat(microbatch_grads(x, y, w, b, sizes))
    w_eq = w.detach().clone().requires_grad_(True)
    b_eq = b.detach().clone().requires_grad_(True)
    start = 0
    for size in sizes:
        part = slice(start, start + size)
        (mse_loss(x[part], y[part], w_eq, b_eq) / len(sizes)).backward()
        start += size
    equal = flat((w_eq.grad, b_eq.grad))
    print(f"\nmicrobatches {sizes}, max |accumulated - full batch|:")
    print(f"  weight 1/k:      {(equal - ana).abs().max().item():.1e}")
    print(f"  weight n_i/n:    {(weighted - ana).abs().max().item():.1e}")

    loss.backward()
    first = w.grad.clone()
    mse_loss(x, y, w, b).backward()
    ratio = (w.grad / first).tolist()
    print(f"\naccumulation: second backward without zeroing -> "
          f"w.grad / first = {ratio}")

    before, after = gd_step(x, y, w, b, LEARNING_RATE)
    print(f"\none GD step, lr={LEARNING_RATE}: "
          f"loss {before:.6f} -> {after:.6f}")
    print(f"w after step: {[round(v, 6) for v in w.tolist()]}, "
          f"b: {b.item():.6f}")


if __name__ == "__main__":
    main()
