"""Small lab: gradients by hand, by autograd and by finite differences."""
