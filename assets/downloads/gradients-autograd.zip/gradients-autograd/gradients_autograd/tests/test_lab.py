"""Checks for the gradient lab. All tensors are float64 on CPU.

Tolerances:
- autograd vs analytic: rtol=1e-9. Both evaluate the same formula with a
  different order of float64 operations over 16 samples; the expected gap
  is a few ulps (~1e-15 relative). 1e-9 leaves a wide margin while still
  catching real bugs such as a missing factor 2 or 1/n.
- finite differences vs analytic: rtol=1e-6, atol=1e-8. Central differences
  have truncation error O(h^2 * L''') and rounding error ~ eps * |L| / h.
  For this quadratic loss L''' = 0, so with h=1e-6 the error is dominated
  by rounding: ~2.2e-16 * L / 1e-6, i.e. around 1e-10 * L. The tolerance
  sits well above it.
"""

import math

import pytest
import torch

from gradients_autograd import lab
from gradients_autograd.lab import (
    DTYPE,
    analytic_grads,
    autograd_grads,
    finite_diff_grads,
    gd_step,
    make_data,
    mse_loss,
)


@pytest.fixture()
def data() -> tuple[torch.Tensor, torch.Tensor]:
    return make_data()


@pytest.fixture()
def params() -> tuple[torch.Tensor, torch.Tensor]:
    w = torch.tensor([0.4, -0.2, 0.1], dtype=DTYPE, requires_grad=True)
    b = torch.tensor(0.05, dtype=DTYPE, requires_grad=True)
    return w, b


def test_analytic_gradient_matches_hand_computed_values() -> None:
    # X = [[1, 2], [3, 4]], y = [1, 2], w = 0, b = 0  ->  r = [-1, -2]
    # dL/dw = 2/2 * X^T r = [-7, -10], dL/db = 2/2 * (-3) = -3, L = (1 + 4) / 2
    x = torch.tensor([[1.0, 2.0], [3.0, 4.0]], dtype=DTYPE)
    y = torch.tensor([1.0, 2.0], dtype=DTYPE)
    w = torch.zeros(2, dtype=DTYPE)
    b = torch.zeros((), dtype=DTYPE)
    grad_w, grad_b = analytic_grads(x, y, w, b)
    assert grad_w.tolist() == [-7.0, -10.0]
    assert grad_b.item() == -3.0
    assert mse_loss(x, y, w, b).item() == 2.5


def test_autograd_matches_analytic(data, params) -> None:
    x, y = data
    w, b = params
    ana_w, ana_b = analytic_grads(x, y, w, b)
    auto_w, auto_b = autograd_grads(x, y, w, b)
    torch.testing.assert_close(auto_w, ana_w, rtol=1e-9, atol=0.0)
    torch.testing.assert_close(auto_b, ana_b, rtol=1e-9, atol=0.0)


def test_finite_differences_match_analytic(data, params) -> None:
    x, y = data
    w, b = params
    ana_w, ana_b = analytic_grads(x, y, w, b)
    fd_w, fd_b = finite_diff_grads(x, y, w, b, h=1e-6)
    torch.testing.assert_close(fd_w, ana_w, rtol=1e-6, atol=1e-8)
    torch.testing.assert_close(fd_b, ana_b, rtol=1e-6, atol=1e-8)


def test_gradient_accumulates_unless_zeroed(data, params) -> None:
    x, y = data
    w, b = params
    mse_loss(x, y, w, b).backward()
    first = w.grad.clone()
    mse_loss(x, y, w, b).backward()
    torch.testing.assert_close(w.grad, 2.0 * first)
    w.grad = None
    mse_loss(x, y, w, b).backward()
    torch.testing.assert_close(w.grad, first)


def test_only_leaf_tensors_get_grad(data, params) -> None:
    x, y = data
    w, b = params
    residual = x @ w + b - y
    (residual**2).mean().backward()
    assert w.is_leaf and w.grad is not None
    assert not residual.is_leaf
    with pytest.warns(UserWarning):
        assert residual.grad is None


def test_second_backward_through_mse_graph_needs_retain_graph(
    data, params
) -> None:
    # The MSE graph saves tensors (e.g. the residual for pow); backward frees
    # them, so a second backward through this graph fails.
    x, y = data
    w, b = params
    loss = mse_loss(x, y, w, b)
    loss.backward()
    second_time = "backward through the graph a second time"
    with pytest.raises(RuntimeError, match=second_time):
        loss.backward()
    kept = mse_loss(x, y, w, b)
    kept.backward(retain_graph=True)
    kept.backward()


def test_non_scalar_backward_needs_gradient_argument(data, params) -> None:
    x, y = data
    w, b = params
    residual = x @ w + b - y  # shape (16,)
    with pytest.raises(RuntimeError, match="only for scalar outputs"):
        residual.backward()
    # The VJP with v = 2r/n reproduces the gradient of the mean loss.
    v = (2.0 / residual.shape[0] * residual).detach()
    residual.backward(gradient=v)
    expected = analytic_grads(x, y, w, b)[0]
    torch.testing.assert_close(w.grad, expected, rtol=1e-9, atol=0.0)


def test_no_grad_stops_graph_building(data, params) -> None:
    x, y = data
    w, b = params
    with torch.no_grad():
        loss = mse_loss(x, y, w, b)
    assert not loss.requires_grad
    assert loss.grad_fn is None


def test_detach_stops_tracking(data, params) -> None:
    x, y = data
    w, b = params
    pred = (x @ w + b).detach()
    assert not pred.requires_grad and pred.grad_fn is None
    loss = ((pred - y) ** 2).mean() + b
    loss.backward()
    assert w.grad is None  # the path through pred was cut
    assert b.grad.item() == 1.0  # only the direct "+ b" term remains


def test_requires_grad_false_freezes_parameter(data, params) -> None:
    x, y = data
    w, b = params
    b.requires_grad_(False)
    mse_loss(x, y, w, b).backward()
    assert w.grad is not None
    assert b.grad is None


def test_sum_reduction_scales_gradient_by_batch_size(data, params) -> None:
    x, y = data
    w, b = params
    ((x @ w + b - y) ** 2).sum().backward()
    grad_sum = w.grad.clone()
    w.grad = None
    mse_loss(x, y, w, b).backward()
    torch.testing.assert_close(
        grad_sum, x.shape[0] * w.grad, rtol=1e-12, atol=0.0
    )


@pytest.mark.parametrize("h", [0.0, -1e-6, math.nan, math.inf])
def test_finite_difference_rejects_invalid_step(data, params, h) -> None:
    x, y = data
    w, b = params
    with pytest.raises(ValueError, match="finite positive"):
        finite_diff_grads(x, y, w, b, h=h)


def test_finite_difference_rounding_grows_for_very_large_step(
    data, params
) -> None:
    # L is quadratic, so truncation error is zero; for huge h the perturbed
    # losses grow like h**2 and their rounding error (~eps * L / h) grows.
    x, y = data
    w, b = params
    ana_w = analytic_grads(x, y, w, b)[0]
    err = {
        h: (finite_diff_grads(x, y, w, b, h=h)[0] - ana_w).abs().max().item()
        for h in (1e-2, 1e8)
    }
    assert err[1e8] > 1e3 * err[1e-2]


def test_freezing_does_not_clear_an_existing_grad(data, params) -> None:
    x, y = data
    w, b = params
    mse_loss(x, y, w, b).backward()
    stale = b.grad.clone()
    b.requires_grad_(False)
    assert b.grad is not None  # freezing keeps the old gradient
    torch.optim.SGD([w, b], lr=0.1).step()
    assert b.item() == pytest.approx(0.05 - 0.1 * stale.item())
    # Clearing the stale gradient makes the optimizer skip the parameter.
    b.grad = None
    frozen = b.item()
    w.grad = None
    mse_loss(x, y, w, b).backward()
    torch.optim.SGD([w, b], lr=0.1).step()
    assert b.grad is None and b.item() == frozen


def test_no_grad_factory_exception() -> None:
    with torch.no_grad():
        created = torch.ones(1, dtype=DTYPE, requires_grad=True)
        param = torch.nn.Parameter(torch.ones(1, dtype=DTYPE))
    assert created.requires_grad and created.is_leaf
    assert param.requires_grad


def test_second_backward_works_when_no_tensors_are_saved() -> None:
    p = torch.tensor(1.0, dtype=DTYPE, requires_grad=True)
    z = p + 1  # AddBackward0 with a constant saves no tensors
    z.backward()
    z.backward()  # no retain_graph needed here
    assert p.grad.item() == 2.0


def test_backward_inputs_accumulates_into_non_leaf(data, params) -> None:
    x, y = data
    w, b = params
    residual = x @ w + b - y
    (residual**2).mean().backward(inputs=[residual])
    expected = (2.0 / residual.shape[0] * residual).detach()
    torch.testing.assert_close(residual.grad, expected, rtol=1e-12, atol=0.0)
    assert w.grad is None  # only the listed inputs receive .grad


def test_one_element_tensor_allows_implicit_backward() -> None:
    p = torch.tensor([3.0], dtype=DTYPE, requires_grad=True)
    (p * p).backward()  # shape (1,): one element, no gradient argument
    assert p.grad.tolist() == [6.0]


def test_double_is_recorded_only_when_it_converts() -> None:
    converted = torch.randn(3, requires_grad=True).double()  # float32 -> 64
    assert not converted.is_leaf
    same = torch.zeros(3, dtype=DTYPE, requires_grad=True)
    assert same.double() is same and same.is_leaf


def test_duplicating_samples_doubles_sum_gradient(data, params) -> None:
    x, y = data
    w, b = params
    x2, y2 = torch.cat([x, x]), torch.cat([y, y])
    grad_sum = torch.autograd.grad(((x @ w + b - y) ** 2).sum(), w)[0]
    grad_sum2 = torch.autograd.grad(((x2 @ w + b - y2) ** 2).sum(), w)[0]
    torch.testing.assert_close(grad_sum2, 2.0 * grad_sum, rtol=1e-12, atol=0.0)
    grad_mean = torch.autograd.grad(mse_loss(x, y, w, b), w)[0]
    grad_mean2 = torch.autograd.grad(mse_loss(x2, y2, w, b), w)[0]
    torch.testing.assert_close(grad_mean2, grad_mean, rtol=1e-12, atol=0.0)


def test_unequal_microbatches_need_element_count_weights(
    data, params
) -> None:
    x, y = data
    w, b = params
    full_w, full_b = analytic_grads(x, y, w, b)
    acc_w, acc_b = lab.microbatch_grads(x, y, w, b, sizes=(5, 11))
    torch.testing.assert_close(acc_w, full_w, rtol=1e-12, atol=1e-15)
    torch.testing.assert_close(acc_b, full_b, rtol=1e-12, atol=1e-15)
    # Plain 1/k weighting is wrong once the microbatches differ in size.
    w_leaf = w.detach().clone().requires_grad_(True)
    b_leaf = b.detach().clone().requires_grad_(True)
    for part in (slice(0, 5), slice(5, 16)):
        (mse_loss(x[part], y[part], w_leaf, b_leaf) / 2).backward()
    assert (w_leaf.grad - full_w).abs().max().item() > 0.1


@pytest.mark.parametrize("sizes", [(), (5, 10), (0, 16), (-1, 17)])
def test_microbatch_sizes_must_cover_the_batch(data, params, sizes) -> None:
    x, y = data
    w, b = params
    with pytest.raises(ValueError, match="sizes"):
        lab.microbatch_grads(x, y, w, b, sizes=sizes)


def test_gradient_descent_converges_on_convex_problem(data) -> None:
    x, y = data
    w = torch.zeros(3, dtype=DTYPE, requires_grad=True)
    b = torch.zeros((), dtype=DTYPE, requires_grad=True)
    losses = []
    for _ in range(2000):
        before, after = gd_step(x, y, w, b, lr=0.1)
        losses.append(before)
    assert after < losses[0]
    # Hessian eigenvalues here lie in [1.04, 2.79], so lr=0.1 < 2 / 2.79 is
    # stable and the loss decreases monotonically. Once it reaches its minimum
    # (~0.0168), steps change it by a few ulps (observed +1e-16), so allow a
    # 1e-12 relative slack.
    assert all(
        later <= earlier * (1.0 + 1e-12)
        for earlier, later in zip(losses, losses[1:])
    )
    design = torch.cat([x, torch.ones(x.shape[0], 1, dtype=DTYPE)], dim=1)
    solution = torch.linalg.lstsq(design, y.unsqueeze(1)).solution.squeeze(1)
    learned = torch.cat([w.detach(), b.detach().reshape(1)])
    torch.testing.assert_close(learned, solution, rtol=0.0, atol=1e-8)
