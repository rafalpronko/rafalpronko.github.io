# Gradients lab: analytic vs autograd vs finite differences

A small CPU-only lab for the article "Gradients from scratch to autograd:
what actually flows backward". Synthetic linear regression (16 samples,
3 features, fixed seed), float64, MSE loss.

## Dates and versions

The article carries the editorial date 2 May 2024. The lab was executed and
tested on 12 October 2026 with a modern toolchain that reproduces the
historical library pin:

- `torch==2.2.2` (released 27 March 2024) and `numpy<2`, locked to
  numpy 1.26.4; torch 2.2.x wheels were built against NumPy 1.x.
- CPython 3.11 only: `requires-python = ">=3.11,<3.12"`. Other Python
  versions are not covered by `uv.lock` and were not tested.
- `pytest` is unpinned in `pyproject.toml`; `uv.lock` fixes it at 9.1.1,
  and some transitive packages (for example fsspec 2026.9.0) are newer
  than the editorial date. They are verification tooling, not part of the
  2024-era API surface used by the lab.
- Verified only on macOS arm64 (CPU) with uv 0.7.8. Whether torch 2.2.2
  wheels exist for your platform is decided by PyPI; Linux and Windows were
  not run.

## Setup and run

You need [uv](https://docs.astral.sh/uv/). From the directory that contains
`pyproject.toml` and `uv.lock`:

```bash
uv sync --locked --python 3.11
uv run --frozen python -m gradients_autograd.lab
uv run --frozen python -m pytest -v
```

`uv sync --locked` fails instead of silently re-resolving if the lockfile
does not match `pyproject.toml`; `--frozen` then runs from the lock without
touching it. The torch download is a few hundred MB.

## What you should see

- the backward nodes reachable from the loss, in breadth-first order
  (a list of visited nodes, not a path),
- a table where autograd equals the hand-derived gradient and central
  differences differ by about 1e-10,
- a sweep of the finite-difference step `h`: both very small and very
  large steps increase the error,
- accumulated microbatch gradients for sizes 5 and 11: weighting each mean
  by 1/k is wrong, weighting by the element count matches the full batch,
- `w.grad` doubling after a second `backward()` without zeroing,
- one gradient-descent step lowering the loss.

The tests (29) also cover the edge cases discussed in the article: stale
gradients on frozen parameters, the `no_grad` factory exception, graphs
without saved tensors, `backward(inputs=...)` on a non-leaf, one-element
implicit backward, and invalid finite-difference steps.
