"""Frozen split, validation-only model selection and one test evaluation."""
