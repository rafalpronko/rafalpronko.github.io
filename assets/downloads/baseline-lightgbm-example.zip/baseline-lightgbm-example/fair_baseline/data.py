"""Bundled Wisconsin Diagnostic Breast Cancer data with an explicit positive class."""

import hashlib
from typing import NamedTuple

import numpy as np
from sklearn.datasets import load_breast_cancer

MALIGNANT = 1
BENIGN = 0

ORDERING_CONTRACT = (
    "Rows keep the order returned by sklearn.datasets.load_breast_cancer() "
    "(scikit-learn 1.3.2, bundled CSV, no download). Split indices are positional "
    "row numbers in that order and are valid only while dataset_sha256 matches."
)


class Dataset(NamedTuple):
    X: np.ndarray  # float64, shape (569, 30)
    y: np.ndarray  # int64, 1 = malignant, 0 = benign
    feature_names: tuple[str, ...]


def load_dataset() -> Dataset:
    bunch = load_breast_cancer()
    # scikit-learn encodes 0 = malignant, 1 = benign. We want malignant as the positive class.
    original_malignant = list(bunch.target_names).index("malignant")
    y = np.where(bunch.target == original_malignant, MALIGNANT, BENIGN).astype(np.int64)
    X = np.ascontiguousarray(bunch.data, dtype=np.float64)
    return Dataset(X=X, y=y, feature_names=tuple(bunch.feature_names))


def dataset_digest(data: Dataset) -> str:
    """SHA-256 over shape, feature names, feature bytes and labels, in row order."""
    h = hashlib.sha256()
    h.update(repr(data.X.shape).encode())
    h.update("\n".join(data.feature_names).encode())
    h.update(np.ascontiguousarray(data.X, dtype="<f8").tobytes())
    h.update(np.ascontiguousarray(data.y, dtype="<i8").tobytes())
    return h.hexdigest()
