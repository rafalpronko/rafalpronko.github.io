"""Stratified train/validation/test split stored as positional indices."""

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from sklearn.model_selection import train_test_split

from fair_baseline.data import ORDERING_CONTRACT, Dataset, dataset_digest

SPLIT_SEED = 2023  # chosen before any model was trained, never tuned
TEST_FRACTION = 0.20
VALIDATION_FRACTION_OF_REST = 0.25  # 0.25 * 0.80 = 0.20 of all rows


@dataclass(frozen=True)
class Split:
    seed: int
    dataset_sha256: str
    train: np.ndarray
    validation: np.ndarray
    test: np.ndarray

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Split):
            return NotImplemented
        return (
            self.seed == other.seed
            and self.dataset_sha256 == other.dataset_sha256
            and all(np.array_equal(a, b) for a, b in zip(self._parts(), other._parts()))
        )

    def _parts(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        return self.train, self.validation, self.test


def make_split(data: Dataset, seed: int = SPLIT_SEED) -> Split:
    rows = np.arange(len(data.y))
    rest, test = train_test_split(
        rows, test_size=TEST_FRACTION, stratify=data.y, random_state=seed
    )
    train, validation = train_test_split(
        rest, test_size=VALIDATION_FRACTION_OF_REST, stratify=data.y[rest], random_state=seed
    )
    return Split(seed, dataset_digest(data), np.sort(train), np.sort(validation), np.sort(test))


def save_split(split: Split, path: Path) -> None:
    record = {
        "seed": split.seed,
        "dataset_sha256": split.dataset_sha256,
        "ordering_contract": ORDERING_CONTRACT,
        "sizes": {"train": len(split.train), "validation": len(split.validation), "test": len(split.test)},
        "train": split.train.tolist(),
        "validation": split.validation.tolist(),
        "test": split.test.tolist(),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(record, indent=1) + "\n")


def load_split(path: Path, data: Dataset) -> Split:
    record = json.loads(Path(path).read_text())
    if record["dataset_sha256"] != dataset_digest(data):
        raise ValueError("dataset digest differs from the frozen split; indices are not valid")
    parts = [np.asarray(record[k], dtype=np.int64) for k in ("train", "validation", "test")]
    return Split(record["seed"], record["dataset_sha256"], *parts)
