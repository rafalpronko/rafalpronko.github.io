"""Validation comparison, frozen selection record and a single test evaluation."""

import hashlib
import json
from pathlib import Path
from typing import Any, NamedTuple

import numpy as np
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

from fair_baseline.data import MALIGNANT, Dataset
from fair_baseline.models import CANDIDATES
from fair_baseline.split import Split

SELECTION_METRIC = "log_loss"  # smaller is better
THRESHOLD = 0.5  # fixed in advance; used only for the accuracy line


class Comparison(NamedTuple):
    models: dict[str, Any]
    scores: dict[str, dict[str, float]]  # validation rows: the only numbers used for the choice
    train_log_loss: dict[str, float]  # rows the model was fitted on: context, never used for the choice


def malignant_probability(model: Any, X: np.ndarray) -> np.ndarray:
    column = list(model.classes_).index(MALIGNANT)
    return model.predict_proba(X)[:, column]


def row_losses(y: np.ndarray, p: np.ndarray) -> np.ndarray:
    """Per-row log loss, clipped like log_loss(eps="auto") in scikit-learn 1.3."""
    eps = np.finfo(p.dtype).eps
    p = np.clip(p, eps, 1 - eps)
    return -(y * np.log(p) + (1 - y) * np.log(1 - p))


def probability_scores(y: np.ndarray, p: np.ndarray) -> dict[str, float]:
    losses = np.sort(row_losses(y, p))[::-1]
    return {
        "log_loss": float(log_loss(y, p, labels=[0, 1])),
        "roc_auc": float(roc_auc_score(y, p)),
        # How much of the total loss comes from the few worst rows (diagnostic only).
        "max_row_loss": float(losses[0]),
        "top3_loss_share": float(losses[:3].sum() / losses.sum()),
        "rows_with_loss_over_1": int((losses > 1.0).sum()),
    }


def confusion_counts(y: np.ndarray, predicted: np.ndarray) -> dict[str, int]:
    return {
        "tp": int(((predicted == 1) & (y == 1)).sum()),
        "fn": int(((predicted == 0) & (y == 1)).sum()),
        "fp": int(((predicted == 1) & (y == 0)).sum()),
        "tn": int(((predicted == 0) & (y == 0)).sum()),
    }


def compare_on_validation(data: Dataset, split: Split) -> Comparison:
    """Fit every candidate on training rows, score on validation rows. Test rows are never read."""
    X_train, y_train = data.X[split.train], data.y[split.train]
    X_val, y_val = data.X[split.validation], data.y[split.validation]
    models, scores, train_loss = {}, {}, {}
    for name, build in CANDIDATES.items():
        model = build().fit(X_train, y_train)
        models[name] = model
        scores[name] = probability_scores(y_val, malignant_probability(model, X_val))
        train_loss[name] = float(log_loss(y_train, malignant_probability(model, X_train), labels=[0, 1]))
    return Comparison(models, scores, train_loss)


def select_by_log_loss(scores: dict[str, dict[str, float]]) -> str:
    return min(scores, key=lambda name: scores[name][SELECTION_METRIC])


def _record_hash(record: dict[str, Any]) -> str:
    body = {k: v for k, v in record.items() if k != "record_sha256"}
    return hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()


def freeze_selection(scores: dict[str, dict[str, float]], split: Split, path: Path) -> dict[str, Any]:
    record = {
        "selected_model": select_by_log_loss(scores),
        "selection_metric": f"validation {SELECTION_METRIC} (smaller is better)",
        "validation_scores": scores,
        "split_seed": split.seed,
        "dataset_sha256": split.dataset_sha256,
        "test_indices_sha256": hashlib.sha256(split.test.astype("<i8").tobytes()).hexdigest(),
    }
    record["record_sha256"] = _record_hash(record)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(record, indent=1, sort_keys=True) + "\n")
    return record


def _load_frozen(path: Path, split: Split) -> dict[str, Any]:
    record = json.loads(Path(path).read_text())
    if record.get("record_sha256") != _record_hash(record):
        raise ValueError("frozen selection was edited after it was written")
    test_hash = hashlib.sha256(split.test.astype("<i8").tobytes()).hexdigest()
    if (record["dataset_sha256"], record["split_seed"], record["test_indices_sha256"]) != (
        split.dataset_sha256,
        split.seed,
        test_hash,
    ):
        raise ValueError("frozen selection belongs to a different split")
    return record


def evaluate_frozen_choice_on_test(
    selection_path: Path, models: dict[str, Any], data: Dataset, split: Split
) -> dict[str, Any]:
    """Score only the frozen model on test rows. Nothing is refitted here."""
    chosen = _load_frozen(selection_path, split)["selected_model"]
    model = models[chosen]
    X_test, y_test = data.X[split.test], data.y[split.test]
    p = malignant_probability(model, X_test)
    predicted = (p >= THRESHOLD).astype(np.int64)
    return {
        "model": chosen,
        **probability_scores(y_test, p),
        "accuracy_at_0_5": float(accuracy_score(y_test, predicted)),
        "confusion_at_0_5": confusion_counts(y_test, predicted),
        "n_test": int(len(y_test)),
        "n_test_malignant": int(y_test.sum()),
    }
