"""The three candidates. Parameters are fixed up front and never tuned on these results."""

from lightgbm import LGBMClassifier
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

MODEL_SEED = 2023


def dummy_prior() -> DummyClassifier:
    return DummyClassifier(strategy="prior")


def logistic_regression() -> Pipeline:
    # The scaler sits inside the pipeline, so fit() learns mean/std from training rows only.
    return Pipeline(
        [("scaler", StandardScaler()), ("model", LogisticRegression(max_iter=1000))]
    )


def lightgbm() -> LGBMClassifier:
    return LGBMClassifier(
        n_estimators=200,
        learning_rate=0.05,
        num_leaves=15,
        min_child_samples=10,
        reg_lambda=1.0,
        random_state=MODEL_SEED,
        n_jobs=1,
        device_type="cpu",
        deterministic=True,
        force_col_wise=True,
        verbose=-1,
    )


CANDIDATES = {
    "dummy_prior": dummy_prior,
    "logistic_regression": logistic_regression,
    "lightgbm": lightgbm,
}
