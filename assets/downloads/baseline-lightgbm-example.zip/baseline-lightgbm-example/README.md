# A fair baseline for LightGBM — runnable example

Companion code for the article
[“A fair baseline for LightGBM: freeze the split before comparing models”](https://rafalpronko.github.io/blog/baseline-lightgbm/).

The example:

1. loads the Wisconsin Diagnostic Breast Cancer data **bundled with scikit-learn** (no download)
   and relabels it so that `1 = malignant`, `0 = benign`;
2. uses a stratified train / validation / test split (341 / 114 / 114 rows) saved as positional
   indices in `artifacts/split.json`, together with a SHA-256 digest of the data and the row-order
   contract;
3. fits three candidates on the training rows only — `DummyClassifier(strategy="prior")`,
   `StandardScaler` + `LogisticRegression` in one pipeline, and an `LGBMClassifier` with fixed
   parameters (CPU, one thread, `deterministic=True`, `force_col_wise=True`);
4. picks the candidate with the smallest **validation** log loss and freezes that choice in
   `results/selection.json`;
5. only then evaluates the frozen model **once** on the test rows.

This is a teaching example on a small public dataset. It is not a diagnostic tool and the numbers
say nothing about clinical use.

## Prerequisites

- [uv](https://docs.astral.sh/uv/) — a modern Python project tool used here to reproduce the
  environment. It is a present-day convenience, not something the 2023 article date implies.
  The run below was made with uv 0.7.8.
- Python 3.11. If it is not installed, `uv sync` can download a managed interpreter.
- Internet access for the first `uv sync` (package wheels or source archives from PyPI).
  The dataset itself is never downloaded; it ships inside scikit-learn.
- LightGBM needs an OpenMP runtime.
  - **macOS on Apple Silicon (arm64):** PyPI has no LightGBM 4.1.0 wheel for this platform, so
    uv builds it from the source archive. You need the Xcode Command Line Tools (`xcode-select --install`)
    and libomp (`brew install libomp`). CMake and Ninja are fetched automatically as build
    dependencies. The build takes a few minutes and only happens once per uv cache.
  - **macOS on Intel:** a wheel exists, but it still needs libomp (`brew install libomp`).
  - **Linux x86_64 / aarch64, Windows amd64:** wheels exist. On Linux the OpenMP runtime
    (`libgomp`) is usually already present.

## Pinned versions

| Package | Version | First PyPI upload |
|---|---|---|
| lightgbm | 4.1.0 | 2023-09-12 |
| scikit-learn | 1.3.2 | 2023-10-23 |
| numpy | 1.26.2 | 2023-11-12 |
| scipy | 1.11.4 | 2023-11-18 |
| pytest (dev) | 7.4.3 | 2023-10-24 |

`pyproject.toml` also sets `exclude-newer = "2023-11-23T00:00:00Z"` for uv, so transitive
dependencies (joblib, threadpoolctl, …) resolve to files that already existed on that date.
`uv.lock` pins every file hash.

## Run

```bash
uv sync --locked
uv run --locked pytest -v
uv run --locked python run_experiment.py
```

`artifacts/split.json` is part of the bundle. `run_experiment.py` refuses to run if the bundled
data no longer matches the digest stored in it, and checks that a fresh split with the same seed
gives the same indices. `freeze_split.py` is the script that created the file; it refuses to
overwrite an existing split.

Each run writes `results/selection.json` (the frozen choice, its validation scores, the split
digest and a hash of the record) and `results/test_result.json` (the single test evaluation).
Training log loss is printed for context only; it never enters the choice.

## Files

| Path | Role |
|---|---|
| `fair_baseline/data.py` | load data, `malignant = 1` mapping, data digest, ordering contract |
| `fair_baseline/split.py` | stratified split, save/load with digest check |
| `fair_baseline/models.py` | the three candidates with fixed parameters |
| `fair_baseline/selection.py` | validation comparison, frozen selection, single test evaluation |
| `freeze_split.py` | creates `artifacts/split.json` once |
| `run_experiment.py` | runs the steps in order and prints validation and test results |
| `tests/` | 22 tests: split coverage and reproducibility, digest, label mapping, training-only scaler, metric ranges, test isolation, frozen-record checks, repeatability, loss reporting |

## Verification status

Verified on 2026-10-12 on macOS 26.5.2 (arm64), CPython 3.11.12, uv 0.7.8, with LightGBM 4.1.0
built from source against Homebrew libomp 21.1.8: 22 tests passed, and two consecutive runs of
`run_experiment.py` produced identical output files. Expected output on that machine:

```text
TRAINING log loss (rows each model was fitted on; context only, not used for the choice)
  dummy_prior          log_loss=0.6602
  logistic_regression  log_loss=0.0349
  lightgbm             log_loss=0.0052

VALIDATION (used for the choice)
  dummy_prior          log_loss=0.6627  roc_auc=0.5000  max_row_loss=0.99  top3_share=0.039  rows_loss>1=0
  logistic_regression  log_loss=0.1188  roc_auc=0.9866  max_row_loss=6.33  top3_share=0.825  rows_loss>1=3
  lightgbm             log_loss=0.1082  roc_auc=0.9879  max_row_loss=5.38  top3_share=0.745  rows_loss>1=3

FROZEN choice: lightgbm

TEST (one evaluation of the frozen choice, reported, not used for any decision)
  lightgbm             log_loss=0.1775  roc_auc=0.9821  accuracy@0.5=0.9211  n=114
                       max_row_loss=5.87  top3_share=0.536  rows_loss>1=5  confusion@0.5={'tp': 38, 'fn': 4, 'fp': 5, 'tn': 67}
```

Other operating systems, CPUs and compilers were not tested. `deterministic=True` asks LightGBM
for stable results with the same data, parameters and build; its documentation says results are
still expected to differ across LightGBM versions, compilers and systems. Small differences in the
last decimals elsewhere are therefore possible. The tests check repeatability on one machine, not
bitwise equality across platforms.

## Data

Breast Cancer Wisconsin (Diagnostic). W. Wolberg, O. Mangasarian, N. Street, W. Street.
UCI Machine Learning Repository, 1995. <https://doi.org/10.24432/C5DW2B>. Licensed CC BY 4.0.
The copy used here is the one bundled with scikit-learn (`sklearn.datasets.load_breast_cancer`).
