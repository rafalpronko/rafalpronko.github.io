"""Create artifacts/split.json once, before any model is trained. Refuses to overwrite."""

import sys
from pathlib import Path

from fair_baseline.data import load_dataset
from fair_baseline.split import make_split, save_split

SPLIT_PATH = Path(__file__).resolve().parent / "artifacts" / "split.json"


def main() -> int:
    if SPLIT_PATH.exists():
        print(f"{SPLIT_PATH.name} already exists; a frozen split is not regenerated")
        return 1
    split = make_split(load_dataset())
    save_split(split, SPLIT_PATH)
    print(f"wrote {SPLIT_PATH.name}: seed={split.seed} dataset_sha256={split.dataset_sha256}")
    print(f"train={len(split.train)} validation={len(split.validation)} test={len(split.test)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
