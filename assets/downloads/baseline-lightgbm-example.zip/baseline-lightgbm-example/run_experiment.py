"""Run the whole experiment in a fixed order.

1. Load the bundled data and check its digest against the frozen split (see freeze_split.py).
2. Fit three candidates on training rows, score them on validation rows.
3. Freeze the choice (smallest validation log loss) in results/selection.json.
4. Only then evaluate the frozen model once on the test rows.
"""

import json
import sys
from pathlib import Path

from fair_baseline.data import dataset_digest, load_dataset
from fair_baseline.selection import compare_on_validation, evaluate_frozen_choice_on_test, freeze_selection
from fair_baseline.split import load_split, make_split

HERE = Path(__file__).resolve().parent
SPLIT_PATH = HERE / "artifacts" / "split.json"
RESULTS = HERE / "results"


def frozen_split(data):
    if not SPLIT_PATH.exists():
        raise SystemExit("artifacts/split.json is missing; run freeze_split.py first")
    split = load_split(SPLIT_PATH, data)  # raises if the data digest changed
    if split != make_split(data, seed=split.seed):
        raise SystemExit("frozen split differs from a fresh split with the same seed")
    return split


def main() -> int:
    data = load_dataset()
    split = frozen_split(data)
    print(f"dataset_sha256 {dataset_digest(data)}")
    print(f"rows train={len(split.train)} validation={len(split.validation)} test={len(split.test)}")
    print(f"malignant train={data.y[split.train].sum()} validation={data.y[split.validation].sum()} "
          f"test={data.y[split.test].sum()}")

    comparison = compare_on_validation(data, split)
    print("\nTRAINING log loss (rows each model was fitted on; context only, not used for the choice)")
    for name, loss in comparison.train_log_loss.items():
        print(f"  {name:<20} log_loss={loss:.4f}")
    print("\nVALIDATION (used for the choice)")
    for name, s in comparison.scores.items():
        print(f"  {name:<20} log_loss={s['log_loss']:.4f}  roc_auc={s['roc_auc']:.4f}  "
              f"max_row_loss={s['max_row_loss']:.2f}  top3_share={s['top3_loss_share']:.3f}  "
              f"rows_loss>1={s['rows_with_loss_over_1']}")

    selection = freeze_selection(comparison.scores, split, RESULTS / "selection.json")
    print(f"\nFROZEN choice: {selection['selected_model']} (record_sha256 {selection['record_sha256'][:16]}...)")

    result = evaluate_frozen_choice_on_test(RESULTS / "selection.json", comparison.models, data, split)
    (RESULTS / "test_result.json").write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print("\nTEST (one evaluation of the frozen choice, reported, not used for any decision)")
    print(f"  {result['model']:<20} log_loss={result['log_loss']:.4f}  roc_auc={result['roc_auc']:.4f}  "
          f"accuracy@0.5={result['accuracy_at_0_5']:.4f}  n={result['n_test']}")
    print(f"  {'':<20} max_row_loss={result['max_row_loss']:.2f}  top3_share={result['top3_loss_share']:.3f}  "
          f"rows_loss>1={result['rows_with_loss_over_1']}  confusion@0.5={result['confusion_at_0_5']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
