import json
import math

import numpy as np
import pytest

from fair_baseline.data import load_dataset
from fair_baseline.models import CANDIDATES
from fair_baseline.selection import (
    compare_on_validation,
    evaluate_frozen_choice_on_test,
    freeze_selection,
    select_by_log_loss,
)
from fair_baseline.split import make_split


@pytest.fixture(scope="module")
def data():
    return load_dataset()


@pytest.fixture(scope="module")
def split(data):
    return make_split(data)


@pytest.fixture(scope="module")
def comparison(data, split):
    return compare_on_validation(data, split)


def test_candidates_are_the_three_planned_models():
    assert list(CANDIDATES) == ["dummy_prior", "logistic_regression", "lightgbm"]


def test_lightgbm_parameters_are_fixed_single_thread_and_deterministic():
    params = CANDIDATES["lightgbm"]().get_params()
    assert params["n_jobs"] == 1
    assert params["deterministic"] is True
    assert params["force_col_wise"] is True
    assert params["device_type"] == "cpu"


def test_scaler_is_fitted_on_training_rows_only(data, split, comparison):
    scaler = comparison.models["logistic_regression"].named_steps["scaler"]
    assert np.allclose(scaler.mean_, data.X[split.train].mean(axis=0))
    assert not np.allclose(scaler.mean_, data.X.mean(axis=0))


def test_validation_metrics_are_finite_and_in_range(comparison):
    for name, scores in comparison.scores.items():
        assert math.isfinite(scores["log_loss"]) and scores["log_loss"] > 0, name
        assert 0.0 <= scores["roc_auc"] <= 1.0, name


def test_prior_dummy_has_no_ranking_ability(comparison):
    assert comparison.scores["dummy_prior"]["roc_auc"] == 0.5


def test_selection_uses_smallest_validation_log_loss():
    scores = {"a": {"log_loss": 0.30}, "b": {"log_loss": 0.10}, "c": {"log_loss": 0.20}}
    assert select_by_log_loss(scores) == "b"


def test_test_rows_cannot_influence_selection(data, split, comparison):
    poisoned_X = data.X.copy()
    poisoned_X[split.test] = np.nan
    poisoned_y = data.y.copy()
    poisoned_y[split.test] = 1 - poisoned_y[split.test]
    poisoned = data._replace(X=poisoned_X, y=poisoned_y)
    assert compare_on_validation(poisoned, split).scores == comparison.scores


def test_repeated_comparison_gives_identical_scores(data, split, comparison):
    assert compare_on_validation(data, split).scores == comparison.scores


class _Untouchable:
    def __getattr__(self, name):
        raise AssertionError(f"non-selected model was used: {name}")


def test_only_the_frozen_choice_is_evaluated_on_test(data, split, comparison, tmp_path):
    path = tmp_path / "selection.json"
    freeze_selection(comparison.scores, split, path)
    chosen = json.loads(path.read_text())["selected_model"]
    models = {name: _Untouchable() for name in comparison.models}
    models[chosen] = comparison.models[chosen]
    result = evaluate_frozen_choice_on_test(path, models, data, split)
    assert result["model"] == chosen
    assert math.isfinite(result["log_loss"]) and result["log_loss"] > 0
    assert 0.0 <= result["roc_auc"] <= 1.0
    assert 0.0 <= result["accuracy_at_0_5"] <= 1.0


def test_test_evaluation_refuses_an_edited_selection(data, split, comparison, tmp_path):
    path = tmp_path / "selection.json"
    freeze_selection(comparison.scores, split, path)
    record = json.loads(path.read_text())
    record["selected_model"] = "dummy_prior" if record["selected_model"] != "dummy_prior" else "lightgbm"
    path.write_text(json.dumps(record))
    with pytest.raises(ValueError, match="selection"):
        evaluate_frozen_choice_on_test(path, comparison.models, data, split)


def test_test_evaluation_refuses_a_selection_from_another_split(data, split, comparison, tmp_path):
    path = tmp_path / "selection.json"
    freeze_selection(comparison.scores, split, path)
    other = make_split(data, seed=split.seed + 1)
    with pytest.raises(ValueError, match="split"):
        evaluate_frozen_choice_on_test(path, comparison.models, data, other)


def test_loss_profile_shows_how_concentrated_the_loss_is(comparison):
    for name, scores in comparison.scores.items():
        assert scores["max_row_loss"] >= scores["log_loss"], name
        assert 0.0 < scores["top3_loss_share"] <= 1.0, name
        assert 0 <= scores["rows_with_loss_over_1"] <= 114, name


def test_test_result_reports_confusion_counts_at_fixed_threshold(data, split, comparison, tmp_path):
    path = tmp_path / "selection.json"
    freeze_selection(comparison.scores, split, path)
    result = evaluate_frozen_choice_on_test(path, comparison.models, data, split)
    counts = result["confusion_at_0_5"]
    assert set(counts) == {"tp", "fn", "fp", "tn"}
    assert sum(counts.values()) == result["n_test"]
    assert counts["tp"] + counts["fn"] == result["n_test_malignant"]
    assert (counts["tp"] + counts["tn"]) / result["n_test"] == result["accuracy_at_0_5"]


def test_training_loss_is_reported_separately_from_validation(data, split, comparison):
    prevalence = data.y[split.train].mean()
    entropy = -(prevalence * math.log(prevalence) + (1 - prevalence) * math.log(1 - prevalence))
    assert math.isclose(comparison.train_log_loss["dummy_prior"], entropy, rel_tol=1e-12)
    for name, loss in comparison.train_log_loss.items():
        assert math.isfinite(loss) and loss > 0, name
        assert "train_log_loss" not in comparison.scores[name]  # never mixed into selection scores
