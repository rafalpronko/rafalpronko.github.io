import json
from pathlib import Path

import numpy as np
import pytest

from fair_baseline.data import MALIGNANT, dataset_digest, load_dataset
from fair_baseline.split import SPLIT_SEED, load_split, make_split, save_split

FROZEN_SPLIT = Path(__file__).resolve().parents[1] / "artifacts" / "split.json"


def test_malignant_is_explicitly_mapped_to_one():
    data = load_dataset()
    assert MALIGNANT == 1
    assert data.y.shape == (569,)
    assert set(np.unique(data.y)) == {0, 1}
    assert int(data.y.sum()) == 212  # malignant cases in the bundled data
    assert int((data.y == 0).sum()) == 357  # benign cases


def test_mapping_inverts_the_original_sklearn_target():
    from sklearn.datasets import load_breast_cancer

    original = load_breast_cancer().target  # 0 = malignant, 1 = benign
    assert np.array_equal(load_dataset().y, (original == 0).astype(np.int64))


def test_data_digest_is_stable_and_order_sensitive():
    data = load_dataset()
    assert dataset_digest(data) == dataset_digest(load_dataset())
    swapped = data.X.copy()
    swapped[[0, 1]] = swapped[[1, 0]]
    assert dataset_digest(data._replace(X=swapped)) != dataset_digest(data)


def test_split_is_disjoint_and_covers_every_row():
    split = make_split(load_dataset())
    parts = [split.train, split.validation, split.test]
    joined = np.concatenate(parts)
    assert len(joined) == 569
    assert np.array_equal(np.sort(joined), np.arange(569))
    for i, a in enumerate(parts):
        for b in parts[i + 1 :]:
            assert np.intersect1d(a, b).size == 0
    assert (len(split.train), len(split.validation), len(split.test)) == (341, 114, 114)


def test_split_is_stratified():
    data = load_dataset()
    split = make_split(data)
    overall = data.y.mean()
    for idx in (split.train, split.validation, split.test):
        assert abs(data.y[idx].mean() - overall) < 0.01


def test_split_is_reproducible_and_matches_frozen_file():
    data = load_dataset()
    first, second = make_split(data), make_split(data)
    assert first == second
    assert load_split(FROZEN_SPLIT, data) == first
    assert first.seed == SPLIT_SEED


def test_saved_split_records_digest_and_ordering_contract(tmp_path):
    data = load_dataset()
    path = tmp_path / "split.json"
    save_split(make_split(data), path)
    record = json.loads(path.read_text())
    assert record["dataset_sha256"] == dataset_digest(data)
    assert "positional" in record["ordering_contract"]
    assert load_split(path, data) == make_split(data)


def test_loading_split_rejects_different_data(tmp_path):
    data = load_dataset()
    path = tmp_path / "split.json"
    save_split(make_split(data), path)
    shuffled = data._replace(X=data.X[::-1].copy(), y=data.y[::-1].copy())
    with pytest.raises(ValueError, match="digest"):
        load_split(path, shuffled)
