"""Backfills, late data and schema changes on a SQLite revision ledger.

Synthetic demo for Python 3.11+ and SQLite 3.24+; standard library only.
"""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from collections.abc import Iterable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone

NORMALIZER_VERSION = "orders-normalizer/1"
MAX_BACKFILL_DAYS = 31
SQLITE_INT_MIN = -(2**63)
SQLITE_INT_MAX = 2**63 - 1
# Synthetic, explicitly documented contract: only this v1 source is single-currency.
V1_CURRENCY_CONTRACTS = {"legacy-pl": "PLN"}
CURRENCY_CODE = re.compile(r"[A-Z]{3}")

SCHEMA = """
CREATE TABLE raw_revisions (
    source TEXT NOT NULL, entity_id TEXT NOT NULL, version INTEGER NOT NULL,
    schema_version INTEGER NOT NULL, payload TEXT NOT NULL,
    payload_sha256 TEXT NOT NULL, first_observed_at TEXT NOT NULL,
    PRIMARY KEY (source, entity_id, version));
CREATE TABLE normalized_revisions (
    source TEXT NOT NULL, entity_id TEXT NOT NULL, version INTEGER NOT NULL,
    event_time TEXT NOT NULL, event_day TEXT NOT NULL,
    amount_minor INTEGER, currency TEXT, normalizer_version TEXT NOT NULL,
    PRIMARY KEY (source, entity_id, version),
    FOREIGN KEY (source, entity_id, version) REFERENCES raw_revisions);
CREATE TABLE rejected_records (
    id INTEGER PRIMARY KEY, source TEXT NOT NULL, schema_version_json TEXT NOT NULL,
    payload TEXT NOT NULL, observed_at TEXT NOT NULL, reason TEXT NOT NULL);
CREATE TABLE dirty_days (day TEXT PRIMARY KEY);
CREATE TABLE daily_revenue (
    day TEXT NOT NULL, currency TEXT NOT NULL,
    amount_minor INTEGER NOT NULL, orders INTEGER NOT NULL,
    PRIMARY KEY (day, currency));
CREATE TABLE daily_partitions (
    day TEXT PRIMARY KEY, orders INTEGER NOT NULL,
    missing_amount INTEGER NOT NULL, missing_currency INTEGER NOT NULL,
    transformation_version TEXT NOT NULL);
"""

# Latest accepted version per (source, entity_id); no window functions needed.
CURRENT = """
SELECT n.* FROM normalized_revisions n
WHERE n.version = (SELECT MAX(m.version) FROM normalized_revisions m
                   WHERE m.source = n.source AND m.entity_id = n.entity_id)
"""


class RejectedRecord(ValueError):
    """A record we refuse to normalize; its payload goes to rejected_records."""


@dataclass(frozen=True)
class RawRecord:
    source: str
    schema_version: int
    payload: str  # kept byte-for-byte as received


@dataclass(frozen=True)
class Revision:
    entity_id: str
    version: int
    event_time: datetime  # aware, UTC
    amount_minor: int | None  # None means unknown, never zero
    currency: str | None  # None means unknown


def connect(path: str = ":memory:") -> sqlite3.Connection:
    con = sqlite3.connect(path, isolation_level=None)  # we issue BEGIN ourselves
    con.execute("PRAGMA foreign_keys = ON")
    con.executescript(SCHEMA)
    return con


@contextmanager
def transaction(con: sqlite3.Connection) -> Iterator[None]:
    con.execute("BEGIN IMMEDIATE")
    try:
        yield
        con.execute("COMMIT")
    except BaseException:
        if con.in_transaction:
            con.execute("ROLLBACK")
        raise


def utc_text(moment: datetime) -> str:
    if moment.tzinfo is None:
        raise ValueError(f"naive datetime is ambiguous: {moment!r}")
    return moment.astimezone(timezone.utc).isoformat(timespec="microseconds")


def parse_event_time(value: object) -> datetime:
    if not isinstance(value, str):
        raise RejectedRecord("event_time must be an ISO 8601 string")
    try:
        moment = datetime.fromisoformat(value)
    except ValueError as exc:
        raise RejectedRecord(f"event_time is not ISO 8601: {value!r}") from exc
    if moment.tzinfo is None:
        raise RejectedRecord(f"event_time has no UTC offset: {value!r}")
    return moment.astimezone(timezone.utc)


def sqlite_int(value: object, field: str) -> int:
    """Reject unsupported integers before binding, so quarantine keeps the payload."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise RejectedRecord(f"{field} must be an integer")
    if not SQLITE_INT_MIN <= value <= SQLITE_INT_MAX:
        raise RejectedRecord(f"{field} is outside the signed SQLite 64-bit range")
    return value


def optional_int(body: dict[str, object], field: str) -> int | None:
    value = body.get(field)
    if value is None:
        return None  # missing means unknown, not zero
    return sqlite_int(value, field)


def entity_key(body: dict[str, object]) -> tuple[str, int]:
    entity_id = body.get("order_id")
    if not isinstance(entity_id, str) or not entity_id:
        raise RejectedRecord("order_id must be a non-empty string")
    version = sqlite_int(body.get("version"), "version")
    if version < 1:
        raise RejectedRecord("version must be a positive integer")
    return entity_id, version


def money_v1(source: str, body: dict[str, object]) -> tuple[int | None, str | None]:
    # v1 never carried a currency; only an explicit source contract may supply one.
    return optional_int(body, "amount_cents"), V1_CURRENCY_CONTRACTS.get(source)


def money_v2(source: str, body: dict[str, object]) -> tuple[int | None, str | None]:
    currency = body.get("currency")
    if currency is not None and not (
        isinstance(currency, str) and CURRENCY_CODE.fullmatch(currency)
    ):
        raise RejectedRecord(f"currency must be a 3-letter code: {currency!r}")
    return optional_int(body, "amount_minor"), currency


MONEY_BY_SCHEMA = {1: money_v1, 2: money_v2}


def parse(record: RawRecord) -> Revision:
    if not isinstance(record.schema_version, int) or isinstance(record.schema_version, bool):
        raise RejectedRecord("schema_version must be an integer")  # True == 1, 2.0 == 2
    money = MONEY_BY_SCHEMA.get(record.schema_version)
    if money is None:
        raise RejectedRecord(f"unknown schema_version {record.schema_version!r}")
    try:
        body = json.loads(record.payload)
    except json.JSONDecodeError as exc:
        raise RejectedRecord("payload is not valid JSON") from exc
    if not isinstance(body, dict):
        raise RejectedRecord("payload must be a JSON object")
    entity_id, version = entity_key(body)
    amount, currency = money(record.source, body)
    return Revision(entity_id, version, parse_event_time(body.get("event_time")),
                    amount, currency)


def fingerprint(record: RawRecord) -> str:
    canonical = json.dumps([record.schema_version, json.loads(record.payload)],
                           sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def mark_dirty(con: sqlite3.Connection, days: Iterable[str]) -> None:
    con.executemany("INSERT INTO dirty_days (day) VALUES (?) "
                    "ON CONFLICT (day) DO NOTHING", [(day,) for day in days])


def current_day(con: sqlite3.Connection, source: str, entity_id: str) -> list[str]:
    row = con.execute("SELECT event_day FROM normalized_revisions WHERE source = ? "
                      "AND entity_id = ? ORDER BY version DESC LIMIT 1",
                      (source, entity_id)).fetchone()
    return [] if row is None else [row[0]]


def store(con: sqlite3.Connection, record: RawRecord, rev: Revision,
          observed: str) -> bool:
    key = (record.source, rev.entity_id, rev.version)
    digest = fingerprint(record)
    row = con.execute("SELECT payload_sha256 FROM raw_revisions WHERE source = ? "
                      "AND entity_id = ? AND version = ?", key).fetchone()
    if row is not None:
        if row[0] != digest:
            raise RejectedRecord(f"conflicting payload for existing revision {key}")
        return False  # canonical-fingerprint replay: keep the first observation
    new_day = rev.event_time.date().isoformat()
    mark_dirty(con, current_day(con, record.source, rev.entity_id) + [new_day])
    con.execute("INSERT INTO raw_revisions VALUES (?, ?, ?, ?, ?, ?, ?)",
                (*key, record.schema_version, record.payload, digest, observed))
    con.execute("INSERT INTO normalized_revisions VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (*key, utc_text(rev.event_time), new_day, rev.amount_minor,
                 rev.currency, NORMALIZER_VERSION))
    return True


def quarantine(con: sqlite3.Connection, record: RawRecord, observed: str,
               reason: str) -> None:
    # JSON text keeps any rejected schema_version, even one SQLite INTEGER cannot hold.
    con.execute("INSERT INTO rejected_records (source, schema_version_json, payload, "
                "observed_at, reason) VALUES (?, ?, ?, ?, ?)",
                (record.source, json.dumps(record.schema_version), record.payload,
                 observed, reason))


def ingest(con: sqlite3.Connection, record: RawRecord, observed_at: datetime) -> bool:
    """Append a revision. True: new revision; False: canonical-fingerprint replay."""
    observed = utc_text(observed_at)
    try:
        revision = parse(record)
        with transaction(con):
            return store(con, record, revision, observed)
    except RejectedRecord as exc:
        quarantine(con, record, observed, str(exc))
        raise


def rebuild_day(con: sqlite3.Connection, day: str, transformation: str) -> None:
    con.execute("DELETE FROM daily_revenue WHERE day = ?", (day,))
    con.execute("DELETE FROM daily_partitions WHERE day = ?", (day,))
    con.execute(f"""INSERT INTO daily_revenue
        SELECT event_day, currency, SUM(amount_minor), COUNT(*) FROM ({CURRENT})
        WHERE event_day = ? AND amount_minor IS NOT NULL AND currency IS NOT NULL
        GROUP BY event_day, currency""", (day,))
    con.execute(f"""INSERT INTO daily_partitions
        SELECT ?, COUNT(*), COALESCE(SUM(amount_minor IS NULL), 0),
               COALESCE(SUM(currency IS NULL), 0), ?
        FROM ({CURRENT}) WHERE event_day = ?""", (day, transformation, day))
    con.execute("DELETE FROM dirty_days WHERE day = ?", (day,))


def rebuild(con: sqlite3.Connection, days: Iterable[str], transformation: str) -> list[str]:
    """Rebuild every given UTC day in one all-or-nothing transaction."""
    ordered = sorted(set(days))
    with transaction(con):
        for day in ordered:
            rebuild_day(con, day, transformation)
    return ordered


def backfill_days(start: date, end: date) -> list[str]:
    """UTC calendar days in the half-open range [start, end)."""
    if isinstance(start, datetime) or isinstance(end, datetime):
        raise TypeError("backfill bounds are calendar dates, not datetimes")
    span = (end - start).days
    if not 0 < span <= MAX_BACKFILL_DAYS:
        raise ValueError(f"backfill must cover 1..{MAX_BACKFILL_DAYS} days, got {span}")
    return [(start + timedelta(days=offset)).isoformat() for offset in range(span)]


def incremental_days(con: sqlite3.Connection, today: date, lookback: int) -> list[str]:
    """Recent event-time window plus every day invalidated by late data."""
    window = {(today - timedelta(days=offset)).isoformat() for offset in range(lookback)}
    dirty = {day for (day,) in con.execute("SELECT day FROM dirty_days")}
    return sorted(window | dirty)


def current_state(con: sqlite3.Connection) -> list[tuple[object, ...]]:
    return con.execute(f"""SELECT source, entity_id, version, event_day, amount_minor,
        currency FROM ({CURRENT}) ORDER BY source, entity_id""").fetchall()


def state_known_at(con: sqlite3.Connection, as_of: datetime) -> list[tuple[object, ...]]:
    """Latest version per entity among revisions this pipeline had observed by as_of."""
    return con.execute("""
        SELECT n.source, n.entity_id, n.version, n.event_day, n.amount_minor, n.currency
        FROM normalized_revisions n JOIN raw_revisions r USING (source, entity_id, version)
        WHERE r.first_observed_at <= :t AND n.version = (
            SELECT MAX(m.version) FROM normalized_revisions m
            JOIN raw_revisions q USING (source, entity_id, version)
            WHERE m.source = n.source AND m.entity_id = n.entity_id
              AND q.first_observed_at <= :t)
        ORDER BY n.source, n.entity_id""", {"t": utc_text(as_of)}).fetchall()


def history(con: sqlite3.Connection, source: str, entity_id: str) -> list[tuple[object, ...]]:
    return con.execute("""SELECT r.version, r.schema_version, n.event_day, n.amount_minor,
        n.currency, r.first_observed_at FROM raw_revisions r
        JOIN normalized_revisions n USING (source, entity_id, version)
        WHERE source = ? AND entity_id = ? ORDER BY r.version""",
                       (source, entity_id)).fetchall()


def snapshot(con: sqlite3.Connection) -> dict[str, list[tuple[object, ...]]]:
    return {table: sorted(con.execute(f"SELECT * FROM {table}"))
            for table in ("daily_revenue", "daily_partitions", "dirty_days")}


def make_record(source: str, schema_version: int, **body: object) -> RawRecord:
    return RawRecord(source, schema_version, json.dumps(body))


def at(text: str) -> datetime:
    return datetime.fromisoformat(text)


def check(ok: bool, name: str) -> None:
    if not ok:
        raise AssertionError(f"FAIL: {name}")
    print(f"PASS: {name}")


def expect_rejected(con: sqlite3.Connection, raw: RawRecord, observed: datetime) -> str:
    try:
        ingest(con, raw, observed)
    except RejectedRecord as exc:
        return str(exc)
    raise AssertionError(f"FAIL: record was accepted: {raw}")


OBSERVED_FIRST = at("2024-04-02T06:00:00+00:00")
FIRST_LOAD = [
    make_record("shop", 1, order_id="A-1", version=1, amount_cents=1000,
                event_time="2024-04-01T10:00:00+02:00"),
    make_record("legacy-pl", 1, order_id="L-1", version=1, amount_cents=500,
                event_time="2024-04-01T01:30:00+02:00"),
    make_record("shop", 2, order_id="B-1", version=1, amount_minor=2500,
                currency="EUR", event_time="2024-04-01T12:00:00+00:00"),
    make_record("shop", 2, order_id="B-2", version=1, currency="EUR",
                event_time="2024-04-01T13:00:00+00:00"),
]
LATE = make_record("shop", 2, order_id="C-1", version=1, amount_minor=700,
                   currency="EUR", event_time="2024-03-25T09:00:00+00:00")
CORRECTION = make_record("shop", 2, order_id="A-1", version=2, amount_minor=1200,
                         currency="PLN", event_time="2024-03-31T23:50:00+00:00")
CONFLICT = make_record("shop", 2, order_id="B-1", version=1, amount_minor=9999,
                       currency="EUR", event_time="2024-04-01T12:00:00+00:00")
UNKNOWN_SCHEMA = make_record("shop", 3, order_id="D-1", version=1)


def partition(con: sqlite3.Connection, day: str) -> tuple[object, ...] | None:
    return con.execute("SELECT * FROM daily_partitions WHERE day = ?", (day,)).fetchone()


def first_load(con: sqlite3.Connection) -> None:
    for raw in FIRST_LOAD:
        ingest(con, raw, OBSERVED_FIRST)
    rebuild(con, incremental_days(con, date(2024, 4, 2), lookback=2), "daily/1")
    check(partition(con, "2024-03-31") == ("2024-03-31", 1, 0, 0, "daily/1"),
          "01:30+02:00 lands in the 2024-03-31 UTC partition")
    check(partition(con, "2024-04-01") == ("2024-04-01", 3, 1, 1, "daily/1"),
          "missing amount and v1 currency are counted as unknown, not zero")
    replays = [ingest(con, raw, at("2024-04-03T06:00:00+00:00")) for raw in FIRST_LOAD]
    check(replays == [False] * len(FIRST_LOAD), "canonical-fingerprint replay adds no revisions")


def late_data(con: sqlite3.Connection) -> None:
    ingest(con, LATE, at("2024-04-12T08:00:00+00:00"))
    ingest(con, CORRECTION, at("2024-04-12T08:05:00+00:00"))
    days = rebuild(con, incremental_days(con, date(2024, 4, 12), lookback=2), "daily/1")
    check({"2024-03-25", "2024-03-31", "2024-04-01"} <= set(days),
          "late data and the moved correction rebuild old and new days")
    check(partition(con, "2024-04-01") == ("2024-04-01", 2, 1, 0, "daily/1"),
          "the corrected order left its old day")


def bad_input(con: sqlite3.Connection) -> None:
    for raw in (CONFLICT, UNKNOWN_SCHEMA):
        print("rejected:", expect_rejected(con, raw, at("2024-04-12T09:00:00+00:00")))
    check(con.execute("SELECT COUNT(*) FROM rejected_records").fetchone() == (2,),
          "rejected payloads are preserved for inspection")
    check(history(con, "shop", "B-1")[0][3] == 2500, "the accepted revision is untouched")


def backfill(con: sqlite3.Connection) -> None:
    days = backfill_days(date(2024, 3, 25), date(2024, 4, 13))
    rebuild(con, days, "daily/2")
    before = snapshot(con)
    rebuild(con, days, "daily/2")
    check(snapshot(con) == before, "same snapshot and logic produce identical backfill output")
    check(con.execute("SELECT COUNT(*) FROM daily_partitions WHERE "
                      "transformation_version = 'daily/2'").fetchone() == (len(days),),
          "every day in [2024-03-25, 2024-04-13) carries the requested transformation label")


def report(con: sqlite3.Connection) -> None:
    print("A-1 history:", history(con, "shop", "A-1"))
    print("known on 2024-04-05:", state_known_at(con, at("2024-04-05T00:00:00+00:00")))
    print("current state:", current_state(con))
    for row in con.execute("SELECT * FROM daily_revenue ORDER BY day, currency"):
        print("daily_revenue:", row)


def main() -> None:
    con = connect()
    try:
        first_load(con)
        late_data(con)
        bad_input(con)
        backfill(con)
        report(con)
    finally:
        con.close()


if __name__ == "__main__":
    main()
