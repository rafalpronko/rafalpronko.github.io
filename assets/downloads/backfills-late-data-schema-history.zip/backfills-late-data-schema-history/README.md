# Backfills, late data and schema changes: runnable example

Companion code for the article
[Backfills, late data and schema changes without silently losing history](https://rafalpronko.github.io/blog/backfills-late-data-schema-history/).

A synthetic SQLite revision ledger in one standard-library Python file. It keeps raw
revisions, normalizes two schema versions without inventing values, quarantines rejected
payloads, marks the UTC days that late data invalidates and rebuilds a bounded backfill
range in one transaction. The database lives in memory; nothing is written to disk.

## Files

| File | Purpose |
| --- | --- |
| `backfill_demo.py` | The complete example, identical to the code shown in the article. Standard library only. |
| `tests/test_article_excerpt.py` | The tests shown in the article. |
| `tests/test_backfill_demo.py` | The rest of the test suite. |
| `pyproject.toml`, `uv.lock`, `.python-version` | Pinned test tooling for reproduction with `uv`. |

## Run with uv (reproduces the recorded results)

From this directory:

```sh
uv run --frozen --isolated --python 3.11 python backfill_demo.py
uv run --frozen --isolated --python 3.11 python -m pytest
```

`--frozen` uses the committed `uv.lock` without updating it. `--isolated` runs in a
temporary environment, so no `.venv` is created here. Expected results: the demo prints
9 `PASS` lines and exits with `0`; pytest reports `63 passed` and exits with `0`.

## Run without uv

The demo needs only Python 3.11 or newer:

```sh
python3.11 backfill_demo.py
```

The tests need pytest:

```sh
python3.11 -m pip install pytest
python3.11 -m pytest
```

## Modern tooling disclosure

The article carries the editorial date 18 April 2024. The code uses only APIs available
in Python 3.11.0 (released 24 October 2022) and SQLite 3.24.0 (released 4 June 2018).
The recorded runs are a modern reproduction from 12 October 2026 with CPython 3.11.12,
SQLite 3.47.1, uv 0.7.8 and pytest 9.1.1 from `uv.lock`. uv itself was first released
on 15 February 2024 as a pip replacement, but its project-management commands used here
(`uv run` with a `uv.lock` lockfile) arrived on 20 August 2024, after the editorial date
([uv](https://astral.sh/blog/uv),
[uv: Unified Python packaging](https://astral.sh/blog/uv-unified-python-packaging)).
uv 0.7.8, these commands and pytest 9.1.1 are modern reproduction tooling, not part of
the example.

All data is synthetic. The example demonstrates semantics on an in-memory database. It
says nothing about process crashes, disk failures or concurrent writers.
