from __future__ import annotations

import json
import sqlite3
from collections.abc import Iterator
from datetime import date, datetime

import pytest

import backfill_demo as demo
from backfill_demo import RawRecord, RejectedRecord, at, make_record

T0 = at("2024-04-02T06:00:00+00:00")
T1 = at("2024-04-12T08:00:00+00:00")


@pytest.fixture
def con() -> Iterator[sqlite3.Connection]:
    connection = demo.connect()
    yield connection
    connection.close()


def order(entity_id: str, version: int, event_time: str, **money: object) -> RawRecord:
    return make_record("shop", 2, order_id=entity_id, version=version,
                       event_time=event_time, **money)


def eur(entity_id: str, version: int, event_time: str, amount: int) -> RawRecord:
    return order(entity_id, version, event_time, amount_minor=amount, currency="EUR")


def count(con: sqlite3.Connection, table: str) -> int:
    return con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]


def dirty(con: sqlite3.Connection) -> set[str]:
    return {day for (day,) in con.execute("SELECT day FROM dirty_days")}


def test_v1_currency_is_unknown_without_a_source_contract(con: sqlite3.Connection) -> None:
    demo.ingest(con, make_record("shop", 1, order_id="A", version=1, amount_cents=100,
                                 event_time="2024-04-01T10:00:00+00:00"), T0)
    demo.ingest(con, make_record("legacy-pl", 1, order_id="L", version=1,
                                 amount_cents=100,
                                 event_time="2024-04-01T10:00:00+00:00"), T0)
    currencies = {row[0]: row[5] for row in demo.current_state(con)}
    assert currencies == {"shop": None, "legacy-pl": "PLN"}


def test_missing_amount_is_unknown_not_zero(con: sqlite3.Connection) -> None:
    demo.ingest(con, order("A", 1, "2024-04-01T10:00:00+00:00", currency="EUR"), T0)
    demo.ingest(con, eur("B", 1, "2024-04-01T11:00:00+00:00", 300), T0)
    demo.rebuild(con, ["2024-04-01"], "t/1")
    assert con.execute("SELECT * FROM daily_revenue").fetchall() == [
        ("2024-04-01", "EUR", 300, 1)]
    assert demo.partition(con, "2024-04-01") == ("2024-04-01", 2, 1, 0, "t/1")


def test_unknown_schema_is_rejected_loudly_and_quarantined(con: sqlite3.Connection) -> None:
    raw = make_record("shop", 3, order_id="A", version=1)
    with pytest.raises(RejectedRecord, match="unknown schema_version 3"):
        demo.ingest(con, raw, T0)
    assert count(con, "raw_revisions") == 0
    assert con.execute("SELECT payload FROM rejected_records").fetchall() == [(raw.payload,)]


def ledger(con: sqlite3.Connection) -> dict[str, list[tuple[object, ...]]]:
    return {table: sorted(con.execute(f"SELECT * FROM {table}"))
            for table in ("raw_revisions", "normalized_revisions", "dirty_days")}


@pytest.mark.parametrize(("schema_version", "reason"), [
    (3, "unknown schema_version 3"),
    (2**63 - 1, f"unknown schema_version {2**63 - 1}"),
    (-(2**63), f"unknown schema_version {-(2**63)}"),
    (2**63, f"unknown schema_version {2**63}"),
    (-(2**63) - 1, f"unknown schema_version {-(2**63) - 1}"),
    (10**30, f"unknown schema_version {10**30}"),
    (True, "schema_version must be an integer"),
    (False, "schema_version must be an integer"),
    (2.0, "schema_version must be an integer"),
    ("2", "schema_version must be an integer"),
])
def test_rejected_schema_metadata_is_quarantined_losslessly(
        con: sqlite3.Connection, schema_version: object, reason: str) -> None:
    demo.ingest(con, eur("A", 1, "2024-04-01T10:00:00+00:00", 100), T0)
    before = ledger(con)
    raw = RawRecord("shop", schema_version,  # type: ignore[arg-type]
                    '{ "order_id": "B", "version": 1, "amount_cents": 5,\n'
                    '  "amount_minor": 5, "currency": "EUR",\n'
                    '  "event_time": "2024-04-01T11:00:00+00:00" }\n')
    with pytest.raises(RejectedRecord) as rejected:
        demo.ingest(con, raw, T1)
    assert str(rejected.value) == reason
    assert con.execute("SELECT source, schema_version_json, payload, reason "
                       "FROM rejected_records").fetchall() == [
        ("shop", json.dumps(schema_version), raw.payload, reason)]
    assert ledger(con) == before
    assert not con.in_transaction


@pytest.mark.parametrize("money", [{"amount_minor": "12"}, {"amount_minor": True},
                                   {"currency": "eur"}])
def test_wrong_types_are_rejected(con: sqlite3.Connection, money: dict[str, object]) -> None:
    with pytest.raises(RejectedRecord):
        demo.ingest(con, order("A", 1, "2024-04-01T10:00:00+00:00", **money), T0)
    assert count(con, "raw_revisions") == 0


def test_naive_times_are_refused(con: sqlite3.Connection) -> None:
    with pytest.raises(RejectedRecord, match="no UTC offset"):
        demo.ingest(con, eur("A", 1, "2024-04-01T10:00:00", 1), T0)
    with pytest.raises(ValueError, match="naive"):
        demo.ingest(con, eur("A", 1, "2024-04-01T10:00:00+00:00", 1),
                    datetime(2024, 4, 2, 6, 0))


def test_conflicting_equal_version_is_rejected_and_original_kept(
        con: sqlite3.Connection) -> None:
    demo.ingest(con, eur("A", 1, "2024-04-01T10:00:00+00:00", 100), T0)
    with pytest.raises(RejectedRecord, match="conflicting payload"):
        demo.ingest(con, eur("A", 1, "2024-04-01T10:00:00+00:00", 999), T1)
    assert demo.history(con, "shop", "A") == [
        (1, 2, "2024-04-01", 100, "EUR", "2024-04-02T06:00:00.000000+00:00")]
    assert count(con, "rejected_records") == 1


def test_canonical_fingerprint_replay_keeps_first_observed_time(con: sqlite3.Connection) -> None:
    raw = eur("A", 1, "2024-04-01T10:00:00+00:00", 100)
    assert demo.ingest(con, raw, T0) is True
    reordered = RawRecord(raw.source, raw.schema_version,
                          '{"currency": "EUR", "amount_minor": 100, "version": 1, '
                          '"event_time": "2024-04-01T10:00:00+00:00", "order_id": "A"}')
    assert demo.ingest(con, reordered, T1) is False
    assert con.execute("SELECT first_observed_at FROM raw_revisions").fetchall() == [
        ("2024-04-02T06:00:00.000000+00:00",)]


def test_late_lower_version_is_kept_but_does_not_win(con: sqlite3.Connection) -> None:
    demo.ingest(con, eur("A", 2, "2024-04-01T10:00:00+00:00", 200), T0)
    demo.ingest(con, eur("A", 1, "2024-04-01T09:00:00+00:00", 100), T1)
    assert [row[0] for row in demo.history(con, "shop", "A")] == [1, 2]
    assert demo.current_state(con)[0][2:5] == (2, "2024-04-01", 200)


def test_utc_partition_uses_converted_time(con: sqlite3.Connection) -> None:
    demo.ingest(con, eur("A", 1, "2024-04-01T01:30:00+02:00", 100), T0)
    assert dirty(con) == {"2024-03-31"}


def test_late_arrival_outside_lookback_is_still_rebuilt(con: sqlite3.Connection) -> None:
    demo.ingest(con, eur("A", 1, "2024-03-25T10:00:00+00:00", 100), T1)
    days = demo.incremental_days(con, date(2024, 4, 12), lookback=2)
    assert days == ["2024-03-25", "2024-04-11", "2024-04-12"]
    demo.rebuild(con, days, "t/1")
    assert dirty(con) == set()
    assert demo.partition(con, "2024-03-25") == ("2024-03-25", 1, 0, 0, "t/1")


def test_correction_moving_days_invalidates_both(con: sqlite3.Connection) -> None:
    demo.ingest(con, eur("A", 1, "2024-04-01T10:00:00+00:00", 100), T0)
    demo.rebuild(con, ["2024-04-01"], "t/1")
    demo.ingest(con, eur("A", 2, "2024-03-31T23:50:00+00:00", 120), T1)
    assert dirty(con) == {"2024-03-31", "2024-04-01"}
    demo.rebuild(con, dirty(con), "t/1")
    assert demo.partition(con, "2024-04-01") == ("2024-04-01", 0, 0, 0, "t/1")
    assert con.execute("SELECT * FROM daily_revenue").fetchall() == [
        ("2024-03-31", "EUR", 120, 1)]


def test_known_at_differs_from_current_state(con: sqlite3.Connection) -> None:
    demo.ingest(con, eur("A", 1, "2024-04-01T10:00:00+00:00", 100), T0)
    demo.ingest(con, eur("A", 2, "2024-04-01T10:00:00+00:00", 120), T1)
    assert demo.state_known_at(con, at("2024-04-05T00:00:00+00:00"))[0][2] == 1
    assert demo.state_known_at(con, at("2024-04-01T00:00:00+00:00")) == []
    assert demo.current_state(con)[0][2] == 2


def test_stored_times_keep_fixed_width_utc_microseconds(con: sqlite3.Connection) -> None:
    demo.ingest(con, eur("A", 1, "2024-04-01T01:30:00.123456+02:00", 100),
                at("2024-04-02T08:00:00.654321+02:00"))
    assert con.execute("SELECT event_time, event_day FROM normalized_revisions").fetchall() == [
        ("2024-03-31T23:30:00.123456+00:00", "2024-03-31")]
    assert con.execute("SELECT first_observed_at FROM raw_revisions").fetchall() == [
        ("2024-04-02T06:00:00.654321+00:00",)]
    assert demo.utc_text(T0) == "2024-04-02T06:00:00.000000+00:00"


@pytest.mark.parametrize(("schema", "field"), [(1, "amount_cents"), (2, "amount_minor")])
@pytest.mark.parametrize("value", [-(2**63), 2**63 - 1])
def test_sqlite_integer_amount_boundaries_are_accepted(
        con: sqlite3.Connection, schema: int, field: str, value: int) -> None:
    raw = make_record("shop", schema, order_id="A", version=1,
                      event_time="2024-04-01T10:00:00+00:00", **{field: value})
    assert demo.ingest(con, raw, T0) is True
    assert demo.current_state(con)[0][4] == value
    assert count(con, "rejected_records") == 0


@pytest.mark.parametrize("version", [1, 2**63 - 1])
def test_sqlite_positive_version_boundaries_are_accepted(
        con: sqlite3.Connection, version: int) -> None:
    assert demo.ingest(con, eur("A", version, "2024-04-01T10:00:00+00:00", 100), T0)
    assert demo.current_state(con)[0][2] == version


@pytest.mark.parametrize("version", [-(2**63), -1, 0])
def test_nonpositive_version_is_quarantined(con: sqlite3.Connection, version: int) -> None:
    raw = eur("A", version, "2024-04-01T10:00:00+00:00", 100)
    with pytest.raises(RejectedRecord, match="version"):
        demo.ingest(con, raw, T0)
    assert con.execute("SELECT payload FROM rejected_records").fetchall() == [(raw.payload,)]


@pytest.mark.parametrize(("start", "end"), [
    (date(2024, 4, 2), date(2024, 4, 2)),
    (date(2024, 4, 3), date(2024, 4, 2)),
    (date(2024, 1, 1), date(2024, 3, 1)),
])
def test_backfill_range_is_bounded(start: date, end: date) -> None:
    with pytest.raises(ValueError):
        demo.backfill_days(start, end)


def test_backfill_range_is_half_open_and_rejects_datetimes() -> None:
    assert demo.backfill_days(date(2024, 3, 30), date(2024, 4, 2)) == [
        "2024-03-30", "2024-03-31", "2024-04-01"]
    with pytest.raises(TypeError):
        demo.backfill_days(datetime(2024, 3, 30), datetime(2024, 4, 2))


def test_backfill_replay_is_idempotent(con: sqlite3.Connection) -> None:
    demo.ingest(con, eur("A", 1, "2024-04-01T10:00:00+00:00", 100), T0)
    days = demo.backfill_days(date(2024, 3, 31), date(2024, 4, 3))
    demo.rebuild(con, days, "t/2")
    first = demo.snapshot(con)
    demo.rebuild(con, days, "t/2")
    assert demo.snapshot(con) == first
    assert {row[4] for row in first["daily_partitions"]} == {"t/2"}
    assert len(first["daily_partitions"]) == 3


def test_failed_backfill_rolls_back_everything(con: sqlite3.Connection,
                                               monkeypatch: pytest.MonkeyPatch) -> None:
    demo.ingest(con, eur("A", 1, "2024-04-01T10:00:00+00:00", 100), T0)
    demo.ingest(con, eur("B", 1, "2024-04-02T10:00:00+00:00", 200), T0)
    demo.rebuild(con, ["2024-04-01"], "t/1")
    demo.ingest(con, eur("A", 2, "2024-04-01T10:00:00+00:00", 150), T1)
    before = demo.snapshot(con)
    original = demo.rebuild_day

    def fail_on_second_day(c: sqlite3.Connection, day: str, transformation: str) -> None:
        if day == "2024-04-02":
            raise RuntimeError("simulated crash mid-backfill")
        original(c, day, transformation)

    monkeypatch.setattr(demo, "rebuild_day", fail_on_second_day)
    with pytest.raises(RuntimeError):
        demo.rebuild(con, demo.backfill_days(date(2024, 4, 1), date(2024, 4, 3)), "t/2")
    assert demo.snapshot(con) == before
    assert not con.in_transaction


def test_main_runs_end_to_end(capsys: pytest.CaptureFixture[str]) -> None:
    demo.main()
    out = capsys.readouterr().out
    assert "FAIL" not in out
    assert out.count("PASS:") == 9


def test_automatic_rollback_preserves_original_database_error(con: sqlite3.Connection) -> None:
    demo.ingest(con, eur("A", 1, "2024-04-01T10:00:00+00:00", 100), T0)
    demo.rebuild(con, ["2024-04-01"], "t/1")
    before = demo.snapshot(con)
    con.execute("""CREATE TRIGGER fail_partition BEFORE INSERT ON daily_partitions
        BEGIN SELECT RAISE(ROLLBACK, 'forced automatic rollback'); END""")
    with pytest.raises(sqlite3.IntegrityError, match="forced automatic rollback"):
        demo.rebuild(con, ["2024-04-01"], "t/2")
    assert not con.in_transaction
    assert demo.snapshot(con) == before
