import json
import sqlite3
from collections.abc import Iterator
from datetime import date, datetime

import pytest

import backfill_demo as demo


def eur(entity_id: str, version: int, event_time: str, amount: int) -> demo.RawRecord:
    return demo.make_record("shop", 2, order_id=entity_id, version=version,
                            event_time=event_time, amount_minor=amount, currency="EUR")


def observed(text: str) -> datetime:
    return demo.at(text)


@pytest.fixture
def connection() -> Iterator[sqlite3.Connection]:
    con = demo.connect()
    yield con
    con.close()


def test_late_arrival_outside_lookback_is_rebuilt() -> None:
    con = demo.connect()
    demo.ingest(con, eur("A", 1, "2024-03-25T10:00:00+00:00", 100),
                observed("2024-04-12T08:00:00+00:00"))
    days = demo.incremental_days(con, date(2024, 4, 12), lookback=2)
    assert days == ["2024-03-25", "2024-04-11", "2024-04-12"]
    demo.rebuild(con, days, "t/1")
    assert demo.partition(con, "2024-03-25") == ("2024-03-25", 1, 0, 0, "t/1")


def test_correction_invalidates_old_and_new_day() -> None:
    con = demo.connect()
    demo.ingest(con, eur("A", 1, "2024-04-01T10:00:00+00:00", 100),
                observed("2024-04-02T06:00:00+00:00"))
    demo.rebuild(con, ["2024-04-01"], "t/1")
    demo.ingest(con, eur("A", 2, "2024-03-31T23:50:00+00:00", 120),
                observed("2024-04-12T08:00:00+00:00"))
    days = demo.incremental_days(con, date(2024, 4, 12), lookback=1)
    assert days == ["2024-03-31", "2024-04-01", "2024-04-12"]
    demo.rebuild(con, days, "t/1")
    assert demo.partition(con, "2024-04-01") == ("2024-04-01", 0, 0, 0, "t/1")
    assert len(demo.history(con, "shop", "A")) == 2


def test_failed_backfill_leaves_no_partial_state(monkeypatch: pytest.MonkeyPatch) -> None:
    con = demo.connect()
    demo.ingest(con, eur("A", 1, "2024-04-01T10:00:00+00:00", 100),
                observed("2024-04-02T06:00:00+00:00"))
    demo.rebuild(con, ["2024-04-01"], "t/1")
    before = demo.snapshot(con)
    real_rebuild_day = demo.rebuild_day

    def crash_on_second_day(c, day: str, transformation: str) -> None:
        if day == "2024-04-02":
            raise RuntimeError("simulated crash")
        real_rebuild_day(c, day, transformation)

    monkeypatch.setattr(demo, "rebuild_day", crash_on_second_day)
    with pytest.raises(RuntimeError):
        demo.rebuild(con, demo.backfill_days(date(2024, 4, 1), date(2024, 4, 3)), "t/2")
    assert demo.snapshot(con) == before


@pytest.mark.parametrize(("cutoff", "versions"), [
    ("050000", []),
    ("100000", [1]),
    ("500000", [1]),
    ("899999", [1]),
    ("900000", [2]),
])
def test_known_at_never_includes_a_future_observation(
        connection: sqlite3.Connection, cutoff: str, versions: list[int]) -> None:
    demo.ingest(connection, eur("A", 1, "2024-04-01T10:00:00+00:00", 100),
                observed("2024-04-12T08:00:00.100000+00:00"))
    demo.ingest(connection, eur("A", 2, "2024-04-01T10:00:00+00:00", 120),
                observed("2024-04-12T08:00:00.900000+00:00"))
    rows = demo.state_known_at(
        connection, observed(f"2024-04-12T08:00:00.{cutoff}+00:00"))
    assert [row[2] for row in rows] == versions


def test_commit_failure_rolls_back_partitions_and_dirty_marks(
        connection: sqlite3.Connection) -> None:
    demo.ingest(connection, eur("A", 1, "2024-04-01T10:00:00+00:00", 100),
                observed("2024-04-02T06:00:00+00:00"))
    demo.rebuild(connection, ["2024-04-01"], "t/1")
    demo.ingest(connection, eur("A", 2, "2024-04-02T10:00:00+00:00", 120),
                observed("2024-04-12T08:00:00+00:00"))
    before = demo.snapshot(connection)
    denied_commits = []

    def deny_commit(action: int, arg1: str | None, arg2: str | None,
                    database: str | None, trigger: str | None) -> int:
        if action == sqlite3.SQLITE_TRANSACTION and arg1 == "COMMIT":
            denied_commits.append(arg1)
            return sqlite3.SQLITE_DENY
        return sqlite3.SQLITE_OK

    connection.set_authorizer(deny_commit)
    try:
        with pytest.raises(sqlite3.DatabaseError, match="not authorized"):
            demo.rebuild(connection, ["2024-04-01", "2024-04-02"], "t/2")
    finally:
        connection.set_authorizer(None)
    assert denied_commits == ["COMMIT"]
    assert not connection.in_transaction
    assert demo.snapshot(connection) == before
    # The same connection must be usable for a subsequent successful rebuild.
    demo.rebuild(connection, ["2024-04-01", "2024-04-02"], "t/2")
    assert demo.partition(connection, "2024-04-01") == ("2024-04-01", 0, 0, 0, "t/2")
    assert demo.partition(connection, "2024-04-02") == ("2024-04-02", 1, 0, 0, "t/2")


@pytest.mark.parametrize(("schema", "field"), [
    (1, "amount_cents"), (2, "amount_minor"), (2, "version"),
])
@pytest.mark.parametrize("value", [-(2**63) - 1, 2**63, True, False])
def test_unsupported_integers_preserve_the_original_payload_in_quarantine(
        connection: sqlite3.Connection, schema: int, field: str,
        value: int | bool) -> None:
    # Deliberate whitespace must survive quarantine as well as the numeric value.
    body = ('{ "order_id": "A", "version": 1, '
            '"event_time": "2024-04-01T10:00:00+00:00", "currency": "EUR" }')
    payload = json.loads(body)
    payload[field] = value
    raw = demo.RawRecord("shop", schema, json.dumps(payload, indent=2) + "\n")
    with pytest.raises(demo.RejectedRecord):
        demo.ingest(connection, raw, observed("2024-04-02T06:00:00+00:00"))
    assert connection.execute("SELECT payload FROM rejected_records").fetchall() == [
        (raw.payload,)]
    assert connection.execute("SELECT COUNT(*) FROM raw_revisions").fetchone() == (0,)
    assert connection.execute("SELECT COUNT(*) FROM normalized_revisions").fetchone() == (0,)
    assert connection.execute("SELECT COUNT(*) FROM dirty_days").fetchone() == (0,)
    assert not connection.in_transaction
