# TF-IDF + logistic regression vs a tiny embedding classifier

Companion code for "Text classification: TF-IDF versus a small embedding
model". Computation runs on CPU; no pretrained model or dataset downloads.

```bash
uv sync --locked
uv run --locked pytest -v
uv run --locked python -m textclf.run
```

Tested on **Apple Silicon macOS, CPython 3.12.11**, with torch 2.3.0,
scikit-learn 1.4.2 and numpy 1.26.4. The project requires CPython 3.11 or
3.12. The lock contains torch wheels for these platform families:

| platform | architecture | wheel availability, not installation testing |
|---|---|---|
| macOS | arm64 (Apple Silicon) | torch targets macOS 11+; pinned SciPy requires macOS 12+ |
| Linux with glibc | x86_64, aarch64 | no musl/Alpine torch wheel in this lock |
| Windows | x64 | no Windows arm64 torch wheel in this lock |

**Intel macOS is unsupported by this lock:** torch 2.3.0 has no macOS
x86_64 wheel here. Other platforms above were not executed in this session.
A wheel's presence does not verify the entire installation on that system.
On Linux x86_64, the locked PyPI build includes large CUDA dependencies even
though this example computes on CPU. These commands keep the supplied lock.

`pyproject.toml` sets `exclude-newer = "2024-05-09T00:00:00Z"`. Distribution
upload dates in `uv.lock` precede that cutoff; the interpreter is separate.
The editorial date is a label, while these executions took place in 2026.

## Layout

| file | purpose |
|---|---|
| `textclf/data.py` | seeded generator, exact deduplication, fixed stratified split |
| `textclf/text.py` | shared ASCII tokenizer: `[a-z0-9]+` |
| `textclf/tfidf_model.py` | train-only TF-IDF + logistic regression, validation grid |
| `textclf/embed_model.py` | train-only PAD/UNK vocabulary, masked mean, training |
| `textclf/report.py` | display rounding, UNK-only and empty-input diagnostics |
| `textclf/run.py` | tune both models, score test once each, print JSON |
| `tests/` | selection precision/ties, padding, UNK, preprocessing, split, seeds |

All selection uses full-precision validation macro-F1. Only strictly greater
scores replace an incumbent; exact ties retain the first grid candidate or
epoch. Rounding to four decimal places happens in displayed JSON only.
Training uses token-id batches, sorted label indices and cross-entropy on
raw logits; inference chooses the largest logit and maps it back to a label.

The JSON distinguishes UNK-only input (learned vector plus linear layer)
from empty input (zero pooled vector, bias-only logits). It reports all
UNK-only coordinates and logits, and separates stored parameter values from
updated values: the PAD row has zero gradient and stays zero in this setup.

## Evaluation and reproducibility limits

All splits share 40 templates and slot pools. Exact deduplication removes
identical strings but leaves near-duplicates; this is an in-generator teaching
comparison, not evidence of generalisation to new wording. For a stronger
holdout, group by template family before generation/splitting and evaluate
separately collected requests, with validation groups separate from test.

Repeated same-seed training produced bitwise-identical weights in the tested
process, versions and one-thread configuration. This is an observation, not
a guarantee across machines, releases or CPU/GPU. Timings are diagnostic
output; the earlier slow-run cause was not diagnosed. ASCII tokenisation
also truncates or drops non-ASCII letters (`café` becomes `caf`).
