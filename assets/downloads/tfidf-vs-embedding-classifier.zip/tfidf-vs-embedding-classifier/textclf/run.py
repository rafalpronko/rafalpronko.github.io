"""Run both models on a fixed split: uv run --locked python -m textclf.run."""

import json
import platform
import sys
import time
from collections import Counter

import numpy
import sklearn
import torch
from sklearn.metrics import accuracy_score, f1_score

from textclf import embed_model, tfidf_model
from textclf.data import fixed_split, generate
from textclf.report import (
    degenerate_report, display_selection, order_report, parameter_counts,
    probe_report, unk_only_report,
)


def scores(y_true: list[str], y_pred: list[str]) -> dict:
    return {
        "accuracy": round(accuracy_score(y_true, y_pred), 4),
        "macro_f1": round(f1_score(y_true, y_pred, average="macro"), 4),
    }


def environment() -> dict:
    return {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "numpy": numpy.__version__,
        "scikit_learn": sklearn.__version__,
        "torch": torch.__version__,
        "torch_threads": torch.get_num_threads(),
    }


def fit_report(tuner, split):
    start = time.perf_counter()
    model, best, grid = tuner(*split.train, *split.val)
    report = {
        "val_grid": [display_selection(row) for row in grid],
        "selected": display_selection(best),
        "tune_and_fit_seconds": round(time.perf_counter() - start, 2),
    }
    return model, report


def main() -> None:
    torch.set_num_threads(1)
    split = fixed_split(generate())
    tfidf, tfidf_info = fit_report(tfidf_model.tune, split)
    emb, emb_info = fit_report(embed_model.tune, split)
    # Score test once per model, after all validation choices are fixed.
    x_test, y_test = split.test
    tfidf_info["test"] = scores(y_test, tfidf.predict(x_test).tolist())
    emb_info["test"] = scores(y_test, emb.predict(x_test))
    emb_info["parameters"] = parameter_counts(emb)
    emb_info["unk_only"] = unk_only_report(emb)
    report = {
        "environment": environment(),
        "selection_policy": "Full-precision F1; exact ties retain first.",
        "data": {
            "train": len(split.train[0]), "val": len(split.val[0]),
            "test": len(x_test), "classes": len(set(split.train[1])),
            "label_counts": {
                name: dict(sorted(Counter(rows[1]).items()))
                for name, rows in vars(split).items()
            },
            "embedding_vocab_size_incl_pad_unk": len(emb.vocab),
            "tfidf_features": len(tfidf.named_steps["tfidf"].vocabulary_),
        },
        "tfidf_logreg": tfidf_info,
        "embedding_meanpool": emb_info,
        "probes_unseen_words": probe_report(tfidf, emb),
        "order_probe": order_report(tfidf, emb),
        "degenerate_inputs": degenerate_report(tfidf, emb),
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
