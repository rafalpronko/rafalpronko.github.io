"""Synthetic banking-style intent data and one fixed train/val/test split.

Everything here is generated from templates with a seeded RNG. It is a
teaching dataset, not a benchmark: real user text is messier, longer-tailed
and drifts over time.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from sklearn.model_selection import train_test_split

INTENTS: dict[str, list[str]] = {
    "check_balance": [
        "what is my {acct} balance",
        "how much money is in my {acct} account",
        "show me the balance of my {acct} account",
        "can you tell me my current balance",
        "balance on {acct} please",
    ],
    "transfer_money": [
        "send {amount} to my {acct} account",
        "transfer {amount} from {acct} to {acct2}",
        "move {amount} into {acct2}",
        "i want to send money to {person}",
        "pay {person} {amount}",
    ],
    "lost_card": [
        "i lost my {card} card",
        "my {card} card was stolen",
        "someone took my {card} card",
        "block my {card} card it is gone",
        "cannot find my {card} card anywhere",
    ],
    "activate_card": [
        "activate my new {card} card",
        "how do i activate the {card} card",
        "my {card} card arrived and needs activation",
        "turn on my new {card} card",
        "start using the {card} card i received",
    ],
    "change_address": [
        "update my home address",
        "i moved and need to change my address",
        "change the address on my {acct} account",
        "new address for my profile",
        "my address is wrong please fix it",
    ],
    "open_account": [
        "open a new {acct} account",
        "i want to create a {acct} account",
        "how do i open an account for {person}",
        "start a {acct} account for me",
        "sign me up for a {acct} account",
    ],
    "close_account": [
        "close my {acct} account",
        "i want to shut down my {acct} account",
        "cancel the {acct} account",
        "how do i close an account",
        "terminate my {acct} account please",
    ],
    "dispute_charge": [
        "i do not recognise a charge of {amount}",
        "there is a wrong payment on my {card} card",
        "dispute the {amount} transaction",
        "i was charged twice for {amount}",
        "refund an unknown {card} card payment",
    ],
}

SLOTS: dict[str, list[str]] = {
    "acct": ["checking", "savings", "joint", "business", "student"],
    "acct2": ["checking", "savings", "joint", "business", "student"],
    "card": ["debit", "credit", "visa", "mastercard", "virtual"],
    "amount": ["20 dollars", "100", "50 euros", "250", "1000 pounds", "15"],
    "person": ["mom", "john", "my landlord", "anna", "a friend"],
}

PREFIXES = ["", "", "", "hi ", "hello ", "hey ", "please ", "quick question "]
SUFFIXES = ["", "", "", " thanks", " asap", " today", " now", " thank you"]

# Hand-written probe sentences that use words the generator never emits.
# They show what a from-scratch model cannot know; they are NOT a test set.
PROBES: list[tuple[str, str]] = [
    ("i misplaced my plastic", "lost_card"),
    ("what are my remaining funds", "check_balance"),
    ("wire cash to my sister", "transfer_money"),
    ("i relocated last week", "change_address"),
    ("unfamiliar debit on my statement", "dispute_charge"),
    ("enable the replacement plastic", "activate_card"),
]


def _typo(word: str, rng: random.Random) -> str:
    """Swap two adjacent characters to create a realistic misspelling."""
    if len(word) < 4:
        return word
    i = rng.randrange(len(word) - 1)
    return word[:i] + word[i + 1] + word[i] + word[i + 2 :]


def _fill(template: str, rng: random.Random) -> str:
    values = {name: rng.choice(options) for name, options in SLOTS.items()}
    return template.format(**values)


def generate(
    n_per_intent: int = 220, typo_rate: float = 0.06, seed: int = 13,
) -> list[tuple[str, str]]:
    """Return de-duplicated (text, label) pairs.

    Exact deduplication does not remove shared templates or near-duplicates.
    """
    rng = random.Random(seed)
    seen: set[str] = set()
    rows: list[tuple[str, str]] = []
    for label, templates in INTENTS.items():
        for _ in range(n_per_intent):
            text = (
                rng.choice(PREFIXES) + _fill(rng.choice(templates), rng)
                + rng.choice(SUFFIXES)
            )
            words = [
                _typo(w, rng) if rng.random() < typo_rate else w
                for w in text.split()
            ]
            text = " ".join(words)
            if text not in seen:
                seen.add(text)
                rows.append((text, label))
    return rows


@dataclass(frozen=True)
class Split:
    train: tuple[list[str], list[str]]
    val: tuple[list[str], list[str]]
    test: tuple[list[str], list[str]]


def fixed_split(rows: list[tuple[str, str]], seed: int = 13) -> Split:
    """60/20/20 stratified split, shared by both models."""
    texts = [t for t, _ in rows]
    labels = [y for _, y in rows]
    x_train, x_rest, y_train, y_rest = train_test_split(
        texts, labels, test_size=0.4, stratify=labels, random_state=seed
    )
    x_val, x_test, y_val, y_test = train_test_split(
        x_rest, y_rest, test_size=0.5, stratify=y_rest, random_state=seed
    )
    return Split((x_train, y_train), (x_val, y_val), (x_test, y_test))
