"""TF-IDF + logistic regression baseline, tuned on the validation split."""

from __future__ import annotations

from itertools import product

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.pipeline import Pipeline

from textclf.text import tokenize

GRID = {"ngram_range": [(1, 1), (1, 2)], "C": [0.3, 3.0, 30.0]}


def build(ngram_range: tuple[int, int] = (1, 2), C: float = 3.0) -> Pipeline:
    """Fit the vectoriser and classifier on the same supplied texts."""
    return Pipeline([
        ("tfidf", TfidfVectorizer(
            tokenizer=tokenize,
            token_pattern=None,  # we supply our own tokenizer
            lowercase=False,     # tokenize() already lowercases
            ngram_range=ngram_range,
            sublinear_tf=True,
        )),
        ("clf", LogisticRegression(C=C, max_iter=2000)),
    ])


def tune(
    x_train: list[str], y_train: list[str],
    x_val: list[str], y_val: list[str],
):
    """Compare raw validation F1; exact ties retain the first candidate."""
    results = []
    for ngram_range, C in product(GRID["ngram_range"], GRID["C"]):
        model = build(ngram_range, C).fit(x_train, y_train)
        score = f1_score(y_val, model.predict(x_val), average="macro")
        results.append({
            "ngram_range": list(ngram_range),
            "C": C,
            "val_macro_f1": float(score),
        })
    best = max(results, key=lambda r: r["val_macro_f1"])
    model = build(tuple(best["ngram_range"]), best["C"]).fit(x_train, y_train)
    return model, best, results
