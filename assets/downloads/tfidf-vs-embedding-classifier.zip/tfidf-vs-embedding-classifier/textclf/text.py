"""Tokenisation shared by both models so they see the same tokens."""

from __future__ import annotations

import re

_TOKEN = re.compile(r"[a-z0-9]+")


def tokenize(text: str) -> list[str]:
    """Lowercase and keep ASCII letters/digits. Empty text -> []."""
    return _TOKEN.findall(text.lower())
