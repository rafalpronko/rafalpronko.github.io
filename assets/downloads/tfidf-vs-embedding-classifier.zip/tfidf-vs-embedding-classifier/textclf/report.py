"""Display rounding and diagnostics; no model selection happens here."""

import torch

from textclf.data import PROBES
from textclf.embed_model import UNK, Trained


def display_selection(row: dict) -> dict:
    """Round a copy only when constructing the displayed JSON report."""
    return {**row, "val_macro_f1": round(row["val_macro_f1"], 4)}


def probe_report(tfidf, emb: Trained) -> list[dict]:
    texts = [text for text, _ in PROBES]
    rows = []
    for (text, expected), a, b in zip(
        PROBES, tfidf.predict(texts), emb.predict(texts)
    ):
        ids = emb.vocab.encode(text)
        rows.append({
            "text": text, "expected": expected,
            "tfidf": str(a), "embedding": b,
            "embedding_unk_share": round(ids.count(UNK) / len(ids), 2),
        })
    return rows


@torch.no_grad()
def unk_only_report(emb: Trained) -> dict:
    """Expose the learned UNK vector separately from empty-input bias."""
    emb.model.eval()
    ids = torch.tensor([[UNK]], dtype=torch.long)
    pooled = emb.model.pooled(ids)
    logits = emb.model(ids)
    return {
        "token_ids": [UNK],
        "pooled_representation": pooled[0].tolist(),
        "logits": dict(zip(emb.labels, logits[0].tolist())),
        "prediction": emb.labels[int(logits[0].argmax())],
    }


@torch.no_grad()
def degenerate_report(tfidf, emb: Trained) -> dict:
    texts = ["", "zzz qqq"]
    vec, clf = tfidf.named_steps["tfidf"], tfidf.named_steps["clf"]
    return {
        "texts": texts,
        "tfidf_nonzero_features": [int(vec.transform([t]).nnz) for t in texts],
        "tfidf": tfidf.predict(texts).tolist(),
        "tfidf_intercept_argmax": str(tfidf.classes_[clf.intercept_.argmax()]),
        "embedding": emb.predict(texts),
        "embedding_token_ids": [emb.vocab.encode(t) for t in texts],
        "embedding_pooled": emb.model.pooled(emb.vocab.batch(texts)).tolist(),
        "embedding_bias_argmax": emb.labels[int(emb.model.out.bias.argmax())],
    }


@torch.no_grad()
def order_report(tfidf, emb: Trained) -> dict:
    a = "transfer 100 from savings to checking"
    b = "transfer 100 from checking to savings"
    la, lb = emb.model(emb.vocab.batch([a, b]))
    vec = tfidf.named_steps["tfidf"]
    return {
        "a": a, "b": b,
        "embedding_logits_allclose": bool(torch.allclose(la, lb)),
        "embedding_logits_max_abs_diff": float((la - lb).abs().max()),
        "tfidf_selected_ngram_range": list(vec.ngram_range),
        "tfidf_vectors_identical": bool(
            (vec.transform([a]) != vec.transform([b])).nnz == 0
        ),
    }


def parameter_counts(emb: Trained) -> dict:
    stored = sum(p.numel() for p in emb.model.parameters())
    frozen_pad = emb.model.embed.embedding_dim
    return {
        "stored": stored,
        "frozen_pad": frozen_pad,
        "updated": stored - frozen_pad,
    }
