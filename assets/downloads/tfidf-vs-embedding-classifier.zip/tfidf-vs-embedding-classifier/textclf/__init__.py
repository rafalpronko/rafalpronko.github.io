"""TF-IDF vs a small from-scratch embedding classifier on synthetic intents."""
