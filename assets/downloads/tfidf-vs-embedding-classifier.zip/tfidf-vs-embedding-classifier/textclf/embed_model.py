"""A tiny embedding classifier trained from scratch on CPU.

The embeddings are random at start and learned only from the training
split. They are NOT pretrained semantic vectors: a word the model never saw
in training has no meaning to it beyond the shared UNK vector.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass

import torch
from sklearn.metrics import f1_score
from torch import nn

from textclf.text import tokenize

PAD, UNK = 0, 1


class Vocab:
    """Token -> id map built from training texts only."""

    def __init__(self, train_texts: list[str], min_freq: int = 2):
        counts = Counter(tok for text in train_texts for tok in tokenize(text))
        # Tokens below min_freq map to UNK, so the UNK vector is actually
        # trained on rare words instead of staying at its random init.
        kept = sorted(tok for tok, c in counts.items() if c >= min_freq)
        self.itos = ["<pad>", "<unk>", *kept]
        self.stoi = {tok: i for i, tok in enumerate(self.itos)}

    def __len__(self) -> int:
        return len(self.itos)

    def encode(self, text: str) -> list[int]:
        return [self.stoi.get(tok, UNK) for tok in tokenize(text)]

    def batch(self, texts: list[str]) -> torch.Tensor:
        """Right-pad to the longest text. Empty text -> all PAD."""
        ids = [self.encode(t) for t in texts]
        width = max(1, max((len(x) for x in ids), default=0))
        out = torch.full((len(ids), width), PAD, dtype=torch.long)
        for row, seq in enumerate(ids):
            if seq:
                out[row, : len(seq)] = torch.tensor(seq)
        return out


class MeanPoolClassifier(nn.Module):
    """Embed tokens, average the non-padding ones, apply one linear layer."""

    def __init__(self, vocab_size: int, n_classes: int, dim: int = 32):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, dim, padding_idx=PAD)
        self.out = nn.Linear(dim, n_classes)

    def pooled(self, ids: torch.Tensor) -> torch.Tensor:
        mask = (ids != PAD).unsqueeze(-1).float()  # (B, T, 1)
        summed = (self.embed(ids) * mask).sum(dim=1)  # (B, D)
        count = mask.sum(dim=1).clamp(min=1.0)  # Avoid 0/0 for empty text.
        return summed / count  # Empty text -> zero vector.

    def forward(self, ids: torch.Tensor) -> torch.Tensor:
        return self.out(self.pooled(ids))


@dataclass
class Trained:
    model: MeanPoolClassifier
    vocab: Vocab
    labels: list[str]

    @torch.no_grad()
    def predict(self, texts: list[str]) -> list[str]:
        self.model.eval()
        logits = self.model(self.vocab.batch(texts))
        return [self.labels[i] for i in logits.argmax(dim=1).tolist()]


def _train_epoch(model, opt, x_ids, y_idx, gen, batch_size) -> None:
    """Minimise cross-entropy on shuffled training batches."""
    model.train()
    loss_fn = nn.CrossEntropyLoss()
    order = torch.randperm(len(y_idx), generator=gen)
    for start in range(0, len(order), batch_size):
        idx = order[start : start + batch_size]
        opt.zero_grad()
        loss = loss_fn(model(x_ids[idx]), y_idx[idx])
        loss.backward()
        opt.step()


def train(
    x_train: list[str],
    y_train: list[str],
    x_val: list[str],
    y_val: list[str],
    dim: int = 32,
    epochs: int = 30,
    lr: float = 0.01,
    batch_size: int = 32,
    seed: int = 0,
) -> tuple[Trained, dict]:
    """Compare raw validation F1; exact ties retain the first epoch."""
    if epochs < 1:
        raise ValueError("epochs must be positive")
    torch.manual_seed(seed)
    vocab = Vocab(x_train)
    labels = sorted(set(y_train))
    y_idx = torch.tensor([labels.index(y) for y in y_train])
    x_ids = vocab.batch(x_train)

    model = MeanPoolClassifier(len(vocab), len(labels), dim)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    gen = torch.Generator().manual_seed(seed)

    best = {"val_macro_f1": -1.0, "epoch": 0}
    best_state = None
    for epoch in range(1, epochs + 1):
        _train_epoch(model, opt, x_ids, y_idx, gen, batch_size)
        trained = Trained(model, vocab, labels)
        score = f1_score(y_val, trained.predict(x_val), average="macro")
        if score > best["val_macro_f1"]:
            best = {"val_macro_f1": float(score), "epoch": epoch}
            best_state = {k: v.clone() for k, v in model.state_dict().items()}

    model.load_state_dict(best_state)
    return Trained(model, vocab, labels), best


def tune(x_train, y_train, x_val, y_val, dims=(8, 32), seed: int = 0):
    """Compare raw validation F1; exact ties retain the first dimension."""
    results, best_run = [], None
    for dim in dims:
        trained, info = train(
            x_train, y_train, x_val, y_val, dim=dim, seed=seed
        )
        row = {"dim": dim, **info}
        results.append(row)
        if (
            best_run is None
            or row["val_macro_f1"] > best_run[1]["val_macro_f1"]
        ):
            best_run = (trained, row)
    return best_run[0], best_run[1], results
