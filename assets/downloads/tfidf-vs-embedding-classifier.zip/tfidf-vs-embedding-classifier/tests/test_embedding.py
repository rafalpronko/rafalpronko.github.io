import torch

from textclf.embed_model import PAD, UNK, MeanPoolClassifier, Vocab, train

TRAIN = [
    "lost my card", "lost my card", "my card",
    "balance please", "balance please", "rare",
]


def test_vocab_is_built_from_train_only_and_rare_words_map_to_unk():
    vocab = Vocab(TRAIN, min_freq=2)
    assert "card" in vocab.stoi and "balance" in vocab.stoi
    assert "rare" not in vocab.stoi                      # below min_freq
    assert vocab.encode("rare") == [UNK]
    assert vocab.encode("misplaced card") == [UNK, vocab.stoi["card"]]


def test_empty_text_becomes_single_pad_row_and_zero_vector():
    vocab = Vocab(TRAIN)
    ids = vocab.batch(["", "   ", "!!!"])
    assert ids.shape == (3, 1) and (ids == PAD).all()
    model = MeanPoolClassifier(len(vocab), 2, dim=4)
    pooled = model.pooled(ids)
    assert torch.isfinite(pooled).all()
    assert torch.equal(pooled, torch.zeros_like(pooled))
    # With a zero input, the logits are exactly the bias of the linear layer.
    assert torch.allclose(model(ids), model.out.bias.expand(3, -1))


def test_padding_does_not_change_the_output():
    vocab = Vocab(TRAIN)
    model = MeanPoolClassifier(len(vocab), 2, dim=4)
    short = vocab.batch(["my card"])
    padded = torch.cat([short, torch.full((1, 5), PAD)], dim=1)
    assert torch.allclose(model(short), model(padded))


def test_padding_row_starts_at_zero_and_receives_no_gradient():
    vocab = Vocab(TRAIN)
    model = MeanPoolClassifier(len(vocab), 2, dim=4)
    assert torch.equal(model.embed.weight[PAD], torch.zeros(4))
    model(vocab.batch(["my card", "balance"])).sum().backward()
    assert torch.equal(model.embed.weight.grad[PAD], torch.zeros(4))


def test_mean_pooling_is_order_insensitive():
    vocab = Vocab(["a b c d"] * 2, min_freq=1)
    model = MeanPoolClassifier(len(vocab), 2, dim=4)
    a, b = vocab.batch(["a b c d"]), vocab.batch(["d c b a"])
    assert torch.allclose(model(a), model(b))


def _tiny_data():
    x = ["lost my card", "card was stolen", "my balance", "show balance"] * 5
    y = ["lost", "lost", "bal", "bal"] * 5
    return x, y


def test_same_seed_same_process_is_bitwise_reproducible():
    x, y = _tiny_data()
    torch.set_num_threads(1)
    a, info_a = train(x, y, x, y, dim=4, epochs=3, seed=7)
    b, info_b = train(x, y, x, y, dim=4, epochs=3, seed=7)
    assert info_a == info_b
    for name, value in a.model.state_dict().items():
        assert torch.equal(value, b.model.state_dict()[name])


def test_different_seed_gives_different_weights():
    x, y = _tiny_data()
    a, _ = train(x, y, x, y, dim=4, epochs=1, seed=1)
    b, _ = train(x, y, x, y, dim=4, epochs=1, seed=2)
    assert not torch.equal(a.model.embed.weight, b.model.embed.weight)
