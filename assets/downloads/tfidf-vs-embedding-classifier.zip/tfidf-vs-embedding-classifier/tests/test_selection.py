"""Selection must compare raw F1 and retain the first exact tie."""

import pytest
import torch

from textclf import embed_model, tfidf_model

X = ["lost card", "lost card", "show balance", "show balance"]
Y = ["lost", "lost", "balance", "balance"]
HIGH, LOW = 0.99674, 0.99673  # Both display as 0.9967.


@pytest.mark.parametrize("later", [LOW, HIGH], ids=["worse", "exact-tie"])
def test_checkpoint_keeps_first_epoch_for_worse_or_equal_f1(
    monkeypatch, later
):
    torch.set_num_threads(1)
    monkeypatch.setattr(embed_model, "f1_score", lambda *a, **k: HIGH)
    first, _ = embed_model.train(X, Y, X, Y, dim=4, epochs=1, seed=7)
    scores = iter([HIGH, later])
    monkeypatch.setattr(
        embed_model, "f1_score", lambda *a, **k: next(scores)
    )
    selected, info = embed_model.train(X, Y, X, Y, dim=4, epochs=2, seed=7)
    assert info["epoch"] == 1
    assert info["val_macro_f1"] == HIGH
    for name, value in first.model.state_dict().items():
        assert torch.equal(value, selected.model.state_dict()[name])


CASES = [
    pytest.param([HIGH, LOW], 0, id="near-rounding-worse"),
    pytest.param([LOW, HIGH], 1, id="near-rounding-better"),
    pytest.param([HIGH, HIGH], 0, id="exact-tie"),
]


@pytest.mark.parametrize("scores, expected", CASES)
def test_tfidf_grid_uses_full_precision(monkeypatch, scores, expected):
    sequence = iter(scores)
    monkeypatch.setattr(
        tfidf_model, "GRID", {"ngram_range": [(1, 1)], "C": [0.3, 3.0]}
    )
    monkeypatch.setattr(
        tfidf_model, "f1_score", lambda *a, **k: next(sequence)
    )
    _, selected, grid = tfidf_model.tune(X, Y, X, Y)
    assert selected["C"] == [0.3, 3.0][expected]
    assert selected["val_macro_f1"] == scores[expected]
    assert [row["val_macro_f1"] for row in grid] == scores


@pytest.mark.parametrize("scores, expected", CASES)
def test_embedding_grid_uses_full_precision(monkeypatch, scores, expected):
    torch.set_num_threads(1)
    sequence = iter(scores)
    original_train = embed_model.train

    def one_epoch(*args, **kwargs):
        return original_train(*args, **kwargs, epochs=1)

    monkeypatch.setattr(embed_model, "train", one_epoch)
    monkeypatch.setattr(
        embed_model, "f1_score", lambda *a, **k: next(sequence)
    )
    trained, selected, grid = embed_model.tune(X, Y, X, Y, dims=(4, 8))
    assert selected["dim"] == [4, 8][expected]
    assert trained.model.embed.embedding_dim == selected["dim"]
    assert selected["val_macro_f1"] == scores[expected]
    assert [row["val_macro_f1"] for row in grid] == scores
