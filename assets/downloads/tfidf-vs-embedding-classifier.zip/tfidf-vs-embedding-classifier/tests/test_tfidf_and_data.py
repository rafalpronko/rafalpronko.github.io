from collections import Counter

import numpy as np

from textclf.data import fixed_split, generate
from textclf.text import tokenize
from textclf.tfidf_model import build

X = ["lost my card", "card stolen", "my balance", "show balance"]
Y = ["lost", "lost", "bal", "bal"]


def test_tokenize_handles_empty_and_punctuation():
    assert tokenize("") == []
    assert tokenize("!!!") == []
    assert tokenize("Lost MY card!") == ["lost", "my", "card"]
    assert tokenize("café Łódź") == ["caf", "d"]  # Deliberately ASCII only.


def test_tfidf_vocabulary_and_idf_come_from_fit_data_only():
    model = build(ngram_range=(1, 1)).fit(X, Y)
    vec = model.named_steps["tfidf"]
    idf_before = vec.idf_.copy()
    assert "misplaced" not in vec.vocabulary_
    # Transforming new text must not change the fitted statistics.
    vec.transform(["misplaced misplaced card", "totally new words"])
    assert np.array_equal(vec.idf_, idf_before)
    assert "misplaced" not in vec.vocabulary_


def test_unseen_and_empty_text_give_zero_vector_and_intercept_logits():
    model = build(ngram_range=(1, 1)).fit(X, Y)
    vec, clf = model.named_steps["tfidf"], model.named_steps["clf"]
    rows = vec.transform(["", "zzz qqq"])
    assert rows.nnz == 0
    assert np.allclose(clf.decision_function(rows), clf.intercept_)


def test_bigrams_see_local_order_unigrams_do_not():
    a, b = "from savings to checking", "from checking to savings"
    uni_model = build(ngram_range=(1, 1)).fit([a, b, "x"], ["t", "t", "o"])
    bi_model = build(ngram_range=(1, 2)).fit([a, b, "x"], ["t", "t", "o"])
    uni, bi = uni_model.named_steps["tfidf"], bi_model.named_steps["tfidf"]
    assert (uni.transform([a]) != uni.transform([b])).nnz == 0
    assert (bi.transform([a]) != bi.transform([b])).nnz > 0


def test_split_is_fixed_disjoint_and_stratified():
    rows = generate()
    s1, s2 = fixed_split(rows), fixed_split(rows)
    assert s1 == s2
    train, val, test = set(s1.train[0]), set(s1.val[0]), set(s1.test[0])
    assert not (train & val) and not (train & test) and not (val & test)
    assert set(s1.train[1]) == set(s1.test[1]) == set(s1.val[1])
    total = Counter(label for _, label in rows)
    for _, labels in (s1.train, s1.val, s1.test):
        actual = Counter(labels)
        for label, count in total.items():
            expected = len(labels) * count / len(rows)
            assert abs(actual[label] - expected) <= 1


def test_generator_is_deterministic_and_deduplicated():
    rows = generate()
    assert rows == generate()
    texts = [t for t, _ in rows]
    assert len(texts) == len(set(texts))
