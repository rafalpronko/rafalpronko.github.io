"""Unknown-only evidence must describe UNK, not empty-input bias."""

import torch

from textclf.embed_model import UNK, MeanPoolClassifier, Trained, Vocab
from textclf.report import display_selection, parameter_counts, unk_only_report


def test_display_rounding_leaves_raw_selection_unchanged():
    raw = {"val_macro_f1": 0.99674, "epoch": 1}
    assert display_selection(raw)["val_macro_f1"] == 0.9967
    assert raw["val_macro_f1"] == 0.99674


def test_unk_report_exposes_vector_logits_and_prediction():
    vocab = Vocab(["known known"])
    model = MeanPoolClassifier(len(vocab), 2, dim=2)
    with torch.no_grad():
        model.embed.weight[UNK].copy_(torch.tensor([1.0, -1.0]))
        model.out.weight.copy_(torch.eye(2))
        model.out.bias.copy_(torch.tensor([0.0, 3.0]))
    trained = Trained(model, vocab, ["a", "b"])
    report = unk_only_report(trained)
    assert report["token_ids"] == [UNK]
    assert report["pooled_representation"] == [1.0, -1.0]
    assert report["logits"] == {"a": 1.0, "b": 2.0}
    assert report["prediction"] == trained.predict(["zzz qqq"])[0] == "b"
    assert torch.equal(model.pooled(vocab.batch([""])), torch.zeros(1, 2))
    assert not torch.equal(
        model.pooled(vocab.batch([""])),
        model.pooled(vocab.batch(["zzz qqq"])),
    )


def test_parameter_counts_exclude_pad_from_updated_values():
    vocab = Vocab(["known known"])
    model = MeanPoolClassifier(len(vocab), 2, dim=2)
    trained = Trained(model, vocab, ["a", "b"])
    assert parameter_counts(trained) == {
        "stored": 12, "frozen_pad": 2, "updated": 10,
    }
