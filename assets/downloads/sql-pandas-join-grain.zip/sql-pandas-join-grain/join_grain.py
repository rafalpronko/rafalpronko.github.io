"""Grain, join keys and row multiplication in pandas (synthetic data)."""
import pandas as pd
from pandas.errors import MergeError

# Grain: one row per order line. Amounts are integer cents.
LINES = pd.DataFrame({
    "order_id": ["A", "A", "B", "C"],
    "line_no": [1, 2, 1, 1],
    "line_cents": [1000, 2000, 1500, 700],
})
# Grain: one row per payment. Order A was paid in three instalments.
PAYMENTS = pd.DataFrame({
    "order_id": ["A", "A", "A", "B", "D"],
    "payment_id": ["P1", "P2", "P3", "P4", "P5"],
    "paid_cents": [1000, 1000, 1000, 1500, 500],
})
# Intended grain: one row per order. This extract breaks it: order B
# arrived twice with conflicting customers, and order C is missing.
ORDERS = pd.DataFrame({
    "order_id": ["A", "B", "B", "D"],
    "customer_id": ["K1", "K2", "K3", "K4"],
})


def naive_line_payment_join() -> pd.DataFrame:
    """Join two independent child tables directly: the fan-out trap."""
    return LINES.merge(PAYMENTS, on="order_id", how="inner")


def order_balance() -> pd.DataFrame:
    """Aggregate both sides to one row per order, then join 1:1."""
    lines = LINES.groupby("order_id", as_index=False)["line_cents"].sum()
    paid = PAYMENTS.groupby("order_id", as_index=False)["paid_cents"].sum()
    result = lines.merge(paid, on="order_id", how="outer",
                         validate="one_to_one", indicator="coverage")
    amounts = ["line_cents", "paid_cents"]
    result[amounts] = result[amounts].fillna(0).astype("int64")
    result["open_cents"] = result["line_cents"] - result["paid_cents"]
    return result


def enrich_lines(how: str) -> pd.DataFrame:
    """Attach the customer to each line; the output grain should stay a line."""
    return LINES.merge(ORDERS, on="order_id", how=how, indicator=True)


def validate_message(mode: str) -> str:
    """Return pandas' verdict on a declared relationship for LINES x ORDERS."""
    try:
        LINES.merge(ORDERS, on="order_id", how="left", validate=mode)
    except MergeError as exc:
        return f"MergeError: {exc}"
    return "passed"


def main() -> None:
    fanout = naive_line_payment_join()
    print("rows per order, lines x payments:",
          fanout.groupby("order_id").size().to_dict())
    print("line cents: true", LINES["line_cents"].sum(),
          "| after join", fanout["line_cents"].sum())
    print("paid cents: true", PAYMENTS["paid_cents"].sum(),
          "| after join", fanout["paid_cents"].sum())

    print("\norder balance at order grain:")
    print(order_balance().to_string(index=False))

    inner, left = enrich_lines("inner"), enrich_lines("left")
    print("\nrows: lines", len(LINES), "| inner", len(inner),
          "| left", len(left))
    print("left coverage:", left["_merge"].value_counts().to_dict())
    print("rows per order, inner:", inner.groupby("order_id").size().to_dict())
    print("line cents after inner join:", inner["line_cents"].sum())

    for mode in ("many_to_one", "one_to_one"):
        print(f"validate={mode!r}:", validate_message(mode))


if __name__ == "__main__":
    main()
