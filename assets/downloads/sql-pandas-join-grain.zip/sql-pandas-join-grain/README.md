# Examples: joins, grain and row multiplication

Synthetic data only; amounts are integer cents. SQL dialect: SQLite via the
Python standard library `sqlite3` module.

| File | What it shows |
|---|---|
| `join_grain.py` | Main article example (pandas): 2×3 fan-out, pre-aggregation to order grain, inner vs left coverage, `validate`, `indicator`. |
| `sql_grain.py` | The same data in SQLite: fan-out, pre-aggregation, `DISTINCT` non-repair, `GROUP BY … HAVING` diagnostic, keys/constraints, temporal join. |
| `null_keys.py` | Null join keys: pandas `merge` matches them; SQL `=` does not, `IS` does. |
| `tests/` | 18 pytest tests asserting every output quoted in the article. |

Pinned: Python 3.11 (`.python-version`, `requires-python = "==3.11.*"`),
`pandas==2.2.1`, `numpy==1.26.4`, `pytest==8.1.1`; exact resolution in `uv.lock`.

From this directory (`--frozen` installs exactly what `uv.lock` records):

```bash
uv run --frozen python join_grain.py
uv run --frozen python sql_grain.py
uv run --frozen python null_keys.py
uv run --frozen pytest -v
```

uv is current reproduction tooling; it is not a claim about tooling at the
article's editorial date.
