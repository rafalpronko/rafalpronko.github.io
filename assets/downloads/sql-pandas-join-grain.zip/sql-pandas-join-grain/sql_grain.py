"""The same grain problems in SQL, using the SQLite bundled with Python."""
import sqlite3

from join_grain import LINES, ORDERS, PAYMENTS

# Staging tables deliberately have no keys: they hold the raw extracts.
STAGING = """
CREATE TABLE lines (order_id TEXT, line_no INTEGER, line_cents INTEGER);
CREATE TABLE payments (order_id TEXT, payment_id TEXT, paid_cents INTEGER);
CREATE TABLE orders_extract (order_id TEXT, customer_id TEXT);
"""

FANOUT = """
SELECT l.order_id, COUNT(*) AS joined_rows,
       SUM(l.line_cents) AS line_cents, SUM(p.paid_cents) AS paid_cents
FROM lines AS l JOIN payments AS p ON l.order_id = p.order_id
GROUP BY l.order_id ORDER BY l.order_id
"""

# Aggregate each child table to the order grain before joining.
BALANCE = """
WITH line_totals AS (
    SELECT order_id, SUM(line_cents) AS line_cents
    FROM lines GROUP BY order_id),
paid_totals AS (
    SELECT order_id, SUM(paid_cents) AS paid_cents
    FROM payments GROUP BY order_id),
all_orders AS (
    SELECT order_id FROM line_totals
    UNION SELECT order_id FROM paid_totals)
SELECT k.order_id,
       COALESCE(l.line_cents, 0) AS line_cents,
       COALESCE(p.paid_cents, 0) AS paid_cents,
       COALESCE(l.line_cents, 0) - COALESCE(p.paid_cents, 0) AS open_cents
FROM all_orders AS k
LEFT JOIN line_totals AS l ON l.order_id = k.order_id
LEFT JOIN paid_totals AS p ON p.order_id = k.order_id
ORDER BY k.order_id
"""

# Uniqueness diagnostic: which keys break the intended one-row-per-order grain?
DUPLICATE_KEYS = """
SELECT order_id, COUNT(*) AS n_rows,
       COUNT(DISTINCT customer_id) AS n_customers
FROM orders_extract
GROUP BY order_id
HAVING COUNT(*) > 1
ORDER BY order_id
"""

# A tempting "repair" of the fan-out: DISTINCT over the joined rows.
DISTINCT_REPAIR = """
SELECT SUM(paid_cents) FROM (
    SELECT DISTINCT p.order_id, p.paid_cents
    FROM lines AS l JOIN payments AS p ON l.order_id = p.order_id)
"""
DISTINCT_EXTRACT = "SELECT DISTINCT order_id, customer_id FROM orders_extract"

# Coverage: lines whose order is absent from the dimension.
UNMATCHED_LINES = """
SELECT l.order_id, l.line_no
FROM lines AS l LEFT JOIN orders_extract AS o ON o.order_id = l.order_id
WHERE o.order_id IS NULL
ORDER BY l.order_id, l.line_no
"""

# Target tables declare the grain, so the database enforces it.
TARGET = """
CREATE TABLE orders (
    order_id TEXT NOT NULL PRIMARY KEY,
    customer_id TEXT NOT NULL);
CREATE TABLE order_lines (
    order_id TEXT NOT NULL,
    line_no INTEGER NOT NULL,
    line_cents INTEGER NOT NULL CHECK (line_cents >= 0),
    PRIMARY KEY (order_id, line_no));
"""


# A temporal dimension: one row per customer *and validity interval*.
TEMPORAL = """
CREATE TABLE customer_segment (
    customer_id TEXT NOT NULL, segment TEXT NOT NULL,
    valid_from TEXT NOT NULL, valid_to TEXT NOT NULL,
    PRIMARY KEY (customer_id, valid_from));
INSERT INTO customer_segment VALUES
    ('K1', 'retail',   '2024-01-01', '2024-03-01'),
    ('K1', 'business', '2024-03-01', '9999-12-31');
CREATE TABLE dated_orders (order_id TEXT, customer_id TEXT, order_date TEXT);
INSERT INTO dated_orders VALUES ('A', 'K1', '2024-03-15');
"""
KEY_ONLY = """
SELECT o.order_id, s.segment FROM dated_orders AS o
JOIN customer_segment AS s ON s.customer_id = o.customer_id
ORDER BY s.valid_from
"""
AS_OF = """
SELECT o.order_id, s.segment FROM dated_orders AS o
JOIN customer_segment AS s ON s.customer_id = o.customer_id
 AND o.order_date >= s.valid_from AND o.order_date < s.valid_to
"""


def temporal_joins() -> tuple[list[tuple], list[tuple]]:
    """Join on the customer key alone, then on key plus validity interval."""
    con = sqlite3.connect(":memory:")
    try:
        con.executescript(TEMPORAL)
        return query(con, KEY_ONLY), query(con, AS_OF)
    finally:
        con.close()


def connect_staging() -> sqlite3.Connection:
    """Load the synthetic pandas frames into an in-memory SQLite database."""
    con = sqlite3.connect(":memory:")
    con.executescript(STAGING)
    for table, frame in (("lines", LINES), ("payments", PAYMENTS),
                         ("orders_extract", ORDERS)):
        rows = frame.astype(object).itertuples(index=False, name=None)
        marks = ", ".join("?" * frame.shape[1])
        con.executemany(f"INSERT INTO {table} VALUES ({marks})", rows)
    return con


def query(con: sqlite3.Connection, sql: str) -> list[tuple]:
    return con.execute(sql).fetchall()


def load_target(con: sqlite3.Connection) -> str:
    """Try to move the extract into a keyed table; report what happened."""
    con.executescript(TARGET)
    try:
        with con:
            con.execute("INSERT INTO orders SELECT * FROM orders_extract")
    except sqlite3.IntegrityError as exc:
        return f"IntegrityError: {exc}"
    return "loaded"


def main() -> None:
    print("SQLite library version:", sqlite3.sqlite_version)
    with connect_staging() as con:
        print("fan-out per order (order, rows, line, paid):", query(con, FANOUT))
        print("balance at order grain:", query(con, BALANCE))
        print("paid cents after DISTINCT 'repair':",
              query(con, DISTINCT_REPAIR))
        print("DISTINCT rows of the orders extract:",
              query(con, DISTINCT_EXTRACT))
        print("duplicate keys (order, rows, customers):",
              query(con, DUPLICATE_KEYS))
        print("lines without an order:", query(con, UNMATCHED_LINES))
        print("load into keyed table:", load_target(con))
        print("rows in keyed table after failed load:",
              query(con, "SELECT COUNT(*) FROM orders"))
    con.close()
    key_only, as_of = temporal_joins()
    print("temporal join on key only:", key_only)
    print("temporal join on key + interval:", as_of)


if __name__ == "__main__":
    main()
