import sqlite3

import pytest

from null_keys import (pandas_inner_rows, sqlite_null_comparisons,
                       sqlite_rows)
from sql_grain import (BALANCE, DISTINCT_EXTRACT, DISTINCT_REPAIR,
                       DUPLICATE_KEYS, FANOUT, TARGET, UNMATCHED_LINES,
                       connect_staging, load_target, query, temporal_joins)


@pytest.fixture
def con():
    connection = connect_staging()
    yield connection
    connection.close()


def test_sql_join_multiplies_like_pandas(con):
    assert query(con, FANOUT) == [("A", 6, 9000, 6000), ("B", 1, 1500, 1500)]


def test_sql_preaggregation_keeps_every_order(con):
    assert query(con, BALANCE) == [("A", 3000, 3000, 0), ("B", 1500, 1500, 0),
                                   ("C", 700, 0, 700), ("D", 0, 500, -500)]


def test_distinct_is_not_a_repair(con):
    # A and B were paid 3000 + 1500 = 4500; DISTINCT collapses A's three
    # genuine 1000-cent payments into one.
    assert query(con, DISTINCT_REPAIR) == [(2500,)]
    assert sorted(query(con, DISTINCT_EXTRACT)) == [
        ("A", "K1"), ("B", "K2"), ("B", "K3"), ("D", "K4")]


def test_group_by_having_finds_conflicting_duplicate(con):
    assert query(con, DUPLICATE_KEYS) == [("B", 2, 2)]
    assert query(con, UNMATCHED_LINES) == [("C", 1)]


def test_primary_key_rejects_extract_and_rolls_back(con):
    assert load_target(con) == (
        "IntegrityError: UNIQUE constraint failed: orders.order_id")
    assert query(con, "SELECT COUNT(*) FROM orders") == [(0,)]


def test_composite_key_allows_lines_but_not_repeated_line(con):
    con.executescript(TARGET)
    con.execute("INSERT INTO order_lines VALUES ('A', 1, 1000)")
    con.execute("INSERT INTO order_lines VALUES ('A', 2, 2000)")
    with pytest.raises(sqlite3.IntegrityError, match="UNIQUE constraint"):
        con.execute("INSERT INTO order_lines VALUES ('A', 1, 999)")


def test_sqlite_key_constraints_and_null():
    con = sqlite3.connect(":memory:")
    try:
        con.execute("CREATE TABLE u (k TEXT UNIQUE)")
        con.executemany("INSERT INTO u VALUES (?)", [(None,), (None,)])
        assert con.execute("SELECT COUNT(*) FROM u").fetchone() == (2,)
        con.execute("CREATE TABLE p (k TEXT PRIMARY KEY)")  # no NOT NULL
        con.execute("INSERT INTO p VALUES (NULL)")
        assert con.execute("SELECT COUNT(*) FROM p").fetchone() == (1,)
        con.execute("CREATE TABLE n (k TEXT NOT NULL PRIMARY KEY)")
        with pytest.raises(sqlite3.IntegrityError, match="NOT NULL"):
            con.execute("INSERT INTO n VALUES (NULL)")
    finally:
        con.close()


def test_null_keys_match_in_pandas_but_not_with_sql_equals():
    assert pandas_inner_rows(["A", None]) == 2
    assert pandas_inner_rows([1.0, float("nan")]) == 2
    assert sqlite_rows("l.order_id = r.order_id") == [("A", 1000, "K1")]
    assert sqlite_rows("l.order_id IS r.order_id") == [
        (None, 700, "K9"), ("A", 1000, "K1")]
    assert sqlite_null_comparisons() == (None, 1)


def test_temporal_dimension_needs_interval_condition():
    key_only, as_of = temporal_joins()
    assert key_only == [("A", "retail"), ("A", "business")]
    assert as_of == [("A", "business")]
