import pandas as pd
import pytest
from pandas.errors import MergeError

from join_grain import (LINES, ORDERS, PAYMENTS, enrich_lines,
                        naive_line_payment_join, order_balance,
                        validate_message)


def test_two_lines_times_three_payments_gives_six_rows():
    fanout = naive_line_payment_join()
    assert fanout.groupby("order_id").size().to_dict() == {"A": 6, "B": 1}
    assert fanout["line_cents"].sum() == 10500  # true total is 5200
    assert fanout["paid_cents"].sum() == 7500   # true total is 5000


def test_preaggregated_balance_keeps_totals_and_coverage():
    balance = order_balance().set_index("order_id")
    assert balance["line_cents"].sum() == LINES["line_cents"].sum() == 5200
    assert balance["paid_cents"].sum() == PAYMENTS["paid_cents"].sum() == 5000
    assert balance["coverage"].astype(str).to_dict() == {
        "A": "both", "B": "both", "C": "left_only", "D": "right_only"}
    assert balance["open_cents"].to_dict() == {
        "A": 0, "B": 0, "C": 700, "D": -500}
    assert balance["line_cents"].dtype == "int64"


def test_aggregating_only_one_side_still_multiplies():
    paid = PAYMENTS.groupby("order_id", as_index=False)["paid_cents"].sum()
    per_line = LINES.merge(paid, on="order_id", how="left",
                           validate="many_to_one")
    paid_for_a = per_line.loc[per_line["order_id"] == "A", "paid_cents"]
    assert paid_for_a.tolist() == [3000, 3000]
    assert paid_for_a.sum() == 6000  # A was paid 3000


def test_loss_and_multiplication_cancel_in_row_count():
    inner = enrich_lines("inner")
    assert len(inner) == len(LINES) == 4         # the row-count check passes
    assert set(inner["order_id"]) == {"A", "B"}  # yet C was dropped
    assert (inner["order_id"] == "B").sum() == 2  # and B was doubled
    assert inner["line_cents"].sum() == 6000     # instead of 5200


def test_left_join_exposes_both_problems():
    left = enrich_lines("left")
    assert len(left) == 5
    assert left["_merge"].value_counts().to_dict() == {
        "both": 4, "left_only": 1, "right_only": 0}
    assert left.loc[left["_merge"] == "left_only", "order_id"].tolist() == ["C"]


def test_validate_messages_name_the_broken_side():
    assert "not unique in right dataset" in validate_message("many_to_one")
    assert "not unique in either left or right" in validate_message("one_to_one")


def test_many_to_one_passes_but_one_to_one_fails_on_a_clean_dimension():
    clean = pd.DataFrame({"order_id": ["A", "B", "C"],
                          "customer_id": ["K1", "K2", "K5"]})
    result = LINES.merge(clean, on="order_id", how="left",
                         validate="many_to_one")
    assert len(result) == len(LINES)
    with pytest.raises(MergeError, match="not unique in left dataset"):
        LINES.merge(clean, on="order_id", how="left", validate="one_to_one")


def test_validate_checks_the_whole_composite_key():
    # One row per (order_id, line_no) on both sides: unique as a pair only.
    discounts = pd.DataFrame({"order_id": ["A", "A", "B"],
                              "line_no": [1, 2, 1],
                              "discount_cents": [100, 0, 50]})
    keys = ["order_id", "line_no"]
    result = LINES.merge(discounts, on=keys, how="left", validate="one_to_one")
    assert len(result) == len(LINES)
    with pytest.raises(MergeError, match="not unique in either left or right"):
        LINES.merge(discounts, on="order_id", how="left", validate="one_to_one")
    repeated = pd.concat([discounts, discounts.iloc[[0]]])  # ('A', 1) twice
    with pytest.raises(MergeError, match="not unique in right dataset"):
        LINES.merge(repeated, on=keys, how="left", validate="one_to_one")


def test_drop_duplicates_is_not_a_repair():
    assert len(ORDERS.drop_duplicates()) == len(ORDERS)  # rows differ
    first = ORDERS.drop_duplicates("order_id", keep="first")
    last = ORDERS.drop_duplicates("order_id", keep="last")
    customer = {"first": first.set_index("order_id").loc["B", "customer_id"],
                "last": last.set_index("order_id").loc["B", "customer_id"]}
    assert customer == {"first": "K2", "last": "K3"}  # row order decides
    assert "C" not in set(first["order_id"])         # the gap remains
