"""Null join keys: pandas merge matches them, SQL '=' does not."""
import sqlite3

import numpy as np
import pandas as pd

LEFT = pd.DataFrame({"order_id": ["A", None], "line_cents": [1000, 700]})
RIGHT = pd.DataFrame({"order_id": ["A", None], "customer_id": ["K1", "K9"]})


def pandas_inner_rows(key_values: list) -> int:
    """Inner-merge two frames whose key columns hold the given values."""
    left = pd.DataFrame({"k": key_values, "x": range(len(key_values))})
    right = pd.DataFrame({"k": key_values, "y": range(len(key_values))})
    return len(left.merge(right, on="k", how="inner"))


def sqlite_rows(condition: str) -> list[tuple]:
    """Join the same rows in SQLite with the given ON condition."""
    con = sqlite3.connect(":memory:")
    try:
        con.execute("CREATE TABLE l (order_id TEXT, line_cents INTEGER)")
        con.execute("CREATE TABLE r (order_id TEXT, customer_id TEXT)")
        con.executemany("INSERT INTO l VALUES (?, ?)",
                        LEFT.astype(object).itertuples(index=False, name=None))
        con.executemany("INSERT INTO r VALUES (?, ?)",
                        RIGHT.astype(object).itertuples(index=False, name=None))
        sql = ("SELECT l.order_id, l.line_cents, r.customer_id "
               f"FROM l JOIN r ON {condition} ORDER BY l.line_cents")
        return con.execute(sql).fetchall()
    finally:
        con.close()


def sqlite_null_comparisons() -> tuple:
    """Evaluate NULL = NULL and NULL IS NULL in SQLite."""
    con = sqlite3.connect(":memory:")
    try:
        return con.execute("SELECT NULL = NULL, NULL IS NULL").fetchone()
    finally:
        con.close()


def main() -> None:
    merged = LEFT.merge(RIGHT, on="order_id", how="inner")
    print("pandas inner merge:")
    print(merged.to_string(index=False))
    print("pandas rows, object keys with None:", pandas_inner_rows(["A", None]))
    print("pandas rows, float keys with NaN:", pandas_inner_rows([1.0, np.nan]))
    print("SQLite ON l.order_id = r.order_id:",
          sqlite_rows("l.order_id = r.order_id"))
    print("SQLite ON l.order_id IS r.order_id:",
          sqlite_rows("l.order_id IS r.order_id"))
    print("SQLite SELECT NULL = NULL, NULL IS NULL:",
          sqlite_null_comparisons())


if __name__ == "__main__":
    main()
