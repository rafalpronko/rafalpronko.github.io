# Example: quality gate before migration

Code for the article "A quality gate before migration: checking the data, not
the job status". The article carries the editorial date 2023-11-09; it was
written, and this code was run, in 2026.

Layout of the downloadable archive `quality-gate-before-migration.zip`:

```
quality-gate-before-migration/
  README.md                  this file
  pyproject.toml             no dependencies
  examples/
    quality_gate.py          the gate, a simulated promotion step, demo main
    test_quality_gate.py     unittest suite
```

`examples/quality_gate.py` is identical to the full Python block in the
article.

Python 3.11, standard library only, synthetic data only. The code doesn't
connect to or migrate any database. `promote` is a simulated callback, not a
race-free production cutover (see the article).

## Running with Python 3.11 (as in the article)

Run every command from the directory that contains `pyproject.toml` and
`examples/` (after unpacking: `quality-gate-before-migration/`):

```
python3.11 examples/quality_gate.py
python3.11 -m unittest discover -s examples -v
```

## Contemporary reproduction with uv (verified 2026-10-12)

This section is not part of the 2023-dated article. uv was announced on
15 February 2024, after the article's editorial date; it is only used here to
get a Python 3.11 interpreter today. Running the code in 2026 is not evidence
of how it ran in 2023.

From the same directory:

```
uv venv --python 3.11 .venv
.venv/bin/python examples/quality_gate.py
.venv/bin/python -m unittest discover -s examples -v
```

The author's runs on 2026-10-12 used uv 0.7.8 and CPython 3.11.12 on macOS
(Darwin 25.5.0, arm64). In each of them the demo printed the output shown in
the article and all 37 tests passed:

- the commands from "Running with Python 3.11", in the source tree and in the
  unpacked archive, with an existing uv-managed CPython 3.11.12 environment
  standing in for `python3.11`, both normally and with `python3.11 -O`;
- the uv commands above, in the unpacked archive, in a new `.venv` created by
  `uv venv` (offline, from the CPython 3.11.12 already installed), both
  normally and with `.venv/bin/python -O`.

Nothing else (other Python versions or platforms, databases, concurrent
writers, a real cutover) was tested.
