"""Pre-cutover quality gate: compare a reference snapshot with a candidate.

Synthetic data only. Python 3.11, standard library only.
Run from the directory that contains examples/:
    python3.11 examples/quality_gate.py
"""
import hashlib
import json
from collections import Counter
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

Row = tuple[str, str, int]  # (row_id, segment, amount_cents)
FIELDS = ("row_id", "segment", "amount_cents")


@dataclass(frozen=True)
class Scope:
    snapshot: str    # id of the consistent source cut both sides were read at
    start: datetime  # UTC, inclusive
    end: datetime    # UTC, exclusive
    currency: str
    fields: tuple[str, ...] = FIELDS


@dataclass(frozen=True)
class Decision:
    passed: bool
    report: dict[str, list] = field(default_factory=dict)  # mutable, advisory
    digest: str | None = None  # SHA-256 of the exact candidate that passed


def scope_errors(reference: Scope, candidate: Scope) -> list[str]:
    errors = []
    if reference != candidate:
        errors.append("scope: reference and candidate describe different data")
    for name in ("snapshot", "currency"):
        value = getattr(reference, name)
        if type(value) is not str or not value.strip():
            errors.append(f"scope: {name} must be a non-blank str")
    bounds = (reference.start, reference.end, candidate.start, candidate.end)
    if not all(isinstance(bound, datetime) for bound in bounds):
        errors.append("scope: window bounds must be datetime")  # not time/date
    elif any(bound.utcoffset() != timedelta(0) for bound in bounds):
        errors.append("scope: window bounds must be timezone-aware UTC")
    elif not reference.start < reference.end:
        errors.append("scope: window is empty or inverted")
    if reference.fields != FIELDS:
        errors.append(f"scope: compared fields must be {FIELDS}")
    return errors


def row_errors(side: str, i: int, row: object) -> list[str]:
    where = f"{side}[{i}]"
    if type(row) is not tuple or len(row) != 3:
        return [f"{where}: expected a 3-tuple, got {row!r}"]
    row_id, segment, amount = row
    errors = []
    for name, value in (("row_id", row_id), ("segment", segment)):
        if type(value) is not str or not value.strip():
            errors.append(f"{where}: {name} must be a non-blank str")
    if type(amount) is not int:  # bool is a subclass of int, so no isinstance
        errors.append(f"{where}: amount_cents must be int, "
                      f"got {type(amount).__name__}")
    return errors


def freeze(side: str, rows: Sequence[object]) -> tuple[tuple, list[str]]:
    frozen = tuple(rows)  # private copy: later edits to the caller's list
    errors = [e for i, row in enumerate(frozen)  # cannot leak into the check
              for e in row_errors(side, i, row)]
    return frozen, errors


def duplicated(rows: tuple[Row, ...]) -> list[str]:
    counts = Counter(row_id for row_id, _, _ in rows)
    return sorted(row_id for row_id, n in counts.items() if n > 1)


def reconcile(reference: tuple[Row, ...],
              candidate: tuple[Row, ...]) -> dict[str, list]:
    ref_ids = {row[0] for row in reference}
    cand_ids = {row[0] for row in candidate}
    ref_rows, cand_rows = Counter(reference), Counter(candidate)
    return {
        "missing": sorted(ref_ids - cand_ids),
        "extra": sorted(cand_ids - ref_ids),
        "duplicate_candidate": duplicated(candidate),
        "only_reference": sorted((ref_rows - cand_rows).elements()),
        "only_candidate": sorted((cand_rows - ref_rows).elements()),
    }


def digest(scope: Scope, rows: Sequence[Row]) -> str:
    payload = [scope.snapshot, scope.start.isoformat(), scope.end.isoformat(),
               scope.currency, list(scope.fields), sorted(rows)]
    return hashlib.sha256(json.dumps(payload).encode()).hexdigest()


def gate(ref_scope: Scope, reference: Sequence[Row],
         cand_scope: Scope, candidate: Sequence[Row],
         *, allow_empty: bool = False) -> Decision:
    try:
        ref_rows, invalid = freeze("reference", reference)
        cand_rows, cand_invalid = freeze("candidate", candidate)
        invalid += cand_invalid + scope_errors(ref_scope, cand_scope)
        if not invalid:
            invalid = [f"reference: duplicate row_id {d!r}"
                       for d in duplicated(ref_rows)]
        if invalid:
            return Decision(False, {"invalid": invalid})
        report = reconcile(ref_rows, cand_rows)
        empty = not ref_rows and not allow_empty
        report["empty"] = ["empty window without allow_empty"] if empty else []
        if any(report.values()):
            return Decision(False, report)
        return Decision(True, report, digest(cand_scope, cand_rows))
    except Exception as exc:  # fail closed: a check that crashed did not pass
        return Decision(False, {"error": [f"{type(exc).__name__}: {exc}"]})


def promote(decision: Decision, scope: Scope, staged: Sequence[Row],
            switch: Callable[[], None]) -> bool:
    """Simulated cutover hook, not a race-free production gate.

    The digest proves only that `staged` matched when it was hashed; data can
    still change before or during switch(). A real system checks an immutable
    staged version and moves readers to it with a switch that its store makes
    atomic and conditional on the expected current version (compare-and-swap).
    Only `passed` and `digest` are trusted here; `report` is not consulted.
    An exception raised by switch() is not caught: it propagates to the
    caller, who must treat the state of the cutover as unknown.
    """
    if not decision.passed or decision.digest is None:
        return False
    try:
        rows, invalid = freeze("staged", staged)
        unchanged = not invalid and digest(scope, rows) == decision.digest
    except Exception:  # cannot prove it is the same data, so do not switch
        return False
    if unchanged:
        switch()
    return unchanged


def main() -> None:
    utc = timezone.utc
    scope = Scope("legacy-export-0001", datetime(2023, 10, 1, tzinfo=utc),
                  datetime(2023, 11, 1, tzinfo=utc), "PLN")
    reference = [("t1", "B2B", 10000), ("t2", "B2C", 2550), ("t3", "B2C", 700)]
    scenarios = {
        "same rows, different order": reference[::-1],
        "one row lost": reference[:2],
        "one row loaded twice": reference + [reference[0]],
        "10.00 moved between rows": [("t1", "B2B", 9000),
                                     ("t2", "B2C", 3550), ("t3", "B2C", 700)],
        "t3 reassigned to B2B": reference[:2] + [("t3", "B2B", 700)],
        "bool instead of amount": reference[:2] + [("t3", "B2C", True)],
    }
    for name, candidate in scenarios.items():
        decision = gate(scope, reference, scope, candidate)
        found = {k: v for k, v in decision.report.items() if v}
        print("PASS " if decision.passed else "BLOCK", f"{name}: {found}")
    staging = list(reference)
    decision = gate(scope, reference, scope, staging)
    staging.append(("t4", "B2C", 100))  # a late write after the check
    switched = promote(decision, scope, staging, lambda: print("cutover"))
    print(f"promote after a late write: {switched}; old dataset stays live")
    switched = promote(decision, scope, reference, lambda: print("cutover"))
    print(f"promote the copy that was checked: {switched}")


if __name__ == "__main__":
    main()
