"""Tests for quality_gate.py. Standard library unittest only; synthetic data."""
import dataclasses
import unittest
from datetime import date, datetime, time, timedelta, timezone
from unittest import mock

import quality_gate as qg

UTC = timezone.utc
SCOPE = qg.Scope("legacy-export-0001", datetime(2023, 10, 1, tzinfo=UTC),
                 datetime(2023, 11, 1, tzinfo=UTC), "PLN")
REF = [("t1", "B2B", 10000), ("t2", "B2C", 2550), ("t3", "B2C", 700)]


def run(candidate, reference=REF, scope=SCOPE, **kwargs):
    return qg.gate(scope, reference, scope, candidate, **kwargs)


class Reconciliation(unittest.TestCase):
    def test_same_rows_in_different_order_pass(self):
        decision = run(REF[::-1])
        self.assertTrue(decision.passed)
        self.assertIsNotNone(decision.digest)

    def test_missing_row_blocks(self):
        decision = run(REF[:2])
        self.assertFalse(decision.passed)
        self.assertEqual(decision.report["missing"], ["t3"])

    def test_extra_row_blocks(self):
        decision = run(REF + [("t4", "B2C", 100)])
        self.assertFalse(decision.passed)
        self.assertEqual(decision.report["extra"], ["t4"])

    def test_candidate_duplicate_blocks(self):
        decision = run(REF + [REF[0]])
        self.assertFalse(decision.passed)
        self.assertEqual(decision.report["duplicate_candidate"], ["t1"])
        self.assertEqual(decision.report["only_candidate"], [REF[0]])

    def test_lost_row_hidden_by_duplicate_still_blocks(self):
        candidate = [REF[0], REF[1], REF[1]]
        self.assertEqual(len(candidate), len(REF))
        decision = run(candidate)
        self.assertFalse(decision.passed)
        self.assertEqual(decision.report["missing"], ["t3"])
        self.assertEqual(decision.report["duplicate_candidate"], ["t2"])

    def test_reference_duplicate_is_invalid_reference(self):
        decision = run(REF, reference=REF + [REF[1]])
        self.assertFalse(decision.passed)
        self.assertEqual(decision.report["invalid"],
                         ["reference: duplicate row_id 't2'"])

    def test_duplicate_on_both_sides_blocks(self):
        doubled = REF + [REF[1]]
        decision = run(doubled, reference=doubled)
        self.assertFalse(decision.passed)
        self.assertIn("reference: duplicate row_id 't2'",
                      decision.report["invalid"])

    def test_compensating_amounts_block_despite_equal_totals(self):
        moved = [("t1", "B2B", 9000), ("t2", "B2C", 3550), ("t3", "B2C", 700)]
        self.assertEqual(len(moved), len(REF))
        self.assertEqual(sum(r[2] for r in moved), sum(r[2] for r in REF))
        self.assertEqual({r[0] for r in moved}, {r[0] for r in REF})
        decision = run(moved)
        self.assertFalse(decision.passed)
        self.assertEqual(len(decision.report["only_candidate"]), 2)

    def test_segment_reassignment_blocks(self):
        decision = run(REF[:2] + [("t3", "B2B", 700)])
        self.assertFalse(decision.passed)
        self.assertEqual(decision.report["missing"], [])
        self.assertEqual(decision.report["only_candidate"], [("t3", "B2B", 700)])


class Validation(unittest.TestCase):
    def assert_invalid(self, decision, fragment):
        self.assertFalse(decision.passed)
        self.assertIsNone(decision.digest)
        self.assertTrue(any(fragment in e for e in decision.report["invalid"]),
                        decision.report)

    def test_bool_amount_is_invalid(self):
        self.assert_invalid(run(REF[:2] + [("t3", "B2C", True)]),
                            "amount_cents must be int, got bool")

    def test_string_amount_is_invalid(self):
        self.assert_invalid(run(REF[:2] + [("t3", "B2C", "700")]),
                            "amount_cents must be int, got str")

    def test_float_amount_is_invalid(self):
        self.assert_invalid(run(REF[:2] + [("t3", "B2C", 700.0)]),
                            "amount_cents must be int, got float")

    def test_malformed_row_shapes_are_invalid(self):
        for bad in [("t3", "B2C"), ("t3", "B2C", 700, "x"), ["t3", "B2C", 700],
                    {"row_id": "t3"}, None]:
            with self.subTest(bad=bad):
                self.assert_invalid(run(REF[:2] + [bad]), "expected a 3-tuple")

    def test_non_string_or_blank_identifiers_are_invalid(self):
        for bad in [(3, "B2C", 700), (None, "B2C", 700), ("", "B2C", 700),
                    ("   ", "B2C", 700), ("t3", 1, 700), ("t3", " ", 700)]:
            with self.subTest(bad=bad):
                self.assert_invalid(run(REF[:2] + [bad]), "must be a non-blank str")

    def test_invalid_reference_row_blocks(self):
        self.assert_invalid(run(REF, reference=REF[:2] + [("t3", "B2C", None)]),
                            "reference[2]")

    def test_scope_mismatch_blocks(self):
        other = qg.Scope("legacy-export-0001", SCOPE.start, SCOPE.end, "EUR")
        self.assert_invalid(qg.gate(SCOPE, REF, other, REF), "different data")

    def test_naive_window_blocks(self):
        naive = qg.Scope("s", datetime(2023, 10, 1), datetime(2023, 11, 1), "PLN")
        self.assert_invalid(run(REF, scope=naive), "timezone-aware UTC")

    def test_non_utc_offset_blocks(self):
        cet = timezone(timedelta(hours=1))
        scope = qg.Scope("s", datetime(2023, 10, 1, tzinfo=cet),
                         datetime(2023, 11, 1, tzinfo=cet), "PLN")
        self.assert_invalid(run(REF, scope=scope), "timezone-aware UTC")

    def test_inverted_window_blocks(self):
        scope = qg.Scope("s", SCOPE.end, SCOPE.start, "PLN")
        self.assert_invalid(run(REF, scope=scope), "empty or inverted")

    def test_candidate_bound_with_same_instant_but_non_utc_offset_blocks(self):
        cet = timezone(timedelta(hours=1))
        start = datetime(2023, 10, 1, 1, tzinfo=cet)  # same instant as SCOPE
        other = qg.Scope(SCOPE.snapshot, start, SCOPE.end, SCOPE.currency)
        self.assertEqual(other, SCOPE)
        self.assert_invalid(qg.gate(SCOPE, REF, other, REF), "timezone-aware UTC")

    def test_blank_or_non_string_snapshot_and_currency_are_invalid(self):
        for snapshot, currency in [("", "PLN"), ("  ", "PLN"), (None, "PLN"),
                                   ("s", ""), ("s", " "), ("s", 985)]:
            with self.subTest(snapshot=snapshot, currency=currency):
                scope = qg.Scope(snapshot, SCOPE.start, SCOPE.end, currency)
                self.assert_invalid(run(REF, scope=scope), "must be a non-blank str")

    def test_non_datetime_bound_blocks(self):
        scope = qg.Scope("s", "2023-10-01", SCOPE.end, "PLN")
        self.assert_invalid(run(REF, scope=scope), "bounds must be datetime")

    def test_time_of_day_window_on_both_sides_is_invalid(self):
        # aware time-of-day values have a zero UTC offset and are ordered,
        # but they name no dates: the same scope on both sides must not pass
        scope = qg.Scope("s", time(0, tzinfo=UTC), time(1, tzinfo=UTC), "PLN")
        self.assertEqual(scope.start.utcoffset(), timedelta(0))
        self.assert_invalid(run(REF, scope=scope), "bounds must be datetime")

    def test_each_non_datetime_bound_is_invalid(self):
        for bad in [time(0, tzinfo=UTC), date(2023, 10, 1), "2023-10-01"]:
            for side, name in [("reference", "start"), ("reference", "end"),
                               ("candidate", "start"), ("candidate", "end")]:
                with self.subTest(bad=bad, side=side, name=name):
                    changed = dataclasses.replace(SCOPE, **{name: bad})
                    scopes = {"reference": SCOPE, "candidate": SCOPE, side: changed}
                    decision = qg.gate(scopes["reference"], REF,
                                       scopes["candidate"], REF)
                    self.assert_invalid(decision, "bounds must be datetime")


class EmptyPolicy(unittest.TestCase):
    def test_empty_window_is_rejected_by_default(self):
        decision = run([], reference=[])
        self.assertFalse(decision.passed)
        self.assertTrue(decision.report["empty"])

    def test_empty_window_passes_only_when_allowed(self):
        self.assertTrue(run([], reference=[], allow_empty=True).passed)

    def test_allow_empty_does_not_hide_extra_rows(self):
        decision = run(REF, reference=[], allow_empty=True)
        self.assertFalse(decision.passed)
        self.assertEqual(decision.report["extra"], ["t1", "t2", "t3"])


class Promotion(unittest.TestCase):
    def test_passed_and_unchanged_candidate_switches_once(self):
        switch = mock.Mock()
        decision = run(list(REF))
        self.assertTrue(qg.promote(decision, SCOPE, REF[::-1], switch))
        switch.assert_called_once_with()

    def test_blocked_decision_does_not_switch(self):
        switch = mock.Mock()
        self.assertFalse(qg.promote(run(REF[:2]), SCOPE, REF[:2], switch))
        switch.assert_not_called()

    def test_candidate_changed_after_check_does_not_switch(self):
        switch = mock.Mock()
        staging = list(REF)
        decision = run(staging)
        staging[0] = ("t1", "B2B", 1)
        self.assertFalse(qg.promote(decision, SCOPE, staging, switch))
        switch.assert_not_called()

    def test_caller_mutation_after_gate_does_not_change_checked_copy(self):
        staging = list(REF)
        decision = run(staging)
        staging.append(("t4", "B2C", 100))
        self.assertEqual(decision.digest, qg.digest(SCOPE, tuple(REF)))

    def test_exception_in_check_blocks_and_does_not_switch(self):
        switch = mock.Mock()
        with mock.patch.object(qg, "reconcile", side_effect=RuntimeError("boom")):
            decision = run(REF)
        self.assertFalse(decision.passed)
        self.assertEqual(decision.report["error"], ["RuntimeError: boom"])
        self.assertFalse(qg.promote(decision, SCOPE, REF, switch))
        switch.assert_not_called()

    def test_non_iterable_input_blocks_and_does_not_switch(self):
        switch = mock.Mock()
        decision = run(None)
        self.assertFalse(decision.passed)
        self.assertIn("error", decision.report)
        self.assertFalse(qg.promote(decision, SCOPE, REF, switch))
        switch.assert_not_called()

    def test_malformed_staged_data_does_not_switch(self):
        switch = mock.Mock()
        decision = run(REF)
        self.assertFalse(qg.promote(decision, SCOPE, [REF[0], {"bad": 1}], switch))
        switch.assert_not_called()

    def test_staged_rows_with_wrong_shape_but_same_json_do_not_switch(self):
        switch = mock.Mock()
        decision = run(REF)
        as_lists = [list(row) for row in REF]  # serialises like the tuples
        self.assertFalse(qg.promote(decision, SCOPE, as_lists, switch))
        switch.assert_not_called()

    def test_exception_in_switch_propagates(self):
        # documented contract: promote doesn't swallow a failed switch, the
        # caller has to treat the cutover state as unknown
        switch = mock.Mock(side_effect=RuntimeError("switch failed"))
        with self.assertRaisesRegex(RuntimeError, "switch failed"):
            qg.promote(run(REF), SCOPE, REF, switch)
        switch.assert_called_once_with()

    def test_promote_under_different_scope_does_not_switch(self):
        switch = mock.Mock()
        decision = run(REF)
        other = qg.Scope("legacy-export-0002", SCOPE.start, SCOPE.end, "PLN")
        self.assertFalse(qg.promote(decision, other, REF, switch))
        switch.assert_not_called()


if __name__ == "__main__":
    unittest.main()
