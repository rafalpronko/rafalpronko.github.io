-- Compare both customer key sets and totals for EACH staged customer.
with order_totals as (
    select customer_id,
           count(*) filter (where not is_canceled) as order_count,
           count(*) filter (where is_canceled) as canceled_order_count,
           coalesce(cast(sum(recognized_amount) as decimal(18, 2)),
                    cast(0 as decimal(18, 2))) as lifetime_value,
           min(ordered_at) filter (where not is_canceled) as first_order_at,
           max(ordered_at) filter (where not is_canceled) as last_order_at
    from {{ ref('orders') }}
    group by customer_id
),
expected as (
    select c.customer_id,
           coalesce(o.order_count, cast(0 as bigint)) as order_count,
           coalesce(o.canceled_order_count, cast(0 as bigint)) as canceled_order_count,
           coalesce(o.lifetime_value, cast(0 as decimal(18, 2))) as lifetime_value,
           o.first_order_at, o.last_order_at
    from {{ ref('stg_shop__customers') }} c
    left join order_totals o on c.customer_id = o.customer_id
),
actual as (
    select * from {{ ref('customers') }}
)
select e.customer_id as expected_customer_id, a.customer_id as actual_customer_id,
       e.lifetime_value as expected_value, a.lifetime_value as actual_value,
       e.order_count as expected_orders, a.order_count as actual_orders,
       e.canceled_order_count as expected_canceled, a.canceled_order_count as actual_canceled
from expected e
full outer join actual a on e.customer_id = a.customer_id
where e.customer_id is null or a.customer_id is null
   or a.order_count is distinct from e.order_count
   or a.canceled_order_count is distinct from e.canceled_order_count
   or a.lifetime_value is distinct from e.lifetime_value
   or a.first_order_at is distinct from e.first_order_at
   or a.last_order_at is distinct from e.last_order_at
