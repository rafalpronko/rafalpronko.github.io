-- Quantity must be positive; a zero price is a valid free item, not missing data.
select order_item_id, quantity, unit_price, line_amount
from {{ ref('stg_shop__order_items') }}
where quantity is null or quantity <= 0
   or unit_price is null or unit_price < 0
   or line_amount is null
