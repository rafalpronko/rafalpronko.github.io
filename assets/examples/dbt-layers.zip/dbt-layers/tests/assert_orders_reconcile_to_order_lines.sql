-- Compare both key sets and the expected counts and amounts of EACH order.
with line_totals as (
    select order_id,
           count(*) as line_count,
           coalesce(sum(quantity), cast(0 as bigint)) as unit_count,
           coalesce(cast(sum(line_amount) as decimal(18, 2)),
                    cast(0 as decimal(18, 2))) as order_amount
    from {{ ref('stg_shop__order_items') }}
    group by order_id
),
expected as (
    select o.order_id, o.customer_id, o.ordered_at, o.order_status, o.is_canceled,
           coalesce(l.line_count, cast(0 as bigint)) as line_count,
           coalesce(l.unit_count, cast(0 as bigint)) as unit_count,
           coalesce(l.order_amount, cast(0 as decimal(18, 2))) as order_amount,
           case when o.is_canceled then cast(0 as decimal(18, 2))
                else coalesce(l.order_amount, cast(0 as decimal(18, 2))) end as recognized_amount
    from {{ ref('stg_shop__orders') }} o
    left join line_totals l on o.order_id = l.order_id
),
actual as (
    select * from {{ ref('orders') }}
)
select e.order_id as expected_order_id, a.order_id as actual_order_id,
       e.order_amount as expected_amount, a.order_amount as actual_amount,
       e.line_count as expected_lines, a.line_count as actual_lines,
       e.unit_count as expected_units, a.unit_count as actual_units
from expected e
full outer join actual a on e.order_id = a.order_id
where e.order_id is null or a.order_id is null
   or a.customer_id is distinct from e.customer_id
   or a.ordered_at is distinct from e.ordered_at
   or a.order_status is distinct from e.order_status
   or a.is_canceled is distinct from e.is_canceled
   or a.line_count is distinct from e.line_count
   or a.unit_count is distinct from e.unit_count
   or a.order_amount is distinct from e.order_amount
   or a.recognized_amount is distinct from e.recognized_amount
