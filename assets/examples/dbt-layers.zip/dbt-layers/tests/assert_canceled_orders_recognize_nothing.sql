-- Business policy: canceled orders retain their gross amount but recognize 0.00.
select order_id, order_status, order_amount, recognized_amount
from {{ ref('orders') }}
where is_canceled is null
   or order_amount is null
   or recognized_amount is distinct from
      case when is_canceled then cast(0 as decimal(18, 2)) else order_amount end
