# dbt layers: staging → intermediate → marts

A small, complete dbt project on synthetic data. Everything runs locally against
one DuckDB file. No cloud account, no credentials, no paid services.

Pinned versions (all published on PyPI before 2024-04-11):

- Python 3.11
- dbt-core 1.7.11
- dbt-duckdb 1.7.3
- duckdb 0.10.1

`pyproject.toml` also sets `exclude-newer = "2024-04-11T00:00:00Z"`, so `uv.lock`
resolves every transitive dependency as PyPI looked on that date.

## Run

Requires [uv](https://docs.astral.sh/uv/). Run every command from this directory.

```bash
uv sync --frozen --python 3.11                     # create .venv from uv.lock
uv run dbt build --profiles-dir . --threads 1      # seeds, models and tests in DAG order
uv run python scripts/show_marts.py                # print both marts and a content fingerprint
```

Expected end of the build output:

```text
Done. PASS=44 WARN=0 ERROR=0 SKIP=0 TOTAL=44
```

Run the build a second time and `show_marts.py` again: the fingerprint must not change.

The fan-out demo reads the database. The two mutation demos write synthetic seeds
and rebuild; run them after a successful build:

```bash
uv run python scripts/fanout_demo.py     # naive join across grains vs. the customers mart
uv run python scripts/bad_data_demo.py   # write a duplicate line, reject, restore and rebuild
uv run python scripts/repair_regression.py # NULL inputs, empty builds, corrupt marts, recovery
```

`bad_data_demo.py` appends a duplicate line to `seeds/raw_order_items.csv`, runs
`dbt build` (expected to exit non-zero), restores the file from a backup in a
`finally` block, checks it byte-for-byte and rebuilds. It exits 0 only if the
first build failed, the second one passed, and the view/table amounts recovered.

`repair_regression.py` exercises 26 checks. It rejects missing price, quantity,
status and order time; accepts customers with no orders and entirely empty inputs;
and rejects 16 key/count/amount corruptions using the actual compiled singular SQL.
It restores all seed bytes in `finally`, rebuilds, and asserts the original mart
fingerprint. Run only one mutation demo at a time against this local database.

Notes:

- `uv sync` needs the network when the uv cache is cold: it downloads the locked
  packages and, if missing, a Python 3.11 interpreter.
- Once dependencies are installed, `uv run dbt --version` is the only command that
  goes online: it asks PyPI for the latest dbt version. `dbt build`, the scripts and
  the tests run offline once `.venv` exists.
- `profiles.yml` lives in this directory and is selected with `--profiles-dir .`.
  It writes `dbt_layers.duckdb` here. Delete that file, `target/` and `logs/` to start over.

## Layout

```text
seeds/                      raw_customers, raw_orders, raw_order_items (loaded as VARCHAR)
models/staging/             one view per seed: rename, cast, keep the grain
models/intermediate/        order lines summed to one row per order (view)
models/marts/               orders and customers (tables)
tests/                      singular tests: reconciliations and business policy
scripts/                    read-only inspection plus demos that mutate and restore synthetic data
```

## Grain

| Model | One row per |
|---|---|
| `stg_shop__customers` | customer |
| `stg_shop__orders` | order (canceled included) |
| `stg_shop__order_items` | order line |
| `int_order_items_summed_to_orders` | order that has at least one line |
| `orders` | order in `stg_shop__orders` (canceled and line-less included) |
| `customers` | customer in `stg_shop__customers` (customers without orders included) |

Policy: a canceled order keeps `order_amount` for audit and has `recognized_amount = 0.00`.
`customers.order_count` counts non-canceled orders; `canceled_order_count` counts the rest.
Money is `DECIMAL(18,2)` from staging onward. A zero price is a valid free item;
a missing price is invalid, and quantity must be positive.

There are 35 tests: 31 generic and 4 singular. Reconciliation checks both directions
of each mart key set and counts/amounts per entity using NULL-safe comparisons.
No-orders customers and entirely empty inputs are valid. Empty amounts normalize
to typed decimal zero; first/last order dates remain NULL.

Failed tests do not roll back models. Tables retain their latest model build even
if tests fail; existing downstream views can read updated data despite being skipped.

## What this project deliberately leaves out

Sources and freshness, incremental models, snapshots, schema evolution, backfills,
late-arriving data and retries. Seeds stand in for raw tables so the project is
self-contained; with real ingestion, staging would read `{{ source(...) }}`.

ZIP entry timestamps use the neutral epoch 1980-01-01 for reproducibility;
they do not assert when these files were authored.
