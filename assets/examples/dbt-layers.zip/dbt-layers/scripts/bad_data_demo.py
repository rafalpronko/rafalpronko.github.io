"""Deliver a duplicated order line, watch dbt build fail, then restore and rebuild.

Run after a successful `dbt build`:  uv run python scripts/bad_data_demo.py
The seed file is restored in `finally` and checked byte-for-byte.
"""
import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

import duckdb

ROOT = Path(__file__).resolve().parents[1]
SEED = ROOT / "seeds" / "raw_order_items.csv"
BACKUP = SEED.with_name("raw_order_items.csv.bak")
BAD_LINE = "L01,O1001,SKU-TEA,2,12.50\n"  # the same line delivered twice
BUILD = ["dbt", "build", "--profiles-dir", ".", "--threads", "1"]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build(label: str) -> int:
    print(f"\n$ {' '.join(BUILD)}   # {label}", flush=True)
    code = subprocess.run(BUILD, cwd=ROOT).returncode
    print(f"exit code: {code}", flush=True)
    return code


def peek(label: str) -> None:
    con = duckdb.connect(str(ROOT / "dbt_layers.duckdb"), read_only=True)
    q = {
        "stg_shop__order_items rows (view)":
            "select count(*) from main.stg_shop__order_items",
        "int_order_items_summed_to_orders O1001 (view)":
            "select order_amount from main.int_order_items_summed_to_orders where order_id = 'O1001'",
        "orders O1001 (table)":
            "select order_amount from main.orders where order_id = 'O1001'",
    }
    print(f"\n-- state {label}")
    for name, sql in q.items():
        print(f"{name}: {con.sql(sql).fetchone()[0]}")
    if label == "after failed build":
        assert con.sql(q["stg_shop__order_items rows (view)"]).fetchone()[0] == 10
        assert str(con.sql(q["int_order_items_summed_to_orders O1001 (view)"]).fetchone()[0]) == "58.99"
        assert str(con.sql(q["orders O1001 (table)"]).fetchone()[0]) == "33.99"
    else:
        assert str(con.sql(q["int_order_items_summed_to_orders O1001 (view)"]).fetchone()[0]) == "33.99"
        assert str(con.sql(q["orders O1001 (table)"]).fetchone()[0]) == "33.99"
    con.close()


original = sha(SEED)
shutil.copyfile(SEED, BACKUP)
try:
    with SEED.open("a") as f:
        f.write(BAD_LINE)
    bad_exit = build("with duplicated line L01")
    peek("after failed build")
finally:
    shutil.move(BACKUP, SEED)
    assert sha(SEED) == original, "seed recovery failed"
    good_exit = build("after restoring the seed")
    assert good_exit == 0, "recovery build failed"
restored = sha(SEED) == original
print(f"\nseed restored byte-for-byte: {restored}")
peek("after restored build")

ok = bad_exit != 0 and good_exit == 0 and restored
print(f"\nexpected failure then recovery: {ok}")
sys.exit(0 if ok else 1)
