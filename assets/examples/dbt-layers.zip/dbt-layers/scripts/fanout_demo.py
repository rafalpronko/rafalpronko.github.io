"""Show what a join across two grains does to an order-level amount (read-only).

Run after `dbt build`:  uv run python scripts/fanout_demo.py
"""
from pathlib import Path

import duckdb

DB = Path(__file__).resolve().parents[1] / "dbt_layers.duckdb"

NAIVE = """
-- Wrong: orders (order grain) joined to lines (line grain) before summing.
select o.customer_id,
       count(o.order_id)        as order_rows_seen,
       sum(o.recognized_amount) as lifetime_value
from main.orders o
left join main.stg_shop__order_items i on i.order_id = o.order_id
group by o.customer_id order by o.customer_id
"""

CORRECT = """
select customer_id, order_count + canceled_order_count as order_rows_seen,
       lifetime_value
from main.customers where order_count + canceled_order_count > 0
order by customer_id
"""

con = duckdb.connect(str(DB), read_only=True)
for label, sql in (("naive join, then sum", NAIVE), ("customers mart (customers with at least one order)", CORRECT)):
    rows = con.sql(sql).fetchall()
    total = sum(r[2] for r in rows)
    print(f"\n== {label} (total lifetime_value = {total})")
    for r in rows:
        print(f"{r[0]}  order_rows_seen={r[1]}  lifetime_value={r[2]}")
con.close()
