"""Exercise NULL inputs, empty builds and per-entity reconciliation.

Run after a good build: uv run python scripts/repair_regression.py
This demo WRITES seeds and mart tables, restores them in finally, rebuilds,
and asserts byte-for-byte seed recovery and the original mart fingerprint.
"""
import argparse
import csv
import hashlib
import io
import subprocess
from pathlib import Path

import duckdb

ROOT = Path(__file__).resolve().parents[1]
BUILD = ["dbt", "build", "--profiles-dir", ".", "--threads", "1"]
SEEDS = sorted((ROOT / "seeds").glob("*.csv"))
RESULTS = []


def build(label):
    print(f"\n$ {' '.join(BUILD)}  # {label}", flush=True)
    proc = subprocess.run(BUILD, cwd=ROOT)
    print(f"exit_code={proc.returncode}", flush=True)
    return proc.returncode


def check(label, ok, detail):
    RESULTS.append((label, ok))
    print(f"CHECK {label}: {ok}; {detail}", flush=True)


def fingerprint():
    with duckdb.connect(str(ROOT / "dbt_layers.duckdb"), read_only=True) as con:
        rows = [con.sql(f"select * from main.{t} order by 1").fetchall()
                for t in ("orders", "customers")]
    return hashlib.sha256(repr(rows).encode()).hexdigest()


def change_seed(original, name, column):
    path = ROOT / "seeds" / name
    reader = csv.DictReader(io.StringIO(original[path].decode()))
    rows = list(reader)
    rows[0][column] = ""
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=reader.fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def corrupt(label, table, sql, test):
    # Execute the exact SQL compiled by the most recent dbt build, not a copy
    # of the test logic. Table restoration runs even if query execution fails.
    path = ROOT / "target" / "compiled" / "dbt_layers" / "tests" / f"{test}.sql"
    query = path.read_text()
    with duckdb.connect(str(ROOT / "dbt_layers.duckdb")) as con:
        con.sql(f"create temp table saved as select * from main.{table}")
        try:
            print(f"\n$ DuckDB SQL: {sql}", flush=True)
            con.sql(sql)
            print(f"$ DuckDB SQL from {path.relative_to(ROOT)}", flush=True)
            rows = con.sql(query).fetchall()
            print(f"returned failure rows ({len(rows)}): {rows}", flush=True)
            check(label, len(rows) > 0, "singular test must return failure rows")
        finally:
            con.sql(f"delete from main.{table}")
            con.sql(f"insert into main.{table} select * from saved")
            assert con.sql(f"select * from main.{table} except select * from saved").fetchall() == []
            assert con.sql(f"select * from saved except select * from main.{table}").fetchall() == []


def main():
    original = {p: p.read_bytes() for p in SEEDS}
    before = fingerprint()
    try:
        for label, name, column in (
            ("missing-price", "raw_order_items.csv", "unit_price"),
            ("missing-quantity", "raw_order_items.csv", "quantity"),
            ("missing-status", "raw_orders.csv", "status"),
            ("missing-ordered-at", "raw_orders.csv", "ordered_at"),
        ):
            try:
                change_seed(original, name, column)
                check(label, build(label) != 0, "build must reject missing required input")
            finally:
                for p, content in original.items():
                    p.write_bytes(content)
                assert build(f"recover {label}") == 0
                assert fingerprint() == before

        order_test = "assert_orders_reconcile_to_order_lines"
        customer_test = "assert_customers_reconcile_to_orders"
        cases = [
            ("missing-order-key", "orders", "delete from main.orders where order_id='O1007'", order_test),
            ("invented-order-key", "orders", "insert into main.orders select 'O9999', * exclude(order_id) from main.orders where order_id='O1007'", order_test),
            ("replaced-order-key", "orders", "update main.orders set order_id='O9999' where order_id='O1007'", order_test),
            ("redistributed-order-amounts", "orders", "update main.orders set order_amount=order_amount + case when order_id='O1001' then 1 when order_id='O1002' then -1 else 0 end", order_test),
            ("wrong-line-count", "orders", "update main.orders set line_count=line_count+1 where order_id='O1001'", order_test),
            ("wrong-unit-count", "orders", "update main.orders set unit_count=unit_count+1 where order_id='O1001'", order_test),
            ("null-order-amount", "orders", "update main.orders set order_amount=null where order_id='O1007'", order_test),
            ("missing-customer-key", "customers", "delete from main.customers where customer_id='C004'", customer_test),
            ("invented-customer-key", "customers", "insert into main.customers select 'C999', * exclude(customer_id) from main.customers where customer_id='C004'", customer_test),
            ("replaced-customer-key", "customers", "update main.customers set customer_id='C999' where customer_id='C004'", customer_test),
            ("redistributed-customer-amounts", "customers", "update main.customers set lifetime_value=lifetime_value + case when customer_id='C001' then 1 when customer_id='C002' then -1 else 0 end", customer_test),
            ("redistributed-order-counts", "customers", "update main.customers set order_count=order_count + case when customer_id='C001' then 1 when customer_id='C002' then -1 else 0 end", customer_test),
            ("redistributed-canceled-counts", "customers", "update main.customers set canceled_order_count=canceled_order_count + case when customer_id='C001' then 1 when customer_id='C002' then -1 else 0 end", customer_test),
            ("null-customer-amount", "customers", "update main.customers set lifetime_value=null where customer_id='C004'", customer_test),
        ]
        for case in cases:
            corrupt(*case)
        assert fingerprint() == before

        for p in SEEDS:
            if p.name != "raw_customers.csv":
                p.write_bytes(original[p].splitlines(keepends=True)[0])
        check("no-orders-build", build("customers present, no orders or lines") == 0, "empty order aggregates are valid")
        with duckdb.connect(str(ROOT / "dbt_layers.duckdb"), read_only=True) as con:
            rows = con.sql("select customer_id, order_count, canceled_order_count, lifetime_value, first_order_at, last_order_at from main.customers order by 1").fetchall()
            print(f"no-orders customer rows: {rows}", flush=True)
            check("no-orders-zero-totals", len(rows) == 5 and all(r[1:4] == (0, 0, 0) and r[4:] == (None, None) for r in rows), "all five customers preserved with zero totals and NULL dates")
        corrupt("wrong-nonzero-no-orders", "customers", "update main.customers set lifetime_value=1 where customer_id='C004'", customer_test)
        corrupt("null-count-no-orders", "customers", "update main.customers set order_count=null where customer_id='C004'", customer_test)
        for p in SEEDS:
            p.write_bytes(original[p].splitlines(keepends=True)[0])
        check("all-empty-build", build("all three inputs empty") == 0, "entirely empty inputs are valid")
        with duckdb.connect(str(ROOT / "dbt_layers.duckdb"), read_only=True) as con:
            counts = [con.sql(f"select count(*) from main.{t}").fetchone()[0] for t in ("orders", "customers")]
            check("all-empty-marts", counts == [0, 0], str(counts))
    finally:
        for p, content in original.items():
            p.write_bytes(content)
        restored = all(p.read_bytes() == content for p, content in original.items())
        recovery = build("final recovery from original seeds")
        recovered = recovery == 0 and fingerprint() == before
        check("seed-recovery", restored, "all seed bytes equal originals")
        check("mart-recovery", recovered, f"original fingerprint={before}")
        assert restored and recovered, "recovery failed"
    failed = [name for name, ok in RESULTS if not ok]
    print(f"\nREGRESSION checks={len(RESULTS)} satisfied={len(RESULTS)-len(failed)} failed={len(failed)}")
    print(f"failed checks: {failed}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
