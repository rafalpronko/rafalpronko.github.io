"""Print both marts and a fingerprint of their content (read-only).

Run after `dbt build`:  uv run python scripts/show_marts.py
Two builds over the same seeds should print the same fingerprint.
"""
import hashlib
from pathlib import Path

import duckdb

DB = Path(__file__).resolve().parents[1] / "dbt_layers.duckdb"
QUERIES = {
    "orders": "select * from main.orders order by order_id",
    "customers": "select * from main.customers order by customer_id",
}

con = duckdb.connect(str(DB), read_only=True)
digest = hashlib.sha256()
for name, sql in QUERIES.items():
    rel = con.sql(sql)
    rows = rel.fetchall()
    types = dict(zip(rel.columns, (str(t) for t in rel.types)))
    print(f"\n== {name}: {len(rows)} rows")
    print("types:", {k: v for k, v in types.items() if "DECIMAL" in v or "DOUBLE" in v})
    print(" | ".join(rel.columns))
    for row in rows:
        print(" | ".join("NULL" if v is None else str(v) for v in row))
        digest.update(repr(row).encode())
totals = con.sql(
    "select sum(order_amount), sum(recognized_amount) from main.orders"
).fetchone()
print(f"\norder_amount total: {totals[0]}  recognized total: {totals[1]}")
print(f"marts fingerprint: {digest.hexdigest()}")
con.close()
