-- Grain change: order line -> order. One row per order_id that has at least one line.
-- Aggregating here, before any join, is what keeps the marts free of fan-out.
select
    order_id,
    count(*)                                as line_count,
    sum(quantity)                           as unit_count,
    cast(sum(line_amount) as decimal(18, 2)) as order_amount
from {{ ref('stg_shop__order_items') }}
group by order_id
