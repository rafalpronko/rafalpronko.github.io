-- Grain: one row per order in stg_shop__orders, including canceled orders
-- and orders that have no lines yet. Policy: canceled orders keep their
-- order_amount for audit, but recognize 0.00.
with orders as (
    select * from {{ ref('stg_shop__orders') }}
),

order_totals as (
    select * from {{ ref('int_order_items_summed_to_orders') }}
)

select
    orders.order_id,
    orders.customer_id,
    orders.ordered_at,
    orders.order_status,
    orders.is_canceled,
    coalesce(order_totals.line_count, 0)                         as line_count,
    coalesce(order_totals.unit_count, 0)                         as unit_count,
    cast(coalesce(order_totals.order_amount, 0) as decimal(18, 2)) as order_amount,
    cast(case when orders.is_canceled then 0
              else coalesce(order_totals.order_amount, 0) end
         as decimal(18, 2))                                      as recognized_amount
from orders
left join order_totals
    on orders.order_id = order_totals.order_id
