-- Grain: one row per customer in stg_shop__customers, including customers
-- with no orders. Orders are rolled up to customer grain before the join.
with customers as (
    select * from {{ ref('stg_shop__customers') }}
),

customer_orders as (
    select
        customer_id,
        count(*) filter (where not is_canceled)            as order_count,
        count(*) filter (where is_canceled)                as canceled_order_count,
        cast(sum(recognized_amount) as decimal(18, 2))     as lifetime_value,
        min(ordered_at) filter (where not is_canceled)     as first_order_at,
        max(ordered_at) filter (where not is_canceled)     as last_order_at
    from {{ ref('orders') }}
    group by customer_id
)

select
    customers.customer_id,
    customers.customer_name,
    customers.email,
    customers.signed_up_on,
    coalesce(customer_orders.order_count, 0)                         as order_count,
    coalesce(customer_orders.canceled_order_count, 0)                as canceled_order_count,
    cast(coalesce(customer_orders.lifetime_value, 0) as decimal(18, 2)) as lifetime_value,
    customer_orders.first_order_at,
    customer_orders.last_order_at
from customers
left join customer_orders
    on customers.customer_id = customer_orders.customer_id
