-- Grain: one row per order_id, exactly as delivered by raw_orders.
select
    cast(order_id as varchar)       as order_id,
    cast(customer_id as varchar)    as customer_id,
    cast(ordered_at as timestamp)   as ordered_at,
    lower(trim(status))             as order_status,
    lower(trim(status)) = 'canceled' as is_canceled
from {{ ref('raw_orders') }}
