-- Grain: one row per customer_id, exactly as delivered by raw_customers.
select
    cast(customer_id as varchar)    as customer_id,
    cast(full_name as varchar)      as customer_name,
    lower(trim(email))              as email,
    cast(signup_date as date)       as signed_up_on
from {{ ref('raw_customers') }}
