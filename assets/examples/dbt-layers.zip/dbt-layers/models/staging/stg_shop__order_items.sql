-- Grain: one row per order_item_id (an order line), exactly as delivered.
select
    cast(order_item_id as varchar)          as order_item_id,
    cast(order_id as varchar)               as order_id,
    cast(sku as varchar)                    as sku,
    cast(quantity as integer)               as quantity,
    cast(unit_price as decimal(18, 2))      as unit_price,
    cast(cast(quantity as integer) * cast(unit_price as decimal(18, 2))
         as decimal(18, 2))                 as line_amount
from {{ ref('raw_order_items') }}
