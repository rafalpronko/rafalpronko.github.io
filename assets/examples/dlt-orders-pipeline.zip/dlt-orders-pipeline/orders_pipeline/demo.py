"""Three runs against the local fake API: initial load, identical replay, update + new row.

    uv run python -m orders_pipeline.demo
"""
import sys
import tempfile
from pathlib import Path

from orders_pipeline.fake_api import FakeOrdersApi
from orders_pipeline.pipeline import BUSINESS_COLUMNS, business_rows, load_ids, run_pipeline

ORDERS = [
    {"order_id": 1, "status": "paid", "amount_cents": 1999, "version": 1, "updated_at": "2023-10-20T10:00:00Z"},
    {"order_id": 2, "status": "pending", "amount_cents": 4500, "version": 1, "updated_at": "2023-10-20T10:05:00Z"},
    {"order_id": 3, "status": "paid", "amount_cents": 1200, "version": 1, "updated_at": "2023-10-20T10:10:00Z"},
]


def show(title, db):
    print(f"--- {title}")
    print("   ", tuple(BUSINESS_COLUMNS))
    for row in business_rows(**db):
        print("   ", row)
    print("    _dlt_load_id values in orders:", load_ids(**db))


def main(workdir=None):
    workdir = Path(workdir or tempfile.mkdtemp(prefix="orders-demo-"))
    db = {"db_path": workdir / "orders.duckdb", "pipelines_dir": workdir / "dlt"}
    api = FakeOrdersApi(orders=[dict(o) for o in ORDERS], page_size=2)
    api.start()
    try:
        run_pipeline(api.url, **db)
        show("run 1: initial load", db)

        run_pipeline(api.url, **db)
        show("run 2: identical replay", db)

        api.orders[1].update(status="paid", version=2, updated_at="2023-10-21T09:00:00Z")
        api.orders.append({"order_id": 4, "status": "pending", "amount_cents": 800, "version": 1, "updated_at": "2023-10-21T09:01:00Z"})
        run_pipeline(api.url, **db)
        show("run 3: update order 2, add order 4", db)
    finally:
        api.stop()
    print(f"DuckDB file: {db['db_path']}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else None)
