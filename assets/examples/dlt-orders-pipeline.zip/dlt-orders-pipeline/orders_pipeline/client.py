"""HTTP client for the orders API: pagination contract, bounded timeout, business validation."""
from datetime import datetime

import requests

STATUSES = {"pending", "paid", "refunded", "cancelled"}
REQUIRED = ("order_id", "status", "amount_cents", "version", "updated_at")


class ContractError(ValueError):
    """The API answered, but not in the shape (or with the values) we agreed on."""


def _positive_int(value):
    return isinstance(value, int) and not isinstance(value, bool) and value > 0


def parse_updated_at(value):
    """ISO 8601 with date AND time and an explicit timezone (`Z` or a numeric offset)."""
    if not isinstance(value, str) or "T" not in value:
        raise ValueError("expected an ISO 8601 string with date and time")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("timezone required (Z or +HH:MM)")
    return parsed


def validate_order(order):
    missing = [f for f in REQUIRED if f not in order]
    if missing:
        raise ContractError(f"order missing fields: {missing}")
    if not _positive_int(order["order_id"]):
        raise ContractError(f"bad order_id: {order['order_id']!r}")
    if order["status"] not in STATUSES:
        raise ContractError(f"order {order['order_id']}: unknown status {order['status']!r}")
    amount = order["amount_cents"]
    if not isinstance(amount, int) or isinstance(amount, bool) or amount < 0:
        raise ContractError(f"order {order['order_id']}: bad amount_cents {amount!r}")
    if not _positive_int(order["version"]):
        raise ContractError(f"order {order['order_id']}: bad version {order['version']!r}")
    try:
        parse_updated_at(order["updated_at"])
    except ValueError as exc:
        raise ContractError(f"order {order['order_id']}: bad updated_at {order['updated_at']!r} ({exc})") from None
    return {f: order[f] for f in REQUIRED}  # drop undeclared fields


def fetch_orders(base_url, timeout=5.0, max_pages=100, session=None):
    """Yield validated orders page by page. Any HTTP/contract problem raises; nothing is skipped."""
    http = session or requests.Session()
    seen = set()
    page = 1
    for _ in range(max_pages):
        response = http.get(f"{base_url}/orders", params={"page": page}, timeout=timeout)
        response.raise_for_status()
        try:
            body = response.json()
        except ValueError:
            raise ContractError(f"page {page}: body is not JSON") from None
        if not isinstance(body, dict) or not isinstance(body.get("data"), list):
            raise ContractError(f"page {page}: expected an object with a 'data' list")
        missing = [k for k in ("page", "next_page") if k not in body]
        if missing:
            raise ContractError(f"page {page}: missing pagination fields {missing}")
        if not isinstance(body["page"], int) or isinstance(body["page"], bool) or body["page"] != page:
            raise ContractError(f"page {page}: page echo is {body['page']!r}, expected {page}")
        next_page = body["next_page"]
        if next_page is not None and (not isinstance(next_page, int) or isinstance(next_page, bool)):
            raise ContractError(f"page {page}: next_page={next_page!r} is not an integer or null")
        for raw in body["data"]:
            order = validate_order(raw)
            if order["order_id"] in seen:
                raise ContractError(f"duplicate order_id {order['order_id']} within one run")
            seen.add(order["order_id"])
            yield order
        if next_page is None:
            return
        if next_page != page + 1:
            raise ContractError(f"page {page}: next_page={next_page!r}, expected {page + 1} or null")
        page = next_page
    raise ContractError(f"more than max_pages={max_pages} pages; refusing to continue")
