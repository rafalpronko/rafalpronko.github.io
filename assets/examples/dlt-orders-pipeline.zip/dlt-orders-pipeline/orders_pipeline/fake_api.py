"""Synthetic paginated orders API on 127.0.0.1 (stdlib only, no network beyond loopback).

GET /orders?page=N  ->  {"data": [...], "page": N, "next_page": N+1 | null}
`mode` switches failure behaviour for tests: ok, http_500, slow, not_json, missing_data, skip_page,
no_next_page, wrong_page_echo.
"""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse


class FakeOrdersApi:
    def __init__(self, orders, page_size=2):
        self.orders = orders
        self.page_size = page_size
        self.mode = "ok"
        self.requested_pages = []
        self._server = ThreadingHTTPServer(("127.0.0.1", 0), self._handler())
        self._server.daemon_threads = True
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)

    @property
    def url(self):
        host, port = self._server.server_address
        return f"http://{host}:{port}"

    def start(self):
        self._thread.start()

    def stop(self):
        self._server.shutdown()
        self._server.server_close()

    def _page(self, page):
        start = (page - 1) * self.page_size
        chunk = self.orders[start : start + self.page_size]
        has_more = start + self.page_size < len(self.orders)
        next_page = page + 1 if has_more else None
        if self.mode == "skip_page" and next_page:
            next_page += 1
        return {"data": chunk, "page": page, "next_page": next_page}

    def _handler(self):
        api = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):  # keep test output quiet
                pass

            def do_GET(self):
                parsed = urlparse(self.path)
                if parsed.path != "/orders":
                    return self._send(404, b'{"error": "not found"}')
                page = int(parse_qs(parsed.query).get("page", ["1"])[0])
                api.requested_pages.append(page)
                if api.mode == "http_500":
                    return self._send(500, b'{"error": "boom"}')
                if api.mode == "slow":
                    time.sleep(3)
                if api.mode == "not_json":
                    return self._send(200, b"<html>maintenance</html>", "text/html")
                body = api._page(page)
                if api.mode == "missing_data":
                    body = {"items": body["data"], "next_page": body["next_page"]}
                if api.mode == "no_next_page":
                    del body["next_page"]
                if api.mode == "wrong_page_echo":
                    body["page"] = page - 1
                self._send(200, json.dumps(body).encode())

            def _send(self, status, payload, content_type="application/json"):
                try:
                    self.send_response(status)
                    self.send_header("Content-Type", content_type)
                    self.send_header("Content-Length", str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                except (BrokenPipeError, ConnectionResetError):
                    pass  # client gave up (timeout test)

        return Handler
