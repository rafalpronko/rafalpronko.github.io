"""Load orders from the HTTP API into DuckDB with dlt (merge on order_id)."""
import os

os.environ.setdefault("RUNTIME__DLTHUB_TELEMETRY", "false")  # no anonymous telemetry from the demo

import dlt  # noqa: E402
import duckdb  # noqa: E402

from orders_pipeline.client import fetch_orders  # noqa: E402

DATASET = "shop"
BUSINESS_COLUMNS = ["order_id", "status", "amount_cents", "version", "updated_at"]


def current_versions(db_path):
    """order_id -> version already in the destination (empty before the first load)."""
    if not os.path.exists(db_path):
        return {}
    con = duckdb.connect(str(db_path), read_only=True)
    try:
        return dict(con.execute(f"SELECT order_id, version FROM {DATASET}.orders").fetchall())
    except duckdb.CatalogException:
        return {}
    finally:
        con.close()


def drop_stale(orders, known):
    """Version guard: skip records whose version is not newer than what is loaded."""
    for order in orders:
        if order["version"] > known.get(order["order_id"], 0):
            yield order


def run_pipeline(base_url, db_path, pipelines_dir, timeout=5.0, version_guard=False):
    orders = fetch_orders(base_url, timeout=timeout)
    if version_guard:
        orders = drop_stale(orders, current_versions(db_path))
    resource = dlt.resource(
        orders,
        name="orders",
        primary_key="order_id",
        write_disposition="merge",
        columns={"updated_at": {"data_type": "text"}},  # keep the API string as-is
    )
    pipeline = dlt.pipeline(
        pipeline_name="orders",
        pipelines_dir=str(pipelines_dir),
        destination="duckdb",
        credentials=str(db_path),
        dataset_name=DATASET,
    )
    return pipeline.run(resource)


def _query(db_path, sql):
    con = duckdb.connect(str(db_path), read_only=True)
    try:
        return con.execute(sql).fetchall()
    finally:
        con.close()


def business_rows(db_path, pipelines_dir=None):
    cols = ", ".join(BUSINESS_COLUMNS)
    return _query(db_path, f"SELECT {cols} FROM {DATASET}.orders ORDER BY order_id")


def load_ids(db_path, pipelines_dir=None):
    return sorted(r[0] for r in _query(db_path, f"SELECT DISTINCT _dlt_load_id FROM {DATASET}.orders"))


def completed_loads(db_path):
    """Number of load packages dlt recorded as completed (status 0) in this dataset."""
    return _query(db_path, f"SELECT count(*) FROM {DATASET}._dlt_loads WHERE status = 0")[0][0]
