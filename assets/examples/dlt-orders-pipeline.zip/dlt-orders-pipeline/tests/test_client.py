"""Contract tests for the HTTP client: pagination, validation, failures. No dlt involved."""
import time

import pytest
import requests

from orders_pipeline.client import ContractError, fetch_orders, parse_updated_at, validate_order


def test_follows_pagination_until_next_page_is_null(api):
    orders = list(fetch_orders(api.url, timeout=2))
    assert [o["order_id"] for o in orders] == [1, 2, 3]
    assert api.requested_pages == [1, 2]


def test_http_error_is_raised_not_swallowed(api):
    api.mode = "http_500"
    with pytest.raises(requests.HTTPError):
        list(fetch_orders(api.url, timeout=2))


def test_request_timeout_is_bounded(api):
    api.mode = "slow"  # server sleeps 3 s before answering
    started = time.monotonic()
    with pytest.raises(requests.Timeout):
        list(fetch_orders(api.url, timeout=0.5))
    assert time.monotonic() - started < 2.5


def test_non_json_body_is_a_contract_error(api):
    api.mode = "not_json"
    with pytest.raises(ContractError, match="not JSON"):
        list(fetch_orders(api.url, timeout=2))


def test_missing_data_key_is_a_contract_error(api):
    api.mode = "missing_data"
    with pytest.raises(ContractError, match="data"):
        list(fetch_orders(api.url, timeout=2))


def test_skipped_page_is_a_contract_error(api):
    api.mode = "skip_page"  # page 1 says next_page=3
    with pytest.raises(ContractError, match="next_page"):
        list(fetch_orders(api.url, timeout=2))


def test_missing_next_page_key_is_a_contract_error(api):
    api.mode = "no_next_page"  # an absent key is not the same as an explicit null
    with pytest.raises(ContractError, match="next_page"):
        list(fetch_orders(api.url, timeout=2))


def test_wrong_page_echo_is_a_contract_error(api):
    api.mode = "wrong_page_echo"  # page 1 answers with "page": 0
    with pytest.raises(ContractError, match="page echo"):
        list(fetch_orders(api.url, timeout=2))


def test_max_pages_bound(api):
    with pytest.raises(ContractError, match="max_pages"):
        list(fetch_orders(api.url, timeout=2, max_pages=1))


def test_duplicate_order_id_in_one_run_is_rejected(api):
    api.orders.append(dict(api.orders[0]))
    with pytest.raises(ContractError, match="duplicate"):
        list(fetch_orders(api.url, timeout=2))


@pytest.mark.parametrize(
    "patch, message",
    [
        ({"order_id": 0}, "order_id"),
        ({"order_id": "1"}, "order_id"),
        ({"status": "lost"}, "status"),
        ({"amount_cents": -1}, "amount_cents"),
        ({"amount_cents": 10.5}, "amount_cents"),
        ({"version": 0}, "version"),
        ({"updated_at": "yesterday"}, "updated_at"),
        ({"updated_at": "2023-10-20"}, "updated_at"),  # date only
        ({"updated_at": 20231020}, "updated_at"),  # not a string
        ({"updated_at": True}, "updated_at"),
        ({"updated_at": "2023-10-20T10:00:00"}, "updated_at"),  # naive, no timezone
    ],
)
def test_business_validation(patch, message):
    order = {"order_id": 1, "status": "paid", "amount_cents": 100, "version": 1, "updated_at": "2023-10-20T10:00:00Z"}
    order.update(patch)
    with pytest.raises(ContractError, match=message):
        validate_order(order)


def test_numeric_offset_is_accepted_and_equals_utc():
    order = {"order_id": 1, "status": "paid", "amount_cents": 100, "version": 1, "updated_at": "2023-10-20T12:00:00+02:00"}
    assert validate_order(order)["updated_at"] == "2023-10-20T12:00:00+02:00"  # kept as sent
    assert parse_updated_at("2023-10-20T12:00:00+02:00") == parse_updated_at("2023-10-20T10:00:00Z")


def test_missing_field_is_rejected():
    with pytest.raises(ContractError, match="missing"):
        validate_order({"order_id": 1})
