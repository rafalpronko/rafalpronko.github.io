"""Rerun tests: the pipeline loads into a temporary DuckDB file through dlt merge."""
import pytest

from orders_pipeline.pipeline import BUSINESS_COLUMNS, business_rows, completed_loads, load_ids, run_pipeline


@pytest.fixture
def db(tmp_path):
    return {"db_path": tmp_path / "orders.duckdb", "pipelines_dir": tmp_path / "dlt"}


def test_identical_replay_preserves_business_columns(api, db):
    run_pipeline(api.url, **db)
    first = business_rows(**db)
    first_load_ids = load_ids(**db)

    run_pipeline(api.url, **db)
    second = business_rows(**db)

    assert len(first) == 3
    assert second == first  # business columns identical, no duplicates
    # dlt metadata is NOT stable: delete-insert rewrote every row with the new load id
    assert load_ids(**db) != first_load_ids


def test_update_plus_new_row(api, db):
    run_pipeline(api.url, **db)
    api.orders[1].update(status="paid", version=2, updated_at="2023-10-21T09:00:00Z")
    api.orders.append({"order_id": 4, "status": "pending", "amount_cents": 800, "version": 1, "updated_at": "2023-10-21T09:01:00Z"})

    run_pipeline(api.url, **db)
    rows = {r[0]: dict(zip(BUSINESS_COLUMNS, r)) for r in business_rows(**db)}

    assert sorted(rows) == [1, 2, 3, 4]
    assert rows[2]["status"] == "paid" and rows[2]["version"] == 2
    assert rows[4]["amount_cents"] == 800


@pytest.mark.parametrize("mode", ["not_json", "missing_data", "http_500"])
def test_failed_extract_leaves_destination_unchanged(api, db, mode):
    run_pipeline(api.url, **db)
    before = business_rows(**db)

    api.orders[0]["status"] = "refunded"
    api.mode = mode
    with pytest.raises(Exception):
        run_pipeline(api.url, **db)

    assert business_rows(**db) == before


def test_invalid_record_fails_the_whole_run(api, db):
    run_pipeline(api.url, **db)
    before = business_rows(**db)
    api.orders[2]["amount_cents"] = -5
    api.orders[0]["status"] = "refunded"  # a valid change on another page is not loaded either

    with pytest.raises(Exception):
        run_pipeline(api.url, **db)
    assert business_rows(**db) == before


def test_stale_version_regresses_state_without_guard(api, db):
    """Documents the limitation: primary_key is identity, not freshness."""
    api.orders[0].update(status="refunded", version=3)
    run_pipeline(api.url, **db)

    api.orders[0].update(status="paid", version=2)  # late, older event
    run_pipeline(api.url, **db)

    row = [r for r in business_rows(**db) if r[0] == 1][0]
    assert row[BUSINESS_COLUMNS.index("version")] == 2  # state went backwards


def test_version_guard_drops_stale_rows(api, db):
    api.orders[0].update(status="refunded", version=3)
    run_pipeline(api.url, version_guard=True, **db)

    api.orders[0].update(status="paid", version=2)
    api.orders[1].update(status="paid", version=2)  # a genuine newer update still lands
    run_pipeline(api.url, version_guard=True, **db)

    rows = {r[0]: dict(zip(BUSINESS_COLUMNS, r)) for r in business_rows(**db)}
    assert rows[1]["version"] == 3 and rows[1]["status"] == "refunded"
    assert rows[2]["version"] == 2


def test_rerun_after_failure_recovers(api, db):
    """A failed run must not leave a half-extracted package that a later run loads."""
    run_pipeline(api.url, **db)
    api.orders[0]["status"] = "refunded"
    api.orders[2]["amount_cents"] = -5  # page 2 is invalid, page 1 was already extracted
    with pytest.raises(Exception):
        run_pipeline(api.url, **db)

    api.orders[2]["amount_cents"] = 1200  # source fixed
    api.orders[0].update(status="paid", version=1)  # and the refund was withdrawn
    run_pipeline(api.url, **db)

    rows = {r[0]: dict(zip(BUSINESS_COLUMNS, r)) for r in business_rows(**db)}
    assert rows[1]["status"] == "paid"
    assert len(rows) == 3
    assert completed_loads(db["db_path"]) == 2  # first run + recovery run, no partial package
