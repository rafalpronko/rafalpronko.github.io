from orders_pipeline import demo


def test_demo_prints_three_runs(tmp_path, capsys):
    demo.main(workdir=tmp_path)
    out = capsys.readouterr().out
    assert "run 1: initial load" in out
    assert "run 2: identical replay" in out
    assert "run 3: update order 2, add order 4" in out
    assert "(4, 'pending', 800, 1, '2023-10-21T09:01:00Z')" in out
