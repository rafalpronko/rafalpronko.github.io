import pytest

from orders_pipeline.fake_api import FakeOrdersApi

BASE_ORDERS = [
    {"order_id": 1, "status": "paid", "amount_cents": 1999, "version": 1, "updated_at": "2023-10-20T10:00:00Z"},
    {"order_id": 2, "status": "pending", "amount_cents": 4500, "version": 1, "updated_at": "2023-10-20T10:05:00Z"},
    {"order_id": 3, "status": "paid", "amount_cents": 1200, "version": 1, "updated_at": "2023-10-20T10:10:00Z"},
]


@pytest.fixture
def api():
    server = FakeOrdersApi(orders=[dict(o) for o in BASE_ORDERS], page_size=2)
    server.start()
    yield server
    server.stop()
