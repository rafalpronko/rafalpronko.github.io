# dlt-orders-pipeline

A small API-to-DuckDB pipeline with [dlt](https://dlthub.com/) and a rerun test.
Companion code for the article *A small API-to-database pipeline with dlt — and a rerun test*.

- `orders_pipeline/fake_api.py` — synthetic paginated orders API on `127.0.0.1` (standard library only).
- `orders_pipeline/client.py` — HTTP client: bounded timeout, pagination contract, business validation.
- `orders_pipeline/pipeline.py` — dlt resource with `primary_key="order_id"`, `write_disposition="merge"`, DuckDB destination; optional version guard.
- `orders_pipeline/demo.py` — three runs: initial load, identical replay, update + new row.
- `tests/` — pytest: client contract, rerun behaviour, failure handling, stale-version limitation.

## Versions

Pinned to what was on PyPI in October 2023: `dlt[duckdb]==0.3.22` (uploaded 2023-10-24), `duckdb==0.9.1`,
`pytest==7.4.3`, Python 3.11. `uv.lock` was resolved with `exclude-newer = "2023-10-25T00:00:00Z"`.
`uv` is only the reproduction tool; any recent version that reads the lock file works.

## Run

With a plain virtual environment (`requirements.txt` is exported from `uv.lock`, with hashes):

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install --require-hashes -r requirements.txt
export RUNTIME__DLTHUB_TELEMETRY=false   # the code sets this too; dlt 0.3.x telemetry is on by default
.venv/bin/python -m orders_pipeline.demo
.venv/bin/python -m pytest -v
```

Or with uv:

```bash
export RUNTIME__DLTHUB_TELEMETRY=false
uv run --frozen --python 3.11 python -m orders_pipeline.demo
uv run --frozen --python 3.11 pytest -v
```

`pendulum==2.1.2` has no wheel for every platform and may be built from source during install.

The demo writes a DuckDB file to a new temporary directory and prints its path.
No credentials, no external network calls: the API listens on loopback with a random port.
The full test suite (33 tests) takes from about 20 seconds to a few minutes, mostly dlt start-up per run.

## What the tests do *not* prove

- Exactly-once delivery. Reruns are safe for business columns because merge deletes and re-inserts by key.
- Freshness. `primary_key` is identity only; an older version loaded later overwrites a newer one
  (`test_stale_version_regresses_state_without_guard`). The version guard in `pipeline.py` reads current
  versions before the load and is not safe against two concurrent runs.
- Behaviour of other dlt versions or destinations.
