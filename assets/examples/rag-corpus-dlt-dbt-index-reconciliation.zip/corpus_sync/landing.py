"""Land source data in DuckDB with dlt 0.4.2."""
from dataclasses import dataclass
from pathlib import Path

import dlt
import duckdb


@dataclass(frozen=True)
class Workspace:
    root: Path

    @property
    def duckdb_path(self) -> Path:
        return self.root / "warehouse.duckdb"

    @property
    def index_path(self) -> Path:
        return self.root / "index.sqlite"

    @property
    def pipelines_dir(self) -> Path:
        return self.root / "dlt-pipelines"


def _pipeline(ws: Workspace, name: str, dataset: str):
    return dlt.pipeline(
        pipeline_name=name,
        pipelines_dir=str(ws.pipelines_dir),
        destination=dlt.destinations.duckdb(str(ws.duckdb_path)),
        dataset_name=dataset,
    )


class SnapshotError(Exception):
    """The listing broke its contract, or a landing attempt cannot be trusted."""


def discard_pending_packages(ws: Workspace) -> list[str]:
    """Drop load packages that a crashed earlier attempt left behind.

    In dlt 0.4.2, `run()` first loads pending packages and then returns
    without extracting the data it was given. A leftover is never loaded
    here: its rows may already have landed in part, but an attempt that
    crashed before its manifest load committed has no manifest and is never
    selected. Dropping local packages does not erase rows or manifests that
    were already committed in DuckDB; such a manifest is a valid snapshot,
    because its rows landed first.
    """
    pipeline = _pipeline(ws, "corpus_snapshots", "landing")
    pending = [*pipeline.list_extracted_load_packages(),
               *pipeline.list_normalized_load_packages()]
    if pending:
        pipeline.drop_pending_packages(with_partial_loads=True)
    return pending


def _load_now(pipeline, data, **kwargs):
    """`run()` that must extract and load exactly `data`, with no failed job."""
    if pipeline.has_pending_data:
        raise SnapshotError("pending dlt packages would be loaded instead of this data")
    info = pipeline.run(data, **kwargs)
    info.raise_on_failed_jobs()  # dlt 0.4.2 does not raise for terminal job failures
    if pipeline.has_pending_data:
        raise SnapshotError("dlt left packages pending after the load")
    return info


def _attempt_used(ws: Workspace, snapshot_id: str) -> bool:
    """True if rows or a manifest with this attempt ID already landed."""
    if not ws.duckdb_path.exists():
        return False
    con = duckdb.connect(str(ws.duckdb_path), read_only=True)
    try:
        tables = {r[0] for r in con.execute(
            "select table_name from information_schema.tables "
            "where table_schema = 'landing'").fetchall()}
        return any(con.execute(f"select 1 from landing.{table} where snapshot_id = ? limit 1",
                               [snapshot_id]).fetchone()
                   for table in ("snapshot_rows", "snapshot_manifests") if table in tables)
    finally:
        con.close()


def land_snapshot(ws: Workspace, api, tenant: str, snapshot_id: str) -> dict:
    """Append one tenant snapshot, then append its manifest.

    Rows land first. The manifest lands only after the row load succeeded,
    so rows without a manifest are never treated as a snapshot. Whether the
    snapshot is *complete* is decided from the source contract, not from
    the fact that the loop ended. Every attempt needs a fresh `snapshot_id`.
    """
    if _attempt_used(ws, snapshot_id):
        raise SnapshotError(f"{snapshot_id}: attempt ID already landed; use a fresh one")
    manifest = {}

    @dlt.resource(name="snapshot_rows", write_disposition="append")
    def snapshot_rows():
        token, pages, seen, as_of, total = None, 0, set(), None, None
        while True:
            page = api.list_page(tenant, token)
            pages += 1
            if as_of is None:
                as_of, total = page["as_of"], page["total"]
            elif page["as_of"] != as_of or page["total"] != total:
                raise SnapshotError(f"{tenant}: listing changed between pages")
            for item in page["items"]:
                if item["doc_id"] in seen:
                    raise SnapshotError(f"{tenant}: duplicate {item['doc_id']}")
                seen.add(item["doc_id"])
                yield {**item, "tenant": tenant, "snapshot_id": snapshot_id}
            token = page["next_page_token"]
            if token is None:
                break
        manifest.update(
            tenant=tenant, snapshot_id=snapshot_id, as_of=as_of, pages=pages,
            declared_total=total, row_count=len(seen),
            complete=len(seen) == total,
        )

    pipeline = _pipeline(ws, "corpus_snapshots", "landing")
    _load_now(pipeline, snapshot_rows())
    if not manifest:
        raise SnapshotError(f"{tenant}: extractor did not run; no manifest written")
    _load_now(pipeline, [manifest], table_name="snapshot_manifests",
              write_disposition="append")
    return manifest


def land_feed_page(ws: Workspace, events: list[dict]):
    """Merge one page of a change feed by doc_id with a cursor on updated_at."""

    @dlt.resource(name="feed_documents", write_disposition="merge",
                  primary_key="doc_id")
    def feed_documents(
        updated_at=dlt.sources.incremental("updated_at", initial_value=0),
    ):
        yield from events

    return _pipeline(ws, "corpus_feed", "feed").run(feed_documents())
