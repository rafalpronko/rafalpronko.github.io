"""Run the dbt project and read its outputs from DuckDB."""
import os
from pathlib import Path

import duckdb
from dbt.cli.main import dbtRunner

from .landing import Workspace

PROJECT_DIR = Path(__file__).resolve().parent.parent / "dbt_project"


class DbtFailed(Exception):
    pass


def dbt_build(ws: Workspace, selector: str) -> None:
    """`dbt build` = run models and their tests; any failure stops the sync."""
    os.environ["CORPUS_DUCKDB"] = str(ws.duckdb_path)
    result = dbtRunner().invoke([
        "--quiet", "build", "--select", selector,
        "--project-dir", str(PROJECT_DIR),
        "--profiles-dir", str(PROJECT_DIR),
        "--target-path", str(ws.root / "dbt-target"),
        "--log-path", str(ws.root / "dbt-logs"),
    ])
    if not result.success:
        raise DbtFailed(f"dbt build --select {selector} failed: {result.exception}")


def query(ws: Workspace, sql: str, params=()):
    con = duckdb.connect(str(ws.duckdb_path), read_only=True)
    try:
        return con.execute(sql, list(params)).fetchall()
    finally:
        con.close()


def desired_state(ws: Workspace, tenant: str):
    """Return (latest complete snapshot or None, {doc_id: document dict})."""
    snap = query(ws, "select snapshot_id, as_of from main.latest_complete_snapshots "
                     "where tenant = ?", [tenant])
    if not snap:
        return None, {}
    rows = query(ws, "select doc_id, revision, title, body, acl, content_hash "
                     "from main.desired_documents where tenant = ?", [tenant])
    keys = ("doc_id", "revision", "title", "body", "acl", "content_hash")
    docs = {r[0]: dict(zip(keys, r)) for r in rows}
    return {"snapshot_id": snap[0][0], "as_of": snap[0][1]}, docs
