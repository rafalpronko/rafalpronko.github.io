"""Local lexical index (SQLite FTS5) with generations and safe promotion.

This is an exact keyword index, not a vector store. `encode` stands in for
the expensive per-chunk step (an embedding call in a real RAG system) so the
demo can count how much work reuse saves. No embeddings are computed here.
"""
import hashlib
import json
import sqlite3

INDEX_SPEC = {"chunker": "words-v1", "chunk_words": 8, "representation": "fts5"}

SCHEMA = """
create table if not exists generations (
    generation_id integer primary key,
    tenant text not null,
    snapshot_id text not null,
    as_of integer not null,
    index_spec text not null,
    status text not null check (status in ('building', 'serving', 'retired'))
);
create table if not exists chunks (
    generation_id integer not null,
    chunk_id text not null,
    tenant text not null,
    doc_id text not null,
    revision integer not null,
    content_hash text not null,
    acl text not null,
    ordinal integer not null,
    text text not null,
    primary key (generation_id, chunk_id)
);
create virtual table if not exists chunk_fts
    using fts5(text, chunk_id unindexed, generation_id unindexed);
-- One row per tenant: the serving alias AND the committed checkpoint.
create table if not exists serving (
    tenant text primary key,
    generation_id integer not null,
    snapshot_id text not null,
    as_of integer not null
);
"""


class IndexValidationError(Exception):
    pass


class PromotionConflict(Exception):
    pass


def connect(path) -> sqlite3.Connection:
    con = sqlite3.connect(str(path), isolation_level=None)  # explicit BEGIN/COMMIT
    con.executescript(SCHEMA)
    return con


def spec_key(spec: dict) -> str:
    return json.dumps(spec, sort_keys=True)


def chunk_text(title: str, body: str, spec: dict) -> list[str]:
    words = body.split()
    size = spec["chunk_words"]
    return [f"{title}: " + " ".join(words[i:i + size])
            for i in range(0, max(len(words), 1), size)]


def chunk_id(tenant, doc_id, content_hash, spec, ordinal) -> str:
    """Same tenant, document content, chunker and position -> same ID."""
    raw = json.dumps([tenant, doc_id, content_hash, spec_key(spec), ordinal],
                     ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(raw.encode()).hexdigest()


def serving_row(con, tenant):
    row = con.execute(
        "select s.generation_id, s.snapshot_id, s.as_of, g.index_spec "
        "from serving s join generations g using (generation_id) "
        "where s.tenant = ?", (tenant,)).fetchone()
    if row is None:
        return None
    keys = ("generation_id", "snapshot_id", "as_of", "index_spec")
    return dict(zip(keys, row))


def generation_docs(con, generation_id) -> dict:
    rows = con.execute(
        "select doc_id, revision, content_hash, acl from chunks "
        "where generation_id = ? group by doc_id, revision, content_hash, acl",
        (generation_id,)).fetchall()
    return {r[0]: {"revision": r[1], "content_hash": r[2], "acl": r[3]} for r in rows}


def plan(desired: dict, current: dict) -> dict:
    """Desired-state comparison: what must change to make current == desired."""
    out = {"added": [], "content_changed": [], "metadata_changed": [],
           "removed": sorted(set(current) - set(desired)), "unchanged": []}
    for doc_id in sorted(desired):
        want, have = desired[doc_id], current.get(doc_id)
        if have is None:
            out["added"].append(doc_id)
        elif want["content_hash"] != have["content_hash"]:
            out["content_changed"].append(doc_id)
        elif (want["acl"], want["revision"]) != (have["acl"], have["revision"]):
            out["metadata_changed"].append(doc_id)
        else:
            out["unchanged"].append(doc_id)
    return out


def collect_garbage(con, tenant) -> None:
    """Drop abandoned builds and retired generations (single writer assumed)."""
    ids = [r[0] for r in con.execute(
        "select generation_id from generations "
        "where tenant = ? and status in ('building', 'retired')", (tenant,))]
    for gid in ids:
        with_transaction(con, lambda: _drop_generation(con, gid))


def _drop_generation(con, gid):
    con.execute("delete from chunk_fts where generation_id = ?", (gid,))
    con.execute("delete from chunks where generation_id = ?", (gid,))
    con.execute("delete from generations where generation_id = ?", (gid,))


def with_transaction(con, work):
    con.execute("begin immediate")
    try:
        result = work()
    except BaseException:
        con.execute("rollback")
        raise
    con.execute("commit")
    return result


def _insert_chunk(con, gid, tenant, doc_id, doc, ordinal, text, cid):
    con.execute("insert into chunks values (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (gid, cid, tenant, doc_id, doc["revision"], doc["content_hash"],
                 doc["acl"], ordinal, text))
    con.execute("insert into chunk_fts (text, chunk_id, generation_id) "
                "values (?, ?, ?)", (text, cid, gid))


def build_generation(con, tenant, snapshot, desired, spec, current, encode):
    """Write a complete new generation next to the serving one.

    Each document is committed separately, like calls to a remote store
    that has no multi-document transaction. A crash leaves a 'building'
    generation that nobody serves and the next run deletes.
    """
    gid = with_transaction(con, lambda: con.execute(
        "insert into generations (tenant, snapshot_id, as_of, index_spec, status) "
        "values (?, ?, ?, ?, 'building')",
        (tenant, snapshot["snapshot_id"], snapshot["as_of"], spec_key(spec)),
    ).lastrowid)
    same_spec = current is not None and current["index_spec"] == spec_key(spec)
    old = generation_docs(con, current["generation_id"]) if same_spec else {}
    stats = {"encoded": 0, "reused": 0}

    for doc_id in sorted(desired):
        doc = desired[doc_id]
        if old.get(doc_id, {}).get("content_hash") == doc["content_hash"]:
            rows = con.execute(
                "select ordinal, text, chunk_id from chunks where generation_id = ? "
                "and doc_id = ? order by ordinal",
                (current["generation_id"], doc_id)).fetchall()
            stats["reused"] += len(rows)
        else:
            texts = chunk_text(doc["title"], doc["body"], spec)
            rows = [(i, t, chunk_id(tenant, doc_id, doc["content_hash"], spec, i))
                    for i, t in enumerate(texts)]
            for _, text, _ in rows:
                encode(text)  # the step a vector index would pay for
            stats["encoded"] += len(rows)
        with_transaction(con, lambda: [
            _insert_chunk(con, gid, tenant, doc_id, doc, i, t, cid)
            for i, t, cid in rows])
    return gid, stats


def validate_generation(con, gid, desired) -> None:
    """Compare every chunk field and FTS text with the derived desired state."""
    generation = con.execute("select tenant, index_spec from generations "
                             "where generation_id = ?", (gid,)).fetchone()
    if generation is None:
        raise IndexValidationError(f"generation {gid}: missing generation")
    tenant, raw_spec = generation
    spec = json.loads(raw_spec)
    want = []
    for doc_id, doc in desired.items():
        for ordinal, text in enumerate(chunk_text(doc["title"], doc["body"], spec)):
            cid = chunk_id(tenant, doc_id, doc["content_hash"], spec, ordinal)
            want.append((tenant, doc_id, doc["revision"], doc["content_hash"],
                         doc["acl"], ordinal, text, cid))
    got = con.execute("select tenant, doc_id, revision, content_hash, acl, ordinal, "
                      "text, chunk_id from chunks where generation_id = ?", (gid,)).fetchall()
    if sorted(got) != sorted(want):
        raise IndexValidationError(f"generation {gid} != desired chunks")
    in_fts = con.execute("select chunk_id, text from chunk_fts "
                         "where generation_id = ?", (gid,)).fetchall()
    if sorted(in_fts) != sorted((row[7], row[6]) for row in want):
        raise IndexValidationError(f"generation {gid}: FTS and desired text disagree")


def promote(con, tenant, gid, snapshot, expected_gid) -> None:
    """Switch the alias and commit the checkpoint in one transaction."""
    def work():
        row = con.execute("select generation_id from serving where tenant = ?",
                          (tenant,)).fetchone()
        if (row[0] if row else None) != expected_gid:
            raise PromotionConflict(f"{tenant}: serving generation moved")
        candidate = con.execute("select tenant, snapshot_id, as_of, status "
                                "from generations where generation_id = ?", (gid,)).fetchone()
        if candidate != (tenant, snapshot["snapshot_id"], snapshot["as_of"], "building"):
            raise IndexValidationError(f"generation {gid}: candidate does not match promotion")
        con.execute(
            "insert into serving values (?, ?, ?, ?) on conflict (tenant) do update "
            "set generation_id = excluded.generation_id, "
            "snapshot_id = excluded.snapshot_id, as_of = excluded.as_of",
            (tenant, gid, snapshot["snapshot_id"], snapshot["as_of"]))
        con.execute("update generations set status = 'retired' "
                    "where tenant = ? and status = 'serving'", (tenant,))
        con.execute("update generations set status = 'serving' "
                    "where generation_id = ?", (gid,))
    with_transaction(con, work)


def reconcile(con, tenant, snapshot, desired, spec=INDEX_SPEC, encode=lambda t: t):
    """Make the serving index of one tenant equal to an authoritative snapshot."""
    collect_garbage(con, tenant)
    if snapshot is None:
        return {"action": "no_complete_snapshot"}
    current = serving_row(con, tenant)
    if current and snapshot["as_of"] < current["as_of"]:
        return {"action": "stale_snapshot_ignored"}
    if current and snapshot["snapshot_id"] == current["snapshot_id"] \
            and current["index_spec"] == spec_key(spec):
        return {"action": "already_current"}
    have = generation_docs(con, current["generation_id"]) if current else {}
    changes = plan(desired, have)
    nothing_to_do = not any(changes[k] for k in
                            ("added", "content_changed", "metadata_changed", "removed"))
    if current and nothing_to_do and current["index_spec"] == spec_key(spec):
        with_transaction(con, lambda: con.execute(
            "update serving set snapshot_id = ?, as_of = ? where tenant = ?",
            (snapshot["snapshot_id"], snapshot["as_of"], tenant)))
        return {"action": "checkpoint_only", "plan": changes}
    gid, stats = build_generation(con, tenant, snapshot, desired, spec, current, encode)
    validate_generation(con, gid, desired)
    promote(con, tenant, gid, snapshot, current["generation_id"] if current else None)
    result = {"action": "promoted", "generation_id": gid, "plan": changes, **stats}
    try:
        collect_garbage(con, tenant)
    except Exception as exc:  # promotion is committed; the next run cleans up first
        result["cleanup"] = f"pending: {type(exc).__name__}"
    return result


def search(con, tenant, text, group, limit=5):
    """Keyword search in the serving generation, ACL-filtered before LIMIT."""
    terms = " ".join('"' + t.replace('"', "") + '"' for t in text.split())
    return con.execute(
        "select c.doc_id, c.chunk_id, c.text from chunk_fts f "
        "join chunks c on c.generation_id = f.generation_id and c.chunk_id = f.chunk_id "
        "join serving s on s.generation_id = c.generation_id "
        "where s.tenant = ? and chunk_fts match ? "
        "and instr(',' || c.acl || ',', ',' || ? || ',') > 0 "
        "order by bm25(chunk_fts), c.chunk_id limit ?",
        (tenant, terms, group, limit)).fetchall()


def serving_chunks(con, tenant):
    """Complete serving content for one tenant, for exact comparisons."""
    return con.execute(
        "select c.doc_id, c.ordinal, c.chunk_id, c.acl, c.text from chunks c "
        "join serving s on s.generation_id = c.generation_id "
        "where s.tenant = ? order by c.doc_id, c.ordinal", (tenant,)).fetchall()
