"""One sync step per tenant: land -> dbt build -> reconcile the index."""
from . import index
from .landing import Workspace, discard_pending_packages, land_snapshot
from .transform import dbt_build, desired_state


def sync_tenant(ws: Workspace, api, tenant: str, snapshot_id: str, **index_kw) -> dict:
    try:
        discarded = discard_pending_packages(ws)  # leftovers of a crashed attempt
        manifest = land_snapshot(ws, api, tenant, snapshot_id)
    except Exception as exc:  # dlt wraps source errors in PipelineStepFailed
        return {"tenant": tenant, "landing": f"failed: {type(exc).__name__}",
                "index": {"action": "not_attempted"}}
    dbt_build(ws, "tag:corpus")
    landing = ("complete" if manifest["complete"] else
               f"incomplete: {manifest['row_count']}/{manifest['declared_total']} rows")
    result = {"tenant": tenant, "landing": landing, **reconcile_tenant(ws, tenant, **index_kw)}
    if discarded:
        result["discarded_pending_packages"] = discarded
    return result


def reconcile_tenant(ws: Workspace, tenant: str, **index_kw) -> dict:
    """Index-only step. Safe to retry: it reads the durable desired state."""
    snapshot, desired = desired_state(ws, tenant)
    con = index.connect(ws.index_path)
    try:
        result = index.reconcile(con, tenant, snapshot, desired, **index_kw)
    finally:
        con.close()
    return {"desired_from": snapshot and snapshot["snapshot_id"], "index": result}
