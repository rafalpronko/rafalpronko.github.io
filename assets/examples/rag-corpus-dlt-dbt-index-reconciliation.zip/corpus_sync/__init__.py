"""Synthetic RAG corpus sync: dlt -> DuckDB -> dbt -> local SQLite FTS5 index."""
import os
from pathlib import Path

# Keep every tool local and silent before dlt or dbt are imported.
_WORK = Path(__file__).resolve().parent.parent / ".work"
os.environ.setdefault("RUNTIME__DLTHUB_TELEMETRY", "false")
os.environ.setdefault("DBT_SEND_ANONYMOUS_USAGE_STATS", "false")
os.environ.setdefault("DLT_DATA_DIR", str(_WORK / "dlt-data"))
