"""An in-memory documents API with paginated snapshots, a change feed and faults."""
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class Doc:
    doc_id: str
    revision: int
    title: str
    body: str
    acl: str  # comma-separated groups allowed to read the document
    status: str = "published"  # "published" or "archived"


class SourceTimeout(Exception):
    """The source stopped answering in the middle of a snapshot."""


class DocsApi:
    """Lists every document of one tenant as of a single source version.

    Contract (the part that makes deletion safe): all pages of one listing
    carry the same `as_of`, `total` is the size of that listing, and the
    last page has `next_page_token=None`.
    """

    def __init__(self, corpus, as_of, page_size=2, faults=None):
        self.corpus = corpus  # {tenant: [Doc, ...]}
        self.as_of = as_of
        self.page_size = page_size
        self.faults = faults or {}  # {tenant: "timeout" | "truncate"}
        self.calls = []

    def list_page(self, tenant, page_token=None):
        start = int(page_token or 0)
        self.calls.append((tenant, start))
        fault = self.faults.get(tenant)
        if fault == "timeout" and start > 0:
            raise SourceTimeout(f"{tenant}: timeout at offset {start}")
        docs = sorted(self.corpus.get(tenant, []), key=lambda d: d.doc_id)
        page = docs[start:start + self.page_size]
        end = start + self.page_size
        next_token = str(end) if end < len(docs) else None
        if fault == "truncate":
            next_token = None  # a buggy source that silently ends early
        return {
            "as_of": self.as_of,
            "total": len(docs),
            "items": [asdict(d) for d in page],
            "next_page_token": next_token,
        }
