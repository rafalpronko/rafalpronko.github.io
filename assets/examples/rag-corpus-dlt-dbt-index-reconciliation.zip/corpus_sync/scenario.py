"""Synthetic corpus versions shared by demo.py and the tests."""
from .source import Doc

HOLIDAY = Doc("holiday-2023", 1, "Holiday closure",
              "The office is closed from 27 to 29 December 2023. "
              "The support rota is posted in the team channel.", "all")
REFUND_V1 = Doc("refund-policy", 1, "Refund policy",
                "Customers may request a refund within 30 days of purchase. "
                "Refunds are paid to the original payment method. Digital goods "
                "are refundable only if they were not downloaded. Contact billing "
                "for exceptions.", "all")
REFUND_V2 = Doc("refund-policy", 2, "Refund policy",
                "Customers may request a refund within 14 days of purchase, "
                "paid to the original payment method.", "all")
VPN_V1 = Doc("vpn-setup", 1, "VPN setup",
             "Install the client, sign in with SSO and pick the nearest gateway. "
             "Report failures to the helpdesk.", "eng,support")
VPN_V2 = Doc("vpn-setup", 2, VPN_V1.title, VPN_V1.body, "eng")  # support loses access
LEGAL = Doc("legal-hold", 1, "Legal hold",
            "Documents under legal hold must not be edited or deleted until "
            "counsel releases the hold.", "legal")
DRAFT = Doc("pricing-draft", 1, "Pricing draft",
            "Unreleased price list for the next quarter.", "all", status="archived")
SSO = Doc("sso-login", 1, "SSO login",
          "Use the company identity provider to sign in to every internal tool.", "all")

ONBOARD_V1 = Doc("onboarding", 1, "Onboarding",
                 "New starters receive a laptop and accounts on day one.", "all")
ONBOARD_V2 = Doc("onboarding", 2, "Onboarding",
                 "New starters receive a laptop, accounts and a buddy on day one.", "all")
EXPENSES = Doc("expenses", 1, "Expenses",
               "Submit receipts within 30 days through the finance portal.", "all")
LAPTOP = Doc("laptop-return", 1, "Laptop return",
             "Return the laptop to IT on your last working day.", "all")

ACME_V1 = [HOLIDAY, REFUND_V1, VPN_V1, LEGAL, DRAFT]
ACME_V2 = [REFUND_V2, VPN_V2, LEGAL, DRAFT]  # holiday deleted at the source
ACME_V3 = ACME_V2 + [SSO]
BETA_V1 = [ONBOARD_V1, EXPENSES, LAPTOP]
BETA_V2 = [ONBOARD_V2, EXPENSES, LAPTOP]

# Change feed: (page label, events). Every event carries `deleted`.
def _event(doc_id, revision, body, updated_at, deleted=False):
    return {"doc_id": doc_id, "revision": revision, "title": doc_id,
            "body": body, "updated_at": updated_at, "deleted": deleted}


FEED_PAGES = [
    ("page 1: three documents", [
        _event("a", 1, "alpha v1", 10), _event("b", 1, "bravo v1", 11),
        _event("c", 1, "charlie v1", 12)]),
    ("page 2: only b changed; a and c are absent from the page", [
        _event("b", 2, "bravo v2", 20)]),
    ("page 3: tombstone for c, plus an edit of a that arrives late (updated_at=15)", [
        _event("c", 2, None, 30, deleted=True), _event("a", 2, "alpha v2", 15)]),
]
