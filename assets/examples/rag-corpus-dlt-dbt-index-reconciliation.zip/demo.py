"""Run the whole synthetic scenario and print what happened at each step.

    env UV_CACHE_DIR=.work/uv-cache uv run --frozen python demo.py   # recreates ./.work/demo
"""
import json
import shutil
import sys
from pathlib import Path

import corpus_sync  # noqa: F401  (sets local, telemetry-free environment)
from corpus_sync import index, scenario as sc
from corpus_sync.landing import Workspace, land_feed_page
from corpus_sync.source import DocsApi
from corpus_sync.sync import reconcile_tenant, sync_tenant
from corpus_sync.transform import dbt_build, query


def serving(ws, tenant):
    con = index.connect(ws.index_path)
    try:
        return index.serving_chunks(con, tenant), index.serving_row(con, tenant)
    finally:
        con.close()


def find(ws, tenant, text, group):
    con = index.connect(ws.index_path)
    try:
        return sorted({doc for doc, _, _ in index.search(con, tenant, text, group)})
    finally:
        con.close()


class EncoderDown(Exception):
    pass


def failing_encoder(text):
    if text.startswith("SSO login"):
        raise EncoderDown("embedding service unavailable")
    return text


def run_snapshot_scenario(ws: Workspace, log=print) -> dict:
    states = {}

    def step(label, results):
        log(f"\n=== {label}")
        for r in results:
            log(json.dumps(r, sort_keys=True))
        states[label] = {t: serving(ws, t) for t in ("acme", "beta")}
        for tenant in ("acme", "beta"):
            chunks, row = states[label][tenant]
            docs = sorted({c[0] for c in chunks})
            log(f"{tenant}: serving generation={row and row['generation_id']} "
                f"checkpoint={row and row['snapshot_id']} chunks={len(chunks)} docs={docs}")

    def both(as_of, acme, beta, sid, faults=None):
        api_a = DocsApi({"acme": acme}, as_of=as_of["acme"], faults=faults)
        api_b = DocsApi({"beta": beta}, as_of=as_of["beta"], faults=faults)
        return [sync_tenant(ws, api_a, "acme", f"acme-{sid}"),
                sync_tenant(ws, api_b, "beta", f"beta-{sid}")]

    step("s1 initial load", both({"acme": 1, "beta": 1}, sc.ACME_V1, sc.BETA_V1, "s1"))
    step("s2 edit, source delete, ACL withdrawal",
         both({"acme": 2, "beta": 1}, sc.ACME_V2, sc.BETA_V1, "s2"))
    step("s3 same input again",
         both({"acme": 2, "beta": 1}, sc.ACME_V2, sc.BETA_V1, "s3"))
    step("s4 truncated acme listing, beta timeout",
         both({"acme": 3, "beta": 2}, sc.ACME_V3, sc.BETA_V2, "s4",
              faults={"acme": "truncate", "beta": "timeout"}))
    try:
        sync_tenant(ws, DocsApi({"acme": sc.ACME_V3}, as_of=3), "acme", "acme-s5",
                    encode=failing_encoder)
        failed = {"tenant": "acme", "index": "unexpected success"}
    except EncoderDown as exc:
        failed = {"tenant": "acme", "index": f"build failed: {exc}"}
    step("s5 complete acme snapshot, index build fails", [failed])
    step("s6 retry", [
        {"tenant": "acme", **reconcile_tenant(ws, "acme")},
        sync_tenant(ws, DocsApi({"beta": sc.BETA_V2}, as_of=2), "beta", "beta-s6")])

    states["search"] = {
        "acme 'refund days' as all": find(ws, "acme", "refund days", "all"),
        "acme 'gateway' as support": find(ws, "acme", "gateway", "support"),
        "acme 'gateway' as eng": find(ws, "acme", "gateway", "eng"),
        "acme 'December' as all": find(ws, "acme", "December", "all"),
        "acme 'price' as all": find(ws, "acme", "price", "all"),
    }
    states["antipattern"] = query(
        ws, "select doc_key from main.incremental_documents_antipattern "
            "where tenant = 'acme' order by doc_key")
    states["desired"] = query(
        ws, "select doc_key from main.desired_documents where tenant = 'acme' "
            "order by doc_key")
    states["landed_holiday_rows"] = query(
        ws, "select snapshot_id from landing.snapshot_rows "
            "where doc_id = 'holiday-2023' order by snapshot_id")
    log("\n=== after s6")
    for key in ("search", "antipattern", "desired", "landed_holiday_rows"):
        log(f"{key}: {json.dumps(states[key])}")
    return states


def run_feed_scenario(ws: Workspace, log=print) -> dict:
    tables = {}
    for label, events in sc.FEED_PAGES:
        land_feed_page(ws, events)
        tables[label] = query(ws, "select doc_id, revision, body, deleted "
                                  "from feed.feed_documents order by doc_id")
        log(f"\n=== feed {label}")
        for row in tables[label]:
            log(f"  {row}")
    dbt_build(ws, "tag:feed")
    tables["live"] = query(ws, "select doc_id, revision, body "
                               "from main.feed_live_documents order by doc_id")
    log(f"\n=== feed_live_documents (dbt): {tables['live']}")
    return tables


def main() -> int:
    root = Path(__file__).resolve().parent / ".work" / "demo"
    shutil.rmtree(root, ignore_errors=True)
    for name in ("snapshots", "feed"):
        (root / name).mkdir(parents=True)
    run_snapshot_scenario(Workspace(root / "snapshots"))
    run_feed_scenario(Workspace(root / "feed"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
