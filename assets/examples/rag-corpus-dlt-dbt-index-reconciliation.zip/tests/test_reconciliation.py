"""Exact-state tests: compare complete sets and content, not only counts."""
import sqlite3

import pytest

import corpus_sync  # noqa: F401
from corpus_sync import index
from corpus_sync.landing import Workspace

import demo

ALL_STEPS = ["s1 initial load", "s2 edit, source delete, ACL withdrawal",
             "s3 same input again", "s4 truncated acme listing, beta timeout",
             "s5 complete acme snapshot, index build fails", "s6 retry"]


@pytest.fixture(scope="module")
def run(tmp_path_factory):
    return demo.run_snapshot_scenario(Workspace(tmp_path_factory.mktemp("snap")),
                                      log=lambda *_: None)


@pytest.fixture(scope="module")
def feed(tmp_path_factory):
    return demo.run_feed_scenario(Workspace(tmp_path_factory.mktemp("feed")),
                                  log=lambda *_: None)


def docs(state):
    chunks, _ = state
    return {c[0] for c in chunks}


def chunk_ids(state, doc_id):
    return [c[2] for c in state[0] if c[0] == doc_id]


def test_initial_load_indexes_published_readable_documents(run):
    s1 = run["s1 initial load"]
    assert docs(s1["acme"]) == {"holiday-2023", "refund-policy", "vpn-setup", "legal-hold"}
    assert docs(s1["beta"]) == {"onboarding", "expenses", "laptop-return"}
    assert len(chunk_ids(s1["acme"], "refund-policy")) == 4


def test_edit_delete_and_acl_withdrawal_reach_the_index(run):
    s1, s2 = run["s1 initial load"]["acme"], run["s2 edit, source delete, ACL withdrawal"]["acme"]
    assert docs(s2) == {"refund-policy", "vpn-setup", "legal-hold"}
    refund = [c for c in s2[0] if c[0] == "refund-policy"]
    assert [c[4] for c in refund] == [
        "Refund policy: Customers may request a refund within 14 days",
        "Refund policy: of purchase, paid to the original payment method.",
    ]
    assert not set(chunk_ids(s1, "refund-policy")) & set(chunk_ids(s2, "refund-policy"))
    assert {c[3] for c in s2[0] if c[0] == "vpn-setup"} == {"eng"}
    assert chunk_ids(s1, "vpn-setup") == chunk_ids(s2, "vpn-setup")  # content reused


def test_same_input_rerun_keeps_serving_state_identical(run):
    s2, s3 = (run["s2 edit, source delete, ACL withdrawal"],
              run["s3 same input again"])
    for tenant in ("acme", "beta"):
        assert s3[tenant][0] == s2[tenant][0]
        assert s3[tenant][1]["generation_id"] == s2[tenant][1]["generation_id"]
    assert s3["acme"][1]["snapshot_id"] == "acme-s3"  # checkpoint moved, index did not


def test_incomplete_or_failed_snapshot_keeps_serving_state(run):
    s3, s4 = run["s3 same input again"], run["s4 truncated acme listing, beta timeout"]
    assert s4 == s3


def test_failed_index_build_keeps_serving_state_and_retry_recovers(run):
    s4 = run["s4 truncated acme listing, beta timeout"]
    s5, s6 = run["s5 complete acme snapshot, index build fails"], run["s6 retry"]
    assert s5 == s4
    assert docs(s6["acme"]) == {"refund-policy", "vpn-setup", "legal-hold", "sso-login"}
    assert s6["acme"][1]["snapshot_id"] == "acme-s5"
    assert [c[4] for c in s6["beta"][0] if c[0] == "onboarding"] == [
        "Onboarding: New starters receive a laptop, accounts and a",
        "Onboarding: buddy on day one."]


def test_search_respects_deletion_and_acl(run):
    assert run["search"] == {
        "acme 'refund days' as all": ["refund-policy"],
        "acme 'gateway' as support": [],
        "acme 'gateway' as eng": ["vpn-setup"],
        "acme 'December' as all": [],
        "acme 'price' as all": [],
    }


def test_dbt_incremental_unique_key_keeps_absent_documents(run):
    antipattern = {r[0] for r in run["antipattern"]}
    desired = {r[0] for r in run["desired"]}
    assert "acme/holiday-2023" in antipattern
    assert "acme/holiday-2023" not in desired
    assert desired == {"acme/legal-hold", "acme/refund-policy",
                       "acme/sso-login", "acme/vpn-setup"}


def test_index_removal_is_not_physical_erasure(run):
    assert [r[0] for r in run["landed_holiday_rows"]] == ["acme-s1"]


def test_dlt_merge_keeps_absent_rows_and_stores_tombstones(feed):
    page2 = feed["page 2: only b changed; a and c are absent from the page"]
    assert page2 == [("a", 1, "alpha v1", False), ("b", 2, "bravo v2", False),
                     ("c", 1, "charlie v1", False)]
    page3 = feed["page 3: tombstone for c, plus an edit of a that arrives late (updated_at=15)"]
    assert page3 == [("a", 1, "alpha v1", False), ("b", 2, "bravo v2", False),
                     ("c", 2, None, True)]
    assert feed["live"] == [("a", 1, "alpha v1"), ("b", 2, "bravo v2")]


DOC = {"revision": 1, "title": "T", "body": "one two three four five six seven eight nine",
       "acl": "all", "content_hash": "h1"}
SNAP = {"snapshot_id": "x-1", "as_of": 1}


def test_rechunk_replaces_every_chunk_id(tmp_path):
    con = index.connect(tmp_path / "i.sqlite")
    index.reconcile(con, "x", SNAP, {"d": DOC})
    before = index.serving_chunks(con, "x")
    smaller = {**index.INDEX_SPEC, "chunker": "words-v2", "chunk_words": 4}
    result = index.reconcile(con, "x", SNAP, {"d": DOC}, spec=smaller)
    after = index.serving_chunks(con, "x")
    assert result["encoded"] == 3 and result["reused"] == 0
    assert [c[4] for c in after] == ["T: one two three four", "T: five six seven eight",
                                     "T: nine"]
    assert not {c[2] for c in before} & {c[2] for c in after}
    assert con.execute("select count(*) from chunks").fetchone()[0] == 3  # old gen gone


def test_stale_snapshot_is_ignored(tmp_path):
    con = index.connect(tmp_path / "i.sqlite")
    index.reconcile(con, "x", {"snapshot_id": "x-2", "as_of": 2}, {"d": DOC})
    before = index.serving_chunks(con, "x")
    result = index.reconcile(con, "x", SNAP, {})
    assert result == {"action": "stale_snapshot_ignored"}
    assert index.serving_chunks(con, "x") == before


def test_promotion_refuses_when_serving_moved(tmp_path):
    con = index.connect(tmp_path / "i.sqlite")
    index.reconcile(con, "x", SNAP, {"d": DOC})
    with pytest.raises(index.PromotionConflict):
        index.promote(con, "x", 999, {"snapshot_id": "x-9", "as_of": 9}, expected_gid=None)


def test_failed_build_keeps_serving_then_retry_removes_and_adds(tmp_path):
    con = index.connect(tmp_path / "i.sqlite")
    other = {**DOC, "title": "Old", "content_hash": "h2"}
    index.reconcile(con, "x", SNAP, {"d": DOC, "old": other})
    before = index.serving_chunks(con, "x")
    new = {**DOC, "title": "New", "body": "fresh text", "content_hash": "h3"}
    snap2 = {"snapshot_id": "x-2", "as_of": 2}

    def broken(text):
        raise RuntimeError("encoder down")

    with pytest.raises(RuntimeError):
        index.reconcile(con, "x", snap2, {"d": DOC, "new": new}, encode=broken)
    assert index.serving_chunks(con, "x") == before
    assert index.serving_row(con, "x")["snapshot_id"] == "x-1"
    result = index.reconcile(con, "x", snap2, {"d": DOC, "new": new})
    assert result["plan"]["removed"] == ["old"] and result["plan"]["added"] == ["new"]
    assert {c[0] for c in index.serving_chunks(con, "x")} == {"d", "new"}
    assert index.serving_row(con, "x")["snapshot_id"] == "x-2"
    assert {r[0] for r in con.execute("select status from generations")} == {"serving"}
