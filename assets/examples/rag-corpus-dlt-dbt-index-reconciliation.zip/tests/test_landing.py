"""Landing regressions: dlt 0.4.2 pending packages, attempt IDs and content hashes."""
import dlt
import pytest
from dlt.common.exceptions import DestinationHasFailedJobs

import corpus_sync  # noqa: F401
from corpus_sync import index, landing, scenario as sc
from corpus_sync.landing import SnapshotError, Workspace
from corpus_sync.source import DocsApi, Doc
from corpus_sync.sync import reconcile_tenant, sync_tenant
from corpus_sync.transform import dbt_build, query


class Crash(Exception):
    """A process dying in the middle of a dlt step."""


def crash_on_call(monkeypatch, method, call):
    original = getattr(dlt.Pipeline, method)
    calls = []

    def step(self, *args, **kwargs):
        calls.append(method)
        if len(calls) == call:
            raise Crash(f"simulated crash in {method} #{call}")
        return original(self, *args, **kwargs)

    monkeypatch.setattr(dlt.Pipeline, method, step)


def manifests(ws):
    return query(ws, "select snapshot_id, complete from landing.snapshot_manifests "
                     "order by snapshot_id")


@pytest.mark.parametrize("method, call", [
    ("normalize", 1),  # rows extracted, never normalised
    ("load", 1),       # rows normalised, never loaded
    ("load", 2),       # rows loaded, manifest normalised but never loaded
])
def test_crashed_attempt_leftovers_never_replace_a_fresh_attempt(tmp_path, monkeypatch, method, call):
    ws = Workspace(tmp_path)
    first = sync_tenant(ws, DocsApi({"acme": sc.ACME_V1}, as_of=1), "acme", "acme-s1")
    assert first["landing"] == "complete"
    with monkeypatch.context() as patched:
        crash_on_call(patched, method, call)
        crashed = sync_tenant(ws, DocsApi({"acme": sc.ACME_V2}, as_of=2), "acme", "acme-s2")
    assert crashed["landing"] == "failed: Crash"
    assert landing._pipeline(ws, "corpus_snapshots", "landing").has_pending_data

    api = DocsApi({"acme": sc.ACME_V3}, as_of=3)
    retry = sync_tenant(ws, api, "acme", "acme-s3")
    assert api.calls, "the fresh extractor must run instead of only loading leftovers"
    assert retry["landing"] == "complete"
    assert len(retry["discarded_pending_packages"]) == 1
    assert retry["desired_from"] == "acme-s3" and retry["index"]["action"] == "promoted"
    assert not landing._pipeline(ws, "corpus_snapshots", "landing").has_pending_data
    # The crash happened before the manifest load committed, so no manifest landed.
    assert manifests(ws) == [("acme-s1", True), ("acme-s3", True)]


def test_manifest_committed_before_a_crash_stays_a_valid_snapshot(tmp_path, monkeypatch):
    ws = Workspace(tmp_path)
    sync_tenant(ws, DocsApi({"acme": sc.ACME_V1}, as_of=1), "acme", "acme-s1")
    original, calls = dlt.Pipeline.run, []

    def run_then_die(self, *args, **kwargs):
        info = original(self, *args, **kwargs)
        calls.append(kwargs.get("table_name", "snapshot_rows"))
        if len(calls) == 2:  # the manifest load has committed; land_snapshot never returns
            raise Crash("simulated crash after the manifest load committed")
        return info

    with monkeypatch.context() as patched:
        patched.setattr(dlt.Pipeline, "run", run_then_die)
        crashed = sync_tenant(ws, DocsApi({"acme": sc.ACME_V2}, as_of=2), "acme", "acme-s2")
    assert crashed["landing"] == "failed: Crash"
    assert calls == ["snapshot_rows", "snapshot_manifests"]
    # Dropping local packages cannot undo committed rows or the committed manifest.
    assert landing.discard_pending_packages(ws) == []
    assert manifests(ws) == [("acme-s1", True), ("acme-s2", True)]
    assert query(ws, "select count(*) from landing.snapshot_rows where snapshot_id = 'acme-s2'") \
        == [(len(sc.ACME_V2),)]
    # Rows landed first, so the committed manifest describes a complete snapshot and
    # recovery serves it like any other.
    dbt_build(ws, "tag:corpus")
    recovered = reconcile_tenant(ws, "acme")
    assert recovered["desired_from"] == "acme-s2"
    assert recovered["index"]["action"] == "promoted"
    con = index.connect(ws.index_path)
    try:
        served = {c[0] for c in index.serving_chunks(con, "acme")}
        assert served == {d.doc_id for d in sc.ACME_V2 if d.status == "published"}
    finally:
        con.close()


def test_reused_attempt_id_is_rejected_before_extraction(tmp_path):
    ws = Workspace(tmp_path)
    sync_tenant(ws, DocsApi({"acme": sc.ACME_V1}, as_of=1), "acme", "acme-s1")
    api = DocsApi({"acme": sc.ACME_V2}, as_of=2)
    again = sync_tenant(ws, api, "acme", "acme-s1")
    assert again == {"tenant": "acme", "landing": "failed: SnapshotError",
                     "index": {"action": "not_attempted"}}
    assert api.calls == []
    assert manifests(ws) == [("acme-s1", True)]


class FakeInfo:
    def __init__(self, failed):
        self.failed = failed

    def raise_on_failed_jobs(self):
        if self.failed:
            raise DestinationHasFailedJobs("duckdb", "1", ["snapshot_rows.insert_values"])


class FakePipeline:
    """Stands in for dlt to model outcomes that are hard to trigger in DuckDB."""
    has_pending_data = False

    def __init__(self, extract, failed):
        self.extract, self.failed, self.runs = extract, failed, []

    def run(self, data, **kwargs):
        self.runs.append(kwargs.get("table_name", "snapshot_rows"))
        if self.extract:
            list(data)
        return FakeInfo(self.failed)


@pytest.mark.parametrize("extract, failed", [(False, False), (True, True)],
                         ids=["extractor_never_ran", "terminal_job_failure"])
def test_no_manifest_is_appended_unless_rows_were_extracted_and_loaded(tmp_path, monkeypatch,
                                                                       extract, failed):
    fake = FakePipeline(extract, failed)
    monkeypatch.setattr(landing, "_pipeline", lambda *args: fake)
    api = DocsApi({"acme": sc.ACME_V1}, as_of=1)
    with pytest.raises((SnapshotError, DestinationHasFailedJobs)):
        landing.land_snapshot(Workspace(tmp_path), api, "acme", "acme-s1")
    assert fake.runs == ["snapshot_rows"]


def test_content_hash_keeps_the_title_body_boundary(tmp_path):
    ws = Workspace(tmp_path)
    before = Doc("d", 1, "A\nB", "C", "all")
    after = Doc("d", 2, "A", "B\nC", "all")  # same characters, newline moved across fields
    sync_tenant(ws, DocsApi({"x": [before]}, as_of=1), "x", "x-1")
    result = sync_tenant(ws, DocsApi({"x": [after]}, as_of=2), "x", "x-2")
    assert result["index"]["plan"]["content_changed"] == ["d"]
    con = index.connect(ws.index_path)
    try:
        assert [c[4] for c in index.serving_chunks(con, "x")] == ["A: B C"]
    finally:
        con.close()
