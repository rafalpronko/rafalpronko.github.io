"""Regression tests for candidate integrity, tenant scope, chunk identity and cleanup."""
import sqlite3

import pytest

from corpus_sync import index

DOC = {"revision": 1, "title": "T", "body": "one two three four five six seven eight nine",
       "acl": "all", "content_hash": "h1"}
SNAP = {"snapshot_id": "x-1", "as_of": 1}


@pytest.mark.parametrize("damage", ["chunk_text", "fts_text", "missing_tail",
                                   "mixed_metadata", "tenant", "chunk_id"])
def test_corrupt_candidate_is_rejected_before_promotion_and_retry_recovers(tmp_path, monkeypatch, damage):
    con = index.connect(tmp_path / "index.sqlite")
    index.reconcile(con, "x", SNAP, {"d": DOC})
    before = index.serving_chunks(con, "x"), index.serving_row(con, "x")
    desired = {"d": {**DOC, "revision": 2, "content_hash": "h2"}}
    snap2 = {"snapshot_id": "x-2", "as_of": 2}
    build = index.build_generation

    def damaged_build(*args):
        gid, stats = build(*args)
        if damage == "chunk_text":
            con.execute("update chunks set text = 'corrupt' where generation_id = ?", (gid,))
        elif damage == "fts_text":
            con.execute("update chunk_fts set text = 'corrupt' where generation_id = ?", (gid,))
        elif damage == "missing_tail":
            cid = con.execute("select chunk_id from chunks where generation_id = ? and ordinal = 1",
                              (gid,)).fetchone()[0]
            con.execute("delete from chunks where generation_id = ? and chunk_id = ?", (gid, cid))
            con.execute("delete from chunk_fts where generation_id = ? and chunk_id = ?", (gid, cid))
        elif damage == "mixed_metadata":
            con.execute("update chunks set revision = 0 where generation_id = ? and ordinal = 0", (gid,))
        elif damage == "tenant":
            con.execute("update chunks set tenant = 'other' where generation_id = ?", (gid,))
        else:
            con.execute("update chunks set chunk_id = 'wrong' where generation_id = ? and ordinal = 0", (gid,))
            con.execute("update chunk_fts set chunk_id = 'wrong' where generation_id = ? and text = ?",
                        (gid, "T: one two three four five six seven eight"))
        return gid, stats

    monkeypatch.setattr(index, "build_generation", damaged_build)
    with pytest.raises(index.IndexValidationError):
        index.reconcile(con, "x", snap2, desired)
    assert (index.serving_chunks(con, "x"), index.serving_row(con, "x")) == before
    monkeypatch.setattr(index, "build_generation", build)
    index.reconcile(con, "x", snap2, desired)
    assert [c[4] for c in index.serving_chunks(con, "x")] == [
        "T: one two three four five six seven eight", "T: nine"]
    assert index.serving_row(con, "x")["snapshot_id"] == "x-2"
    assert con.execute("select status from generations").fetchall() == [("serving",)]
    con.close()


def test_chunk_identity_has_unambiguous_field_boundaries():
    a = index.chunk_id("a|b", "c", "h", index.INDEX_SPEC, 0)
    b = index.chunk_id("a", "b|c", "h", index.INDEX_SPEC, 0)
    assert a != b
    assert a == index.chunk_id("a|b", "c", "h", dict(reversed(list(index.INDEX_SPEC.items()))), 0)
    assert len(a) == 64


def test_promotion_rejects_another_tenants_candidate(tmp_path):
    con = index.connect(tmp_path / "index.sqlite")
    index.reconcile(con, "x", SNAP, {"d": DOC})
    before = index.serving_chunks(con, "x"), index.serving_row(con, "x")
    snap2 = {"snapshot_id": "x-2", "as_of": 2}
    gid, _ = index.build_generation(con, "other", snap2, {"d": DOC}, index.INDEX_SPEC,
                                    None, lambda text: text)
    with pytest.raises(index.IndexValidationError):
        index.promote(con, "x", gid, snap2, before[1]["generation_id"])
    assert (index.serving_chunks(con, "x"), index.serving_row(con, "x")) == before
    con.close()


def test_cleanup_failure_after_promotion_reports_the_committed_state(tmp_path, monkeypatch):
    con = index.connect(tmp_path / "index.sqlite")
    index.reconcile(con, "x", SNAP, {"d": DOC})
    desired = {"d": {**DOC, "revision": 2, "content_hash": "h2"}}
    snap2 = {"snapshot_id": "x-2", "as_of": 2}

    def failing_drop(con, gid):
        raise sqlite3.OperationalError("disk I/O error")

    monkeypatch.setattr(index, "_drop_generation", failing_drop)
    result = index.reconcile(con, "x", snap2, desired)
    assert (result["action"], result["cleanup"]) == ("promoted", "pending: OperationalError")
    assert index.serving_row(con, "x")["snapshot_id"] == "x-2"
    assert sorted(con.execute("select status from generations")) == [("retired",), ("serving",)]
    monkeypatch.undo()
    assert index.reconcile(con, "x", snap2, desired) == {"action": "already_current"}
    assert con.execute("select status from generations").fetchall() == [("serving",)]
    con.close()


def test_empty_authoritative_state_deletes_only_its_tenant(tmp_path):
    con = index.connect(tmp_path / "index.sqlite")
    index.reconcile(con, "x", SNAP, {"d": DOC})
    index.reconcile(con, "other", SNAP, {"d": DOC})
    other = index.serving_chunks(con, "other"), index.serving_row(con, "other")
    before = index.serving_chunks(con, "x"), index.serving_row(con, "x")
    assert index.reconcile(con, "x", None, {}) == {"action": "no_complete_snapshot"}
    assert (index.serving_chunks(con, "x"), index.serving_row(con, "x")) == before
    result = index.reconcile(con, "x", {"snapshot_id": "x-2", "as_of": 2}, {})
    assert result["plan"]["removed"] == ["d"]
    assert index.serving_chunks(con, "x") == []
    assert (index.serving_chunks(con, "other"), index.serving_row(con, "other")) == other
    assert index.search(con, "x", "one", "all") == []
    assert {r[0] for r in index.search(con, "other", "one", "all")} == {"d"}
    con.close()
