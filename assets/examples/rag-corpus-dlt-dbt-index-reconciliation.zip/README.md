# RAG corpus reconciliation: dlt → DuckDB → dbt → SQLite FTS5

Synthetic, offline example for the post
"Keeping a RAG corpus current: dlt, dbt and index reconciliation, deletions included".

- Loading: dlt 0.4.2 (DuckDB destination)
- Transformation: dbt-core 1.7.4 + dbt-duckdb 1.7.0, DuckDB 0.9.2
- Index: SQLite FTS5 keyword index (stdlib `sqlite3`). **No embeddings, no vector store, no network calls.**
- Python 3.11. Dependencies are pinned in `pyproject.toml` and locked in `uv.lock`
  (resolved with `exclude-newer = 2024-01-04`).

The article's 2024-01-04 date is a historical editorial label, not an actual
historical publication. This example was prepared and executed on 2026-10-12
using modern tooling: Python 3.11.12, uv 0.7.8 and SQLite 3.47.1 on macOS arm64.
The lock's `exclude-newer = "2024-01-04T00:00:00Z"` constrains dependency release
availability; it does not backdate uv, the interpreter or the execution.
Python's SQLite build must support FTS5. Other platforms were not verified.

## Run

```bash
env UV_CACHE_DIR=.work/uv-cache uv sync --frozen
env UV_CACHE_DIR=.work/uv-cache uv run --frozen python demo.py
env UV_CACHE_DIR=.work/uv-cache uv run --frozen pytest -v
```

Run from the extracted directory containing this README and `pyproject.toml`.
The initial dependency sync needs package downloads; the synthetic demo itself
uses no network calls, API keys or credentials. The demo recreates only its own
`./.work/demo` directory. Pytest recreates its configured `./.work/pytest`.
Run these commands sequentially: the shared landing pipeline and dbt models
are not designed for concurrent writers.

The full suite runs both the snapshot scenario and the separate feed scenario,
plus landing and index regressions. Latest verified full result: 31 passed,
0 skipped, exit 0 on 2026-10-12 (run with `--offline` against the synced
environment). Legacy dependency deprecation warnings remain visible;
they were not suppressed or turned into skipped tests.

Telemetry for dlt and dbt is switched off in `corpus_sync/__init__.py`, and all
runtime state (dlt pipelines, DuckDB, dbt target/logs, SQLite index) goes to `./.work/`.

## Layout

- `corpus_sync/source.py` – in-memory paginated documents API with faults (truncate, timeout)
- `corpus_sync/landing.py` – dlt resources: append snapshot rows + manifest, pending-package
  recovery and load guards; merge-based change feed
- `dbt_project/` – full-table models (complete snapshots, desired documents), a naive incremental
  model kept as an anti-pattern, and a tombstone filter for the feed
- `corpus_sync/index.py` – generations, desired-state diff, validation, promotion + checkpoint
- `corpus_sync/sync.py` – one per-tenant sync step
- `demo.py` – six-step snapshot scenario and three-page feed scenario
- `tests/` – exact-state tests, landing crash-recovery and index guard regressions

Assumptions: one writer per tenant; the whole index is one SQLite file, so promotion and
checkpoint commit atomically. Removing a document from the index is not physical erasure:
landed rows in DuckDB keep it.

Every landing attempt needs a unique snapshot ID and the API must supply a
monotonic, immutable source version and a truthful total. Landing rejects an ID
that already has rows or a manifest. Retry index work from the landed snapshot
instead of landing it again. Two complete snapshots with the same `as_of` are
ordered by `snapshot_id` as strings; that is safe only because one `as_of`
identifies one immutable listing.

Crash recovery: dlt 0.4.2 `pipeline.run(data)` loads pending load packages left
by an interrupted earlier run and then returns without extracting `data`.
`sync_tenant` therefore drops pending packages first
(`drop_pending_packages(with_partial_loads=True)`) and reports their load IDs as
`discarded_pending_packages`. Rows from a partly loaded leftover may remain; an
attempt that crashed before its manifest load committed has no manifest and is
never selected. Dropping packages does not roll back committed DuckDB rows or
manifests: a manifest committed just before a crash stays and is a valid
snapshot, because its rows landed first. Every `run` refuses to start
with pending packages, raises on failed load jobs and checks that nothing is
left pending; an empty manifest fails before anything is appended.
`tests/test_landing.py` crashes normalisation, the row load and the manifest
load and checks that the retry lists the source again; a fourth case crashes
after the manifest load committed and checks that this complete snapshot is
served.

Cleanup of old generations runs after the promotion has committed. If it fails,
the result is `promoted` with `cleanup: pending`, and the next run cleans up
before anything else. A source that wrongly lists an empty tenant with
`total = 0` would empty it; a deletion threshold (not implemented) is a cheap
additional safeguard. The first
ever snapshot needs document rows to infer the landing schema; an initially
empty warehouse needs schema bootstrapping (not implemented here). A missing
table fails dbt and prevents promotion. An empty authoritative desired state is
supported by index reconciliation and tested for tenant-scoped deletion.

Incomplete snapshots are never promoted; the latest complete snapshot remains
eligible. A run whose listing is incomplete still reconciles against it, so it can
promote an earlier complete snapshot whose index build had failed.

The readable `tenant/doc_id` dbt key assumes slash-free demo identifiers; use
structured keys in production. The content hash length-prefixes the title, so
moving a line break between title and body changes it. MD5 is a trusted-input
content change detector, not a security hash. Chunk IDs use canonical JSON field boundaries and full
SHA256. Candidate validation compares every expected chunk field and FTS text,
and promotion rejects a candidate with the wrong tenant/snapshot/version/status.

Search accepts a tenant and one group supplied by its caller. Authentication,
trusted group membership, immediate revocation, multiple-group authorisation,
retention/erasure and remote-vector-store consistency are not implemented.
ACL group names must be canonical and contain neither commas nor surrounding
whitespace. Shared FTS statistics do not provide isolated tenant ranking.
