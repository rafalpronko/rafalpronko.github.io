{{ config(tags=['corpus']) }}
-- A snapshot counts only if the extractor declared it complete AND the rows
-- that actually landed match the manifest. Rows without a manifest are ignored.
with landed as (
    select tenant, snapshot_id,
           count(*) as landed_rows,
           count(distinct doc_id) as landed_docs
    from {{ source('landing', 'snapshot_rows') }}
    group by tenant, snapshot_id
)
select m.tenant, m.snapshot_id, m.as_of, m.row_count
from {{ source('landing', 'snapshot_manifests') }} as m
left join landed as l
    on l.tenant = m.tenant and l.snapshot_id = m.snapshot_id
where m.complete
  and m.row_count = m.declared_total
  and coalesce(l.landed_rows, 0) = m.row_count
  and coalesce(l.landed_docs, 0) = m.row_count
