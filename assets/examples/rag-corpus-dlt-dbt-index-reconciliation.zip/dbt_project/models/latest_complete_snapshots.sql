{{ config(tags=['corpus']) }}
select tenant, snapshot_id, as_of
from (
    select *,
           row_number() over (
               partition by tenant order by as_of desc, snapshot_id desc
           ) as rn
    from {{ ref('complete_snapshots') }}
)
where rn = 1
