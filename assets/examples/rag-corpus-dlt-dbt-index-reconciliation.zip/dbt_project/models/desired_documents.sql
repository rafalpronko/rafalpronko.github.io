{{ config(tags=['corpus']) }}
-- Full-table model: rebuilt from the latest complete snapshot of each tenant
-- on every run, so a document missing from that snapshot is simply absent.
select
    r.tenant || '/' || r.doc_id as doc_key,
    r.tenant,
    r.doc_id,
    r.revision,
    r.title,
    r.body,
    r.acl,
    -- Length-prefixed title: moving text between title and body changes the hash.
    md5(strlen(r.title)::varchar || ':' || r.title || r.body) as content_hash,
    s.snapshot_id,
    s.as_of
from {{ source('landing', 'snapshot_rows') }} as r
join {{ ref('latest_complete_snapshots') }} as s
    on s.tenant = r.tenant and s.snapshot_id = r.snapshot_id
where r.status = 'published' and r.acl <> ''
