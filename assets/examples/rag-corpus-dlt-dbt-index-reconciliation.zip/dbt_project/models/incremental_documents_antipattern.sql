{{ config(
    materialized='incremental',
    unique_key='doc_key',
    incremental_strategy='delete+insert',
    tags=['corpus'],
) }}
-- Deliberately naive: only rows loaded since the last run are processed.
-- unique_key replaces matching keys; it never removes keys that stop arriving.
select
    tenant || '/' || doc_id as doc_key,
    tenant, doc_id, revision, title, body, snapshot_id, _dlt_load_id
from {{ source('landing', 'snapshot_rows') }}
{% if is_incremental() %}
where _dlt_load_id > (select max(_dlt_load_id) from {{ this }})
{% endif %}
