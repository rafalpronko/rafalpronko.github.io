{{ config(tags=['feed']) }}
-- A tombstone is a row with deleted = true; dlt 0.4.2 merge keeps it as a row.
select doc_id, revision, title, body, updated_at
from {{ source('feed', 'feed_documents') }}
where not coalesce(deleted, false)
